from curses import wrapper, newwin, error as curses_error
import curses
from tabulate import tabulate
import requests
import websocket
import json
import time
import threading
import hmac
import hashlib
import signal
from urllib.parse import urlencode
import os
import sys

# --- Replace with your actual API key and secret ---
api_key = "YOUR_API_KEY"
api_secret = "YOUR_API_SECRET"

# --- API Endpoints (Bybit Linear Perpetual) ---
base_url = "https://api.bybit.com"
ws_url = "wss://stream.bybit.com/realtime_public"

# --- Global Variables ---
market_data = {"last_price": "--", "change": "--", "volume": "--", "symbol": "BTCUSDT"}
order_details = {
    "order_id": "--", "symbol": "--", "side": "--", "type": "--",
    "quantity": "--", "price": "--", "status": "--"
}
position_details = {
    "symbol": "--", "side": "--", "size": "--", "avg_price": "--"
}
ws_client = None
running = True

# --- Helper Functions ---
def generate_signature(api_secret, data):
    """Generates a signature for the request."""
    signature = hmac.new(
        api_secret.encode("utf-8"),
        data.encode("utf-8"),
        digestmod=hashlib.sha256
    ).hexdigest()
    return signature

def get_timestamp():
    """Gets the current timestamp in milliseconds."""
    return int(time.time() * 1000)

def send_signed_request(method, endpoint, params=None, is_private=True):
    """Sends a signed request to the Bybit API."""
    if params is None:
        params = {}
    timestamp = get_timestamp()
    if is_private:
        params["api_key"] = api_key
        params["timestamp"] = timestamp

    param_str = urlencode(sorted(params.items()))
    if is_private:
        signature = generate_signature(api_secret, param_str)
        params["sign"] = signature

    url = f"{base_url}{endpoint}"
    headers = {"Content-Type": "application/json"}

    try:
        if method == "GET":
            response = requests.get(url, params=params, headers=headers)
        elif method == "POST":
            response = requests.post(url, data=json.dumps(params), headers=headers)
        else:
            raise ValueError("Invalid HTTP method.")

        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return None

def send_public_request(endpoint, params=None):
    """Sends a public request to the Bybit API (no signature required)."""
    if params is None:
        params = {}

    url = f"{base_url}{endpoint}"
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return None

# --- API Functions ---
def place_order(symbol, side, order_type, quantity, price=None, stop_loss=None, take_profit=None):
    """Places an order on Bybit (Linear Perpetual)."""
    endpoint = "/v5/order/create"
    params = {
        "category": "linear",
        "symbol": symbol,
        "side": side,
        "orderType": order_type,
        "qty": str(quantity),
    }

    if order_type == "Limit":
        params["price"] = str(price)
    if stop_loss:
        params["stopLoss"] = str(stop_loss)
    if take_profit:
        params["takeProfit"] = str(take_profit)

    response = send_signed_request("POST", endpoint, params)
    if response and response["retCode"] == 0:
        return response["result"]["orderId"]
    else:
        return None

def amend_order(order_id, symbol, quantity=None, price=None, stop_loss=None, take_profit=None):
    """Amends an existing order."""
    endpoint = "/v5/order/amend"
    params = {
        "category": "linear",
        "symbol": symbol,
        "orderId": order_id
    }

    if quantity:
        params["qty"] = str(quantity)
    if price:
        params["price"] = str(price)
    if stop_loss:
        params["stopLoss"] = str(stop_loss)
    if take_profit:
        params["takeProfit"] = str(take_profit)

    response = send_signed_request("POST", endpoint, params)
    return response and response["retCode"] == 0

def cancel_order(order_id, symbol):
    """Cancels an order."""
    endpoint = "/v5/order/cancel"
    params = {
        "category": "linear",
        "symbol": symbol,
        "orderId": order_id,
    }
    response = send_signed_request("POST", endpoint, params)
    return response and response["retCode"] == 0

def get_position(symbol):
    """Gets the current position for a symbol."""
    endpoint = "/v5/position/list"
    params = {"category": "linear", "symbol": symbol}
    response = send_signed_request("GET", endpoint, params)

    if response and response["retCode"] == 0:
        results = response['result']['list']
        return results[0] if results else None
    else:
        return None

def get_market_data(symbol="BTCUSDT"):
    """Gets market data (ticker) for a symbol."""
    endpoint = "/v5/market/tickers"
    params = {"category": "linear", "symbol": symbol}
    response = send_public_request(endpoint, params)
    if response and response["retCode"] == 0:
        ticker_data = response["result"]['list'][0]
        return {
            "last_price": ticker_data["lastPrice"],
            "change": ticker_data["price24hPcnt"],
            "volume": ticker_data["volume24h"],
            "symbol": symbol
        }
    else:
        return None

def get_open_orders(symbol="BTCUSDT"):
    """Gets open orders for a symbol."""
    endpoint = "/v5/order/realtime"
    params = {"category": "linear", "symbol": symbol}
    response = send_signed_request("GET", endpoint, params)
    if response and response["retCode"] == 0:
        return response["result"]['list']
    else:
        return None

# --- WebSocket Handling ---
def on_message(ws, message):
    """Handles incoming WebSocket messages."""
    data = json.loads(message)

    if "topic" in data and data["topic"].startswith("tickers.") and "data" in data:
        try:
            ticker_data = data['data']
            market_data.update({
                "last_price": ticker_data["lastPrice"],
                "change": ticker_data["price24hPcnt"],
                "volume": ticker_data["volume24h"],
                "symbol": ticker_data['symbol']
            })
        except (KeyError, TypeError) as e:
            pass

    if 'topic' in data and data['topic'] == 'order' and 'data' in data:
        for order in data['data']:
            if order.get('symbol') == market_data['symbol']:
                order_details.update({
                    "order_id": order.get('orderId', order_details['order_id']),
                    "symbol": order.get('symbol', order_details['symbol']),
                    "side": order.get('side', order_details['side']),
                    "type": order.get('orderType', order_details['type']),
                    "quantity": order.get('qty', order_details['quantity']),
                    "price": order.get('price', order_details['price']),
                    "status": order.get('orderStatus', order_details['status']),
                })

    if 'topic' in data and data['topic'] == 'position' and 'data' in data:
        for position in data['data']:
            if position.get('symbol') == market_data['symbol']:
                position_details.update({
                    "symbol": position.get("symbol", position_details['symbol']),
                    "side": position.get("side", position_details['side']),
                    "size": str(position.get("size", position_details['size'])),
                    "avg_price": str(position.get("avgPrice", position_details['avg_price']))
                })

def on_error(ws, error):
    pass

def on_close(ws, close_status_code, close_msg):
    pass

def on_open(ws):
    subscribe_to_tickers(market_data["symbol"])
    subscribe_to_private_topics()

def subscribe_to_tickers(symbol):
    if ws_client:
        subscribe_request = {
            "op": "subscribe",
            "args": [f"tickers.{symbol}"]
        }
        ws_client.send(json.dumps(subscribe_request))

def subscribe_to_private_topics():
    expires = str(get_timestamp() + 1000)
    signature_data = "GET/realtime" + expires
    signature = generate_signature(api_secret, signature_data)

    auth_request = {
        "op": "auth",
        "args": [api_key, expires, signature],
    }
    if ws_client:
        ws_client.send(json.dumps(auth_request))
        subscribe_request = {
            "op": "subscribe",
            "args": ["order", "position"]
        }
        ws_client.send(json.dumps(subscribe_request))

def run_websocket():
    global ws_client, running

    while running:
        try:
            ws_client = websocket.WebSocketApp(
                ws_url,
                on_open=on_open,
                on_message=on_message,
                on_error=on_error,
                on_close=on_close
            )
            ws_client.run_forever(ping_interval=20, ping_timeout=10)
        except Exception as e:
            pass
        finally:
            if ws_client:
                ws_client.close()
            time.sleep(5)

# --- UI Update Functions ---
def update_market_data_ui(window):
    if window:
        window.clear()
        window.border()
        window.addstr(1, 1, f"Symbol: {market_data['symbol']}", curses.A_BOLD)
        window.addstr(2, 1, f"Last Price: {market_data['last_price']}")
        change = float(market_data['change']) if market_data['change'] != '--' else 0
        color = curses.color_pair(2) if change >= 0 else curses.color_pair(3)
        window.addstr(3, 1, f"Change: {market_data['change']}%", color)
        window.addstr(4, 1, f"Volume: {market_data['volume']}")
        window.refresh()

def update_order_status_ui(window):
    if window:
        window.clear()
        window.border()
        window.addstr(1, 1, "Order Status", curses.A_BOLD)
        window.addstr(2, 1, f"ID: {order_details['order_id']}")
        window.addstr(3, 1, f"Symbol: {order_details['symbol']}")
        window.addstr(4, 1, f"Side: {order_details['side']}")
        window.addstr(5, 1, f"Type: {order_details['type']}")
        window.addstr(6, 1, f"Quantity: {order_details['quantity']}")
        window.addstr(7, 1, f"Price: {order_details['price']}")
        window.addstr(8, 1, f"Status: {order_details['status']}", curses.color_pair(1) if order_details['status'] == 'Filled' else curses.color_pair(0))
        window.refresh()

def update_position_ui(window):
    if window:
        window.clear()
        window.border()
        window.addstr(1, 1, "Position Details", curses.A_BOLD)
        window.addstr(2, 1, f"Symbol: {position_details['symbol']}")
        window.addstr(3, 1, f"Side: {position_details['side']}")
        window.addstr(4, 1, f"Size: {position_details['size']}")
        window.addstr(5, 1, f"Avg Price: {position_details['avg_price']}")
        window.refresh()

def update_ui(market_win, order_win, position_win):
    while running:
        try:
            update_market_data_ui(market_win)
            update_order_status_ui(order_win)
            update_position_ui(position_win)
            time.sleep(0.1)
        except curses_error:
            pass

# --- Main Function ---
def main(stdscr):
    global running, ws_client

    def signal_handler(sig, frame):
        global running
        running = False
        if ws_client:
            ws_client.close()
        curses.endwin()
        sys.exit(0)
    signal.signal(signal.SIGINT, signal_handler)

    if 'TERMUX_VERSION' not in os.environ:
        pass

    try:
        curses.noecho()
        curses.cbreak()
        stdscr.keypad(True)
        stdscr.nodelay(1)
        curses.curs_set(0)

        if curses.has_colors():
            curses.start_color()
            curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
            curses.init_pair(2, curses.COLOR_RED, curses.COLOR_BLACK)
            curses.init_pair(3, curses.COLOR_CYAN, curses.COLOR_BLACK)

        max_y, max_x = stdscr.getmaxyx()

        market_win = newwin(8, max_x//2, 0, 0)
        order_win = newwin(8, max_x//2, 0, max_x//2)
        position_win = newwin(8, max_x//2, 8, 0)
        input_win = newwin(3, max_x, 16, 0)

        ws_thread = threading.Thread(target=run_websocket, daemon=True)
        ui_thread = threading.Thread(target=update_ui, args=(market_win, order_win, position_win), daemon=True)
        ws_thread.start()
        ui_thread.start()

        while running:
            c = stdscr.getch()
            if c == -1:
                continue
            cmd = chr(c)

            if cmd == 'q':
                running = False
            elif cmd == 'h':
                input_win.clear()
                input_win.border()
                input_win.addstr(1, 1, "Commands: h=Help, p=Place, a=Amend, c=Cancel, l=List, s=Position, chg=Change Symbol, q=Quit")
                input_win.refresh()
                stdscr.nodelay(0)
                input_win.getch()
                stdscr.nodelay(1)
            elif cmd == 'p':
                # Place order logic
                pass
            # Implement other commands similarly

            time.sleep(0.1)

    except Exception as e:
        running = False
        raise e

if __name__ == "__main__":
    wrapper(main)
