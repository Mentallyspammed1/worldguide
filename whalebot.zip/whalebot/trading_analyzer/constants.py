"""Constants and configurations for the trading signal analyzer."""

# Indicator Keywords
TREND_KEYWORDS = {
    'BULLISH': ['Bullish', 'Accumulation', 'Oversold'],
    'BEARISH': ['Bearish', 'Distribution', 'Overbought']
}

# Confidence Scores
TREND_CONFIRMATION_SCORE = 2.0
INDICATOR_CONFIRMATION_SCORE = 1.0
MAX_CONFIDENCE = 10.0

# ATR Multipliers
TP_ATR_MULTIPLIER = 2.0
SL_ATR_MULTIPLIER = 1.5

# File System
BOT_LOGS_DIR = "bot_logs"
