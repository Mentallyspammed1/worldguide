"""Data models for trading analysis."""
from dataclasses import dataclass
from typing import Dict, List, Optional

@dataclass
class PriceLevel:
    label: str
    price: float

@dataclass
class AnalysisResult:
    signal: str
    confidence: float
    tp: Optional[str]
    sl: Optional[str]
    reasoning: str
    
@dataclass
class TradingIndicators:
    trend: str
    strength: float
    indicators: Dict[str, str]
    current_price: float
    atr: float
    support_levels: List[PriceLevel]
    resistance_levels: List[PriceLevel]
