"""Main entry point for the trading signal analyzer."""
import os
from signal_analyzer import SignalAnalyzer
from constants import BOT_LOGS_DIR

def get_latest_log_content() -> str:
    """Get content from the latest log file."""
    try:
        log_files = [
            f for f in os.listdir(BOT_LOGS_DIR) 
            if os.path.isfile(os.path.join(BOT_LOGS_DIR, f))
        ]
        
        if not log_files:
            raise FileNotFoundError(f"No log files found in {BOT_LOGS_DIR} directory.")
            
        latest_log_file = max(
            log_files,
            key=lambda f: os.path.getmtime(os.path.join(BOT_LOGS_DIR, f))
        )
        
        with open(os.path.join(BOT_LOGS_DIR, latest_log_file), "r") as file:
            return file.read()
            
    except Exception as e:
        raise RuntimeError(f"Error reading log file: {str(e)}")

def main():
    try:
        # Get the latest log content
        output_text = get_latest_log_content()
        
        # Initialize the analyzer
        analyzer = SignalAnalyzer()
        
        # Parse the indicators from the log
        trading_data = analyzer.parse_indicators(output_text.split("\n"))
        
        # Analyze the signals
        analysis_result = analyzer.analyze_signals(trading_data)
        
        # Print the results
        print("Analysis of the latest log file:")
        print(f"  Signal: {analysis_result.signal}")
        print(f"  Confidence: {analysis_result.confidence:.1f}")
        print(f"  Take Profit: {analysis_result.tp}")
        print(f"  Stop Loss: {analysis_result.sl}")
        print(f"  Reasoning: {analysis_result.reasoning}")
        
    except Exception as e:
        print(f"Error analyzing trading signals: {str(e)}")

if __name__ == "__main__":
    main()
