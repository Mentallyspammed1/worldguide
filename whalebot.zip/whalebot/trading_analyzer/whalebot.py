import logging
import os
import requests
import pandas as pd
import numpy as np
from datetime import datetime
import hmac
import hashlib
import time
from dotenv import load_dotenv
from typing import Dict, Tuple, List, Union
from colorama import init, Fore, Style
from zoneinfo import ZoneInfo
from decimal import Decimal, getcontext
import json
from analyze_trading_bot_output import SignalAnalyzer
  
getcontext().prec = 10
init(autoreset=True)
load_dotenv()

API_KEY = os.getenv("BYBIT_API_KEY")
API_SECRET = os.getenv("BYBIT_API_SECRET")
if not API_KEY or not API_SECRET:
    raise ValueError("BYBIT_API_KEY and BYBIT_API_SECRET must be set in .env")
BASE_URL = os.getenv("BYBIT_BASE_URL", "https://api.bybit.com")

CONFIG_FILE = "config.json"
LOG_DIRECTORY = "bot_logs"
TIMEZONE = ZoneInfo("America/Chicago")
MAX_API_RETRIES = 3
RETRY_DELAY_SECONDS = 5
VALID_INTERVALS = ["1", "3", "5", "15", "30", "60", "120", "240", "D", "W", "M"]
RETRY_ERROR_CODES = [429, 500, 502, 503, 504]

NEON_GREEN = Fore.LIGHTGREEN_EX
NEON_BLUE = Fore.CYAN
NEON_PURPLE = Fore.MAGENTA
NEON_YELLOW = Fore.YELLOW
NEON_RED = Fore.LIGHTRED_EX
RESET = Style.RESET_ALL

os.makedirs(LOG_DIRECTORY, exist_ok=True)

def load_config(filepath: str) -> dict:
    default_config = {
        "interval": "15",
        "analysis_interval": 30,
        "retry_delay": 5,
        "momentum_period": 10,
        "momentum_ma_short": 12,
        "momentum_ma_long": 26,
        "volume_ma_period": 20,
        "atr_period": 14,
        "trend_strength_threshold": 0.4,
        "sideways_atr_multiplier": 1.5,
        "indicators": {
            "ema_alignment": True,
            "momentum": True,
            "volume_confirmation": True,
            "divergence": True,
            "stoch_rsi": True,
            "rsi": False,
            "macd": False,
        },
        "weight_sets": {
            "low_volatility": {
                "ema_alignment": 0.4,
                "momentum": 0.3,
                "volume_confirmation": 0.2,
                "divergence": 0.1,
                "stoch_rsi": 0.7,
                "rsi": 0.0,
                "macd": 0.0,
            },
        },
    }
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            config = json.load(f)
        config = {**default_config, **config}
    except (FileNotFoundError, json.JSONDecodeError):
        print(f"{NEON_YELLOW}Could not load or parse config. Loading defaults.{RESET}")
        config = default_config
    return config

CONFIG = load_config(CONFIG_FILE)

def setup_logger(symbol: str) -> logging.Logger:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = os.path.join(LOG_DIRECTORY, f"{symbol}_{timestamp}.log")
    logger = logging.getLogger(symbol)
    logger.setLevel(logging.INFO)
    file_handler = logging.FileHandler(log_filename)
    file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    logger.addHandler(file_handler)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(logging.Formatter(NEON_BLUE + "%(asctime)s" + RESET + " - %(levelname)s - %(message)s"))
    logger.addHandler(stream_handler)
    return logger

def generate_signature(params: dict) -> str:
    param_str = "&".join(f"{key}={value}" for key, value in sorted(params.items()))
    return hmac.new(API_SECRET.encode(), param_str.encode(), hashlib.sha256).hexdigest()

def fetch_current_price(symbol: str, logger: logging.Logger) -> Union[Decimal, None]:
    endpoint = "/v5/market/tickers"
    params = {"category": "linear", "symbol": symbol}
    response = bybit_request("GET", endpoint, params, logger)
    if not response or response.get("retCode") != 0 or not response.get("result") or not response["result"].get("list"):
        logger.error(f"{NEON_RED}Failed to fetch ticker data: {response}{RESET}")
        return None
    tickers = response["result"]["list"]
    ticker = next((t for t in tickers if t.get("symbol") == symbol), None)
    if not ticker:
        logger.error(f"{NEON_RED}Symbol {symbol} not found in ticker data{RESET}")
        return None
    last_price_str = ticker.get("lastPrice")
    if not last_price_str:
        logger.error(f"{NEON_RED}No lastPrice in ticker data{RESET}")
        return None
    try:
        return Decimal(last_price_str)
    except Exception as e:
        logger.error(f"{NEON_RED}Error parsing last price: {e}{RESET}")
        return None

def safe_json_response(response: requests.Response, logger: logging.Logger = None) -> Union[dict, None]:
    try:
        return response.json()
    except ValueError:
        if logger:
            logger.error(f"{NEON_RED}Invalid JSON response: {response.text}{RESET}")
        return None

def bybit_request(method: str, endpoint: str, params: dict = None, logger: logging.Logger = None) -> Union[dict, None]:
    for retry in range(MAX_API_RETRIES):
        try:
            params = params or {}
            timestamp = str(int(datetime.now(TIMEZONE).timestamp() * 1000))
            signature_params = {**params, 'timestamp': timestamp, 'api_key': API_KEY}
            signature = generate_signature(signature_params)
            headers = {
                "X-BAPI-API-KEY": API_KEY,
                "X-BAPI-TIMESTAMP": timestamp,
                "X-BAPI-SIGN": signature,
                "Content-Type": "application/json"
            }
            url = f"{BASE_URL}{endpoint}"
            request_kwargs = {'method': method, 'url': url, 'headers': headers, 'timeout': 10}
            if method == "GET":
                request_kwargs['params'] = params
            elif method == "POST":
                request_kwargs['json'] = params
            response = requests.request(**request_kwargs)
            if response.status_code == 200:
                json_response = safe_json_response(response, logger)
                if json_response:
                    return json_response
                else:
                    if logger:
                        logger.error(f"{NEON_RED}Empty or invalid JSON response: {response.text}{RESET}")
                    return None
            elif response.status_code in RETRY_ERROR_CODES:
                if logger:
                    logger.warning(f"{NEON_YELLOW}Rate limited or server error. Retrying {retry + 1}/{MAX_API_RETRIES} after {RETRY_DELAY_SECONDS * (2**retry)} seconds...{RESET}")
                time.sleep(RETRY_DELAY_SECONDS * (2**retry))
            else:
                if logger:
                    logger.error(f"{NEON_RED}Bybit API error: {response.status_code} - {response.text}{RESET}")
                return None
        except requests.exceptions.RequestException as e:
            if logger:
                logger.error(f"{NEON_RED}API request failed: {e}{RESET}")
            time.sleep(RETRY_DELAY_SECONDS * (2**retry))
    if logger:
        logger.error(f"{NEON_RED}Max retries exceeded for endpoint: {endpoint}{RESET}")
    return None

def fetch_klines(symbol: str, interval: str, limit: int = 200, logger: logging.Logger = None) -> pd.DataFrame:
    try:
        endpoint = "/v5/market/kline"
        params = {"symbol": symbol, "interval": interval, "limit": limit, "category": "linear"}
        response = bybit_request("GET", endpoint, params, logger)
        if not response or response.get("retCode") != 0 or not response.get("result") or not response["result"].get("list"):
            if logger:
                logger.error(f"{NEON_RED}Failed to fetch klines: {response}{RESET}")
            return pd.DataFrame()
        data = response["result"]["list"]
        columns = ["start_time", "open", "high", "low", "close", "volume", "turnover"]
        df = pd.DataFrame(data, columns=columns[:len(data[0])])
        df["start_time"] = pd.to_numeric(df["start_time"])
        df["start_time"] = pd.to_datetime(df["start_time"], unit="ms")
        for col in ["open", "high", "low", "close", "volume", "turnover"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")
        return df
    except Exception as e:
        if logger:
            logger.exception(f"{NEON_RED}Error fetching klines: {e}{RESET}")
        return pd.DataFrame()

class TradingAnalyzer:
    def __init__(self, df: pd.DataFrame, logger: logging.Logger, config: dict, symbol: str, interval: str):
        self.df = df.copy()
        self.logger = logger
        self.levels = {}
        self.fib_levels = {}
        self.config = config
        self.signal = None
        self.weight_sets = config["weight_sets"]
        self.user_defined_weights = self.weight_sets["low_volatility"]
        self.symbol = symbol
        self.interval = interval
        self.indicator_df = pd.DataFrame(index=self.df.index)

    def calculate_sma(self, window: int) -> pd.Series:
        try:
            return self.df["close"].rolling(window=window).mean()
        except KeyError as e:
            self.logger.error(f"{NEON_RED}Missing 'close' column for SMA calculation: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_ema(self, window: int) -> pd.Series:
        try:
            return self.df["close"].ewm(span=window, adjust=False).mean()
        except KeyError as e:
            self.logger.error(f"{NEON_RED}Missing 'close' column for EMA calculation: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_momentum(self, period: int = 10) -> pd.Series:
        try:
            return ((self.df["close"] - self.df["close"].shift(period)) / self.df["close"].shift(period)) * 100
        except (KeyError, ZeroDivisionError) as e:
            self.logger.error(f"{NEON_RED}Momentum calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_rsi(self, window: int = 14) -> pd.Series:
        try:
            delta = self.df["close"].diff()
            gain = delta.where(delta > 0, 0)
            loss = -delta.where(delta < 0, 0)
            avg_gain = gain.rolling(window=window, min_periods=1).mean()
            avg_loss = loss.rolling(window=window, min_periods=1).mean()
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            return rsi
        except (KeyError, ZeroDivisionError) as e:
            self.logger.error(f"{NEON_RED}RSI calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_stoch_rsi(self, rsi_window: int = 14, stoch_window: int = 14, k_window: int = 3, d_window: int = 3) -> pd.DataFrame:
        try:
            rsi = self.calculate_rsi(window=rsi_window)
            stoch_rsi = (rsi - rsi.rolling(stoch_window).min()) / (rsi.rolling(stoch_window).max() - rsi.rolling(stoch_window).min()) * 100
            k_line = stoch_rsi.rolling(window=k_window).mean()
            d_line = k_line.rolling(window=d_window).mean()
            return pd.DataFrame({"stoch_rsi": stoch_rsi, "k": k_line, "d": d_line}, index=self.df.index)
        except (KeyError, ZeroDivisionError) as e:
            self.logger.error(f"{NEON_RED}Stochastic RSI calculation error: {e}{RESET}")
            return pd.DataFrame()

    def calculate_macd(self) -> pd.DataFrame:
        try:
            ema_short = self.calculate_ema(12)
            ema_long = self.calculate_ema(26)
            macd_line = ema_short - ema_long
            signal_line = macd_line.ewm(span=9, adjust=False).mean()
            histogram = macd_line - signal_line
            return pd.DataFrame({"macd": macd_line, "signal": signal_line, "histogram": histogram}, index=self.df.index)
        except KeyError:
            self.logger.error(f"{NEON_RED}Missing 'close' column for MACD calculation.{RESET}")
            return pd.DataFrame()

    def calculate_atr(self, window: int = 14) -> pd.Series:
        try:
            tr1 = self.df["high"] - self.df["low"]
            tr2 = abs(self.df["high"] - self.df["close"].shift())
            tr3 = abs(self.df["low"] - self.df["close"].shift())
            tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
            atr = tr.rolling(window=window, min_periods=1).mean()
            return atr
        except KeyError as e:
            self.logger.error(f"{NEON_RED}ATR calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_cci(self, window: int = 20, constant: float = 0.015) -> pd.Series:
        try:
            typical_price = (self.df["high"] + self.df["low"] + self.df["close"]) / 3
            sma_typical_price = typical_price.rolling(window=window).mean()
            mean_deviation = (typical_price - sma_typical_price).abs().rolling(window=window).mean()
            cci = (typical_price - sma_typical_price) / (constant * mean_deviation)
            return cci
        except (KeyError, ZeroDivisionError) as e:
            self.logger.error(f"{NEON_RED}CCI calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_williams_r(self, window: int = 14) -> pd.Series:
        try:
            highest_high = self.df["high"].rolling(window=window).max()
            lowest_low = self.df["low"].rolling(window=window).min()
            wr = (highest_high - self.df["close"]) / (highest_high - lowest_low) * -100
            return wr
        except KeyError as e:
            self.logger.error(f"{NEON_RED}Williams %R calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_mfi(self, window: int = 14) -> pd.Series:
        try:
            typical_price = (self.df["high"] + self.df["low"] + self.df["close"]) / 3
            money_flow = typical_price * self.df["volume"]
            positive_money_flow = money_flow.where(typical_price > typical_price.shift(), 0)
            negative_money_flow = money_flow.where(typical_price < typical_price.shift(), 0).abs()
            positive_mf_sum = positive_money_flow.rolling(window=window, min_periods=1).sum()
            negative_mf_sum = negative_money_flow.rolling(window=window, min_periods=1).sum()
            money_ratio = positive_mf_sum / negative_mf_sum
            mfi = 100 - (100 / (1 + money_ratio))
            return mfi
        except KeyError as e:
            self.logger.error(f"{NEON_RED}MFI calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_obv(self) -> pd.Series:
        try:
            obv = np.where(self.df["close"] > self.df["close"].shift(1), self.df["volume"],
                            np.where(self.df["close"] < self.df["close"].shift(1), -self.df["volume"], 0))
            return pd.Series(obv.cumsum(), index=self.df.index)
        except KeyError as e:
            self.logger.error(f"{NEON_RED}OBV calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_adi(self) -> pd.Series:
        try:
            money_flow_multiplier = ((self.df["close"] - self.df["low"]) - (self.df["high"] - self.df["close"])) / (self.df["high"] - self.df["low"])
            money_flow_volume = money_flow_multiplier * self.df["volume"]
            return money_flow_volume.cumsum()
        except (KeyError, ZeroDivisionError) as e:
            self.logger.error(f"{NEON_RED}ADI calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_psar(self, acceleration=0.02, max_acceleration=0.2) -> pd.Series:
        try:
            psar = pd.Series(index=self.df.index)
            psar.iloc[0] = self.df["low"].iloc[0]
            trend = 1
            ep = self.df["high"].iloc[0]
            af = acceleration

            for i in range(1, len(self.df)):
                if trend == 1:
                    psar.iloc[i] = psar.iloc[i-1] + af * (ep - psar.iloc[i-1])
                    if self.df["high"].iloc[i] > ep:
                        ep = self.df["high"].iloc[i]
                        af = min(af + acceleration, max_acceleration)
                    if self.df["low"].iloc[i] < psar.iloc[i]:
                        trend = -1
                        psar.iloc[i] = ep
                        ep = self.df["low"].iloc[i]
                        af = acceleration
                elif trend == -1:
                    psar.iloc[i] = psar.iloc[i-1] + af * (ep - psar.iloc[i-1])
                    if self.df["low"].iloc[i] < ep:
                        ep = self.df["low"].iloc[i]
                        af = min(af + acceleration, max_acceleration)
                    if self.df["high"].iloc[i] > psar.iloc[i]:
                        trend = 1
                        psar.iloc[i] = ep
                        ep = self.df["high"].iloc[i]
                        af = acceleration
            return psar
        except KeyError as e:
            self.logger.error(f"{NEON_RED}PSAR calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_fve(self) -> pd.Series:
        try:
            force = self.df["close"].diff() * self.df["volume"]
            return force.cumsum()
        except KeyError as e:
            self.logger.error(f"{NEON_RED}FVE calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_momentum_ma(self) -> None:
        try:
            momentum_period = self.config.get("momentum_period", 10)
            momentum_ma_short_period = self.config.get("momentum_ma_short", 12)
            momentum_ma_long_period = self.config.get("momentum_ma_long", 26)
            volume_ma_period = self.config.get("volume_ma_period", 20)

            self.indicator_df["momentum"] = self.df["close"].diff(momentum_period)
            self.indicator_df["momentum_ma_short"] = self.indicator_df["momentum"].rolling(window=momentum_ma_short_period).mean()
            self.indicator_df["momentum_ma_long"] = self.indicator_df["momentum"].rolling(window=momentum_ma_long_period).mean()
            self.indicator_df["volume_ma"] = self.df["volume"].rolling(window=volume_ma_period).mean()
        except KeyError as e:
            self.logger.error(f"{NEON_RED}Momentum/MA calculation error: Missing column {e}{RESET}")

    def determine_trend_momentum(self) -> dict:
        if self.indicator_df.empty or not all(col in self.indicator_df.columns for col in ["momentum", "momentum_ma_short", "momentum_ma_long", "volume_ma"]):
            self.logger.warning(f"{NEON_YELLOW}Missing momentum indicators. Cannot determine trend.{RESET}")
            return {"trend": "Sideways", "strength": 0.0}

        last_row = self.indicator_df.iloc[-1]
        momentum = last_row["momentum"]
        momentum_ma_short = last_row["momentum_ma_short"]
        momentum_ma_long = last_row["momentum_ma_long"]
        volume_ma = last_row["volume_ma"]

        trend = "Sideways"
        strength = 0.0

        if momentum_ma_short > momentum_ma_long and momentum > 0 and self.df["volume"].iloc[-1] > volume_ma:
            trend = "Uptrend"
            strength = abs(momentum_ma_short - momentum_ma_long) / momentum_ma_long
        elif momentum_ma_short < momentum_ma_long and momentum < 0 and self.df["volume"].iloc[-1] > volume_ma:
            trend = "Downtrend"
            strength = abs(momentum_ma_short - momentum_ma_long) / momentum_ma_long

        return {"trend": trend, "strength": strength}

    def generate_analysis_output(self) -> str:
        """Generates the analysis output string based on calculated indicators and trend."""
        self.calculate_momentum_ma()
        trend_data = self.determine_trend_momentum()
        trend = trend_data["trend"]
        strength = trend_data["strength"]
        atr_series = self.calculate_atr(window=self.config.get("atr_period", 14))

        # Check if ATR series is empty or contains only NaN values
        if atr_series.empty or atr_series.isnull().all():
            atr = 0.0  # Or some other appropriate default value
            self.logger.warning(f"{NEON_YELLOW}ATR is empty or contains only NaN values. Using default ATR value of 0.0.{RESET}")
        else:
            atr = atr_series.iloc[-1]

        current_price = fetch_current_price(self.symbol, self.logger)
        if current_price is None:
            current_price_str = "N/A"
        else:
            current_price_str = str(current_price)

        output = f"Symbol: {self.symbol}\n"
        output += f"Interval: {self.interval}\n"
        output += f"Trend: {trend} Strength: {strength:.2f}\n"
        output += f"Current Price: {current_price_str}\n"
        output += f"ATR: {atr:.2f}\n"

        # Calculate and include other indicators based on your configuration
        if self.config["indicators"]["rsi"]:
            rsi = self.calculate_rsi().iloc[-1]
            output += f"RSI: {rsi:.2f}\n"

        if self.config["indicators"]["stoch_rsi"]:
            stoch_rsi_df = self.calculate_stoch_rsi()
            if not stoch_rsi_df.empty:
                stoch_rsi = stoch_rsi_df["stoch_rsi"].iloc[-1]
                k = stoch_rsi_df["k"].iloc[-1]
                d = stoch_rsi_df["d"].iloc[-1]
                output += f"Stoch RSI: {stoch_rsi:.2f}, K: {k:.2f}, D: {d:.2f}\n"
            else:
                output += "Stoch RSI: N/A\n"

        if self.config["indicators"]["macd"]:
            macd_df = self.calculate_macd()
            if not macd_df.empty:
                macd = macd_df["macd"].iloc[-1]
                signal = macd_df["signal"].iloc[-1]
                histogram = macd_df["histogram"].iloc[-1]
                output += f"MACD: {macd:.2f}, Signal: {signal:.2f}, Histogram: {histogram:.2f}\n"
            else:
                output += "MACD: N/A\n"

        cci = self.calculate_cci().iloc[-1]
        output += f"CCI: {cci:.2f}\n"

        wr = self.calculate_williams_r().iloc[-1]
        output += f"Williams %R: {wr:.2f}\n"

        mfi = self.calculate_mfi().iloc[-1]
        output += f"MFI: {mfi:.2f}\n"

        obv = self.calculate_obv().iloc[-1]
        output += f"OBV: {obv:.2f}\n"

        adi = self.calculate_adi().iloc[-1]
        output += f"ADI: {adi:.2f}\n"

        psar = self.calculate_psar().iloc[-1]
        output += f"PSAR: {psar:.2f}\n"

        fve = self.calculate_fve().iloc[-1]
        output += f"FVE: {fve:.2f}\n"

        return output

def main():
    symbol = input("Enter the trading symbol (e.g., BTCUSDT): ").upper()
    interval = input(f"Enter the interval ({', '.join(VALID_INTERVALS)}): ").upper()

    if interval not in VALID_INTERVALS:
        print(f"{NEON_RED}Invalid interval. Please choose from: {', '.join(VALID_INTERVALS)}{RESET}")
        return

    logger = setup_logger(symbol)
    logger.info(f"Starting analysis for {symbol} with interval {interval}")

    df = fetch_klines(symbol, interval, limit=200, logger=logger)
    if df.empty:
        logger.error(f"{NEON_RED}No data fetched for {symbol}. Exiting.{RESET}")
        return

    analyzer = TradingAnalyzer(df, logger, CONFIG, symbol, interval)
    analysis_output = analyzer.generate_analysis_output()
    print("\n--- Technical Analysis Output ---")
    print(analysis_output)
    logger.info(analysis_output)
    print("--- Technical Analysis Complete ---")

    # Get the log file path from the user
    log_file_path = input("Enter the path to the log file from the other bot: ")

    try:
        with open(log_file_path, 'r') as f:
            other_bot_output = f.read()
    except FileNotFoundError:
        print(f"Error: File not found at path: {log_file_path}")
        return
    except Exception as e:
        print(f"Error reading file: {e}")
        return

    # Analyze the output from the other bot
    other_bot_analysis_result = analyze_output_text(other_bot_output)

    print("\n--- Analysis from Other Bot ---")
    print(f"  Signal: {other_bot_analysis_result['signal']}")
    print(f"  Confidence: {other_bot_analysis_result['confidence']}")
    print(f"  Take Profit: {other_bot_analysis_result['tp']}")
    print(f"  Stop Loss: {other_bot_analysis_result['sl']}")
    print(f"  Reasoning: {other_bot_analysis_result['reasoning']}")
    print("--- Other Bot Analysis Complete ---")
    logger.info(f"Other Bot Analysis: {other_bot_analysis_result}")  # Log the other bot's analysis

if __name__ == "__main__":
    main()
