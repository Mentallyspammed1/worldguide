"""Main signal analysis logic."""
import re
from typing import Dict, List, Optional
from models import AnalysisResult, TradingIndicators, PriceLevel
from constants import (
    TREND_KEYWORDS, TREND_CONFIRMATION_SCORE,
    INDICATOR_CONFIRMATION_SCORE, MAX_CONFIDENCE,
    TP_ATR_MULTIPLIER, SL_ATR_MULTIPLIER
)

class SignalAnalyzer:
    @staticmethod
    def parse_price_level(line: str, prefix: str) -> Optional[PriceLevel]:
        """Parse a price level line into a PriceLevel object."""
        try:
            label = line.split("$")[0].split(":")[1].strip()
            price = float(line.split("$")[1].strip())
            return PriceLevel(label=label, price=price)
        except (IndexError, ValueError):
            print(f"Warning: Could not parse {prefix} level from line: {line}")
            return None

    @staticmethod
    def parse_indicators(lines: List[str]) -> TradingIndicators:
        """Parse raw text lines into structured indicator data."""
        indicators: Dict[str, str] = {}
        trend = ""
        strength = 0.0
        support_levels: List[PriceLevel] = []
        resistance_levels: List[PriceLevel] = []
        current_price = 0.0
        atr = 0.0

        for line in lines:
            line = line.strip()
            
            if line.startswith("Trend:"):
                parts = line.split(":")
                trend = parts[1].strip().split(" ")[0]
                match = re.search(r"Strength: ([\d.]+)", parts[1])
                strength = float(match.group(1)) if match else 0.0
            
            elif ":" in line:
                indicator_name, value = line.split(":", 1)
                indicator_name = indicator_name.lower().strip()
                
                if indicator_name == "current price":
                    try:
                        current_price = float(value.strip())
                    except ValueError:
                        print(f"Warning: Could not parse current price from line: {line}")
                elif indicator_name == "atr":
                    try:
                        atr = float(value.strip())
                    except ValueError:
                        print(f"Warning: Could not parse ATR from line: {line}")
                elif line.startswith("S:"):
                    level = SignalAnalyzer.parse_price_level(line, "support")
                    if level:
                        support_levels.append(level)
                elif line.startswith("R:"):
                    level = SignalAnalyzer.parse_price_level(line, "resistance")
                    if level:
                        resistance_levels.append(level)
                else:
                    indicators[indicator_name] = value.strip()

        return TradingIndicators(
            trend=trend,
            strength=strength,
            indicators=indicators,
            current_price=current_price,
            atr=atr,
            support_levels=support_levels,
            resistance_levels=resistance_levels
        )

    def analyze_signals(self, trading_data: TradingIndicators) -> AnalysisResult:
        """Analyze trading signals and generate trading recommendations."""
        signal = "Neutral"
        confidence = 0.0
        tp = None
        sl = None
        signal_reasoning = []

        # Analysis logic for uptrend
        if self._is_confirmed_uptrend(trading_data):
            signal, confidence, signal_reasoning = self._analyze_uptrend(trading_data)
            tp, sl = self._calculate_levels(
                trading_data, is_long=True
            )

        # Analysis logic for downtrend
        elif self._is_confirmed_downtrend(trading_data):
            signal, confidence, signal_reasoning = self._analyze_downtrend(trading_data)
            tp, sl = self._calculate_levels(
                trading_data, is_long=False
            )

        confidence = min(MAX_CONFIDENCE, confidence)
        
        return AnalysisResult(
            signal=signal,
            confidence=confidence,
            tp=tp,
            sl=sl,
            reasoning=", ".join(signal_reasoning) or "Neutral market conditions or conflicting indicators."
        )

    def _is_confirmed_uptrend(self, data: TradingIndicators) -> bool:
        """Check if there's a confirmed uptrend."""
        return (
            data.trend == "Uptrend" and 
            data.indicators.get("adx", "").find("Trending") != -1
        )

    def _is_confirmed_downtrend(self, data: TradingIndicators) -> bool:
        """Check if there's a confirmed downtrend."""
        return (
            data.trend == "Downtrend" and 
            data.indicators.get("adx", "").find("Trending") != -1
        )

    def _analyze_uptrend(self, data: TradingIndicators) -> tuple:
        """Analyze uptrend signals."""
        signal = "Long"
        confidence = TREND_CONFIRMATION_SCORE
        reasoning = ["Uptrend confirmed by ADX"]
        
        for indicator, keywords in TREND_KEYWORDS['BULLISH'].items():
            if any(kw in data.indicators.get(indicator, "") for kw in keywords):
                confidence += INDICATOR_CONFIRMATION_SCORE
                reasoning.append(f"{indicator.upper()} {keywords[0]}")
                
        return signal, confidence, reasoning

    def _analyze_downtrend(self, data: TradingIndicators) -> tuple:
        """Analyze downtrend signals."""
        signal = "Short"
        confidence = TREND_CONFIRMATION_SCORE
        reasoning = ["Downtrend confirmed by ADX"]
        
        for indicator, keywords in TREND_KEYWORDS['BEARISH'].items():
            if any(kw in data.indicators.get(indicator, "") for kw in keywords):
                confidence += INDICATOR_CONFIRMATION_SCORE
                reasoning.append(f"{indicator.upper()} {keywords[0]}")
                
        return signal, confidence, reasoning

    def _calculate_levels(self, data: TradingIndicators, is_long: bool) -> tuple:
        """Calculate take profit and stop loss levels."""
        if is_long:
            tp = self._calculate_long_tp(data)
            sl = self._calculate_long_sl(data)
        else:
            tp = self._calculate_short_tp(data)
            sl = self._calculate_short_sl(data)
        
        return tp, sl

    def _calculate_long_tp(self, data: TradingIndicators) -> str:
        nearest_resistance = next(
            (level for level in data.resistance_levels if level.price > data.current_price),
            None
        )
        if nearest_resistance:
            return f"{nearest_resistance.price:.2f}"
        return f"{data.current_price + TP_ATR_MULTIPLIER * data.atr:.2f}"

    def _calculate_long_sl(self, data: TradingIndicators) -> str:
        nearest_support = next(
            (level for level in data.support_levels if level.price < data.current_price),
            None
        )
        if nearest_support:
            return f"{nearest_support.price:.2f}"
        return f"{data.current_price - SL_ATR_MULTIPLIER * data.atr:.2f}"
