import os
import time
import datetime
import logging
import sys
from dotenv import load_dotenv
from pybit.unified_trading import HTTP
from colorama import Fore, Style, init
import pandas as pd
import numpy as np
import asyncio

# Initialize colorama
init(autoreset=True)

# --- Neon Color Definitions ---
class Neon:
    GREEN = Fore.GREEN + Style.BRIGHT
    CYAN = Fore.CYAN + Style.BRIGHT
    MAGENTA = Fore.MAGENTA + Style.BRIGHT
    YELLOW = Fore.YELLOW + Style.BRIGHT
    RED = Fore.RED + Style.BRIGHT
    BLUE = Fore.BLUE + Style.BRIGHT
    WHITE = Fore.WHITE + Style.BRIGHT
    RESET = Style.RESET_ALL

# --- Configuration ---
load_dotenv()
API_KEY = os.getenv("BYBIT_API_KEY")
API_SECRET = os.getenv("BYBIT_API_SECRET")
TESTNET = os.getenv("TESTNET", "false").lower() == "true"

# Input validation with colored prompts and error messages
while True:
    SYMBOL = input(f"{Neon.CYAN}Enter the trading symbol (e.g., BTCUSDT): {Neon.RESET}").upper().strip()
    if SYMBOL:
        break
    else:
        print(f"{Neon.RED}Symbol cannot be empty.{Neon.RESET}")

while True:
    try:
        TIMEFRAME = int(input(f"{Neon.CYAN}Enter the timeframe in minutes (e.g., 1, 5, 15): {Neon.RESET}"))
        if TIMEFRAME > 0:
            break
        else:
            print(f"{Neon.RED}Timeframe must be positive.{Neon.RESET}")
    except ValueError:
        print(f"{Neon.RED}Invalid input. Please enter a number.{Neon.RESET}")

# Default values and type conversions for environment variables, with error handling
try:
    RISK_PER_TRADE = float(os.getenv("RISK_PER_TRADE", 0.01))
    LOOKBACK_PERIOD = int(os.getenv("LOOKBACK_PERIOD", 100))  # For identifying zones
    ZONE_CONFIRMATION_PERIODS = int(os.getenv("ZONE_CONFIRMATION_PERIODS", 10))
    ZONE_PROXIMITY_PERCENT = float(os.getenv("ZONE_PROXIMITY_PERCENT", 0.01))
    REWARD_RISK_RATIO = float(os.getenv("REWARD_RISK_RATIO", 1.0))
    ORDER_CANCEL_DELAY = int(os.getenv("ORDER_CANCEL_DELAY", 30))
    STOCH_RSI_K = int(os.getenv("STOCH_RSI_K", 3))
    STOCH_RSI_D = int(os.getenv("STOCH_RSI_D", 3))
    STOCH_RSI_PERIOD = int(os.getenv("STOCH_RSI_PERIOD", 14))
    VOLUME_THRESHOLD = float(os.getenv("VOLUME_THRESHOLD", 1.5))
    MIN_ZONE_WIDTH_PERCENT = float(os.getenv("MIN_ZONE_WIDTH_PERCENT", 0.005)) # New parameter
except (TypeError, ValueError) as e:
    print(f"{Neon.RED}Error reading environment variables: {e}.  Please ensure they are set correctly.{Neon.RESET}")
    sys.exit(1)  # Exit if essential configuration is invalid

LOG_DIR = "logs"
MAX_RETRIES = 3
RETRY_DELAY = 5

# --- Logger Setup ---
def setup_logger(symbol, log_dir):
    """Sets up the logger for the trading bot."""
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_filename = os.path.join(log_dir, f"{symbol}_{timestamp}.log")  # Changed to .log
    logger = logging.getLogger(symbol)
    logger.setLevel(logging.DEBUG)
    file_handler = logging.FileHandler(log_filename)
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG)

    class ColorFormatter(logging.Formatter):
        def format(self, record):
            log_message = super().format(record)
            if record.levelno == logging.WARNING:
                return f"{Neon.YELLOW}{log_message}{Neon.RESET}"
            elif record.levelno == logging.ERROR:
                return f"{Neon.RED}{log_message}{Neon.RESET}"
            elif record.levelno == logging.CRITICAL:
                return f"{Neon.RED}{Style.BRIGHT}{log_message}{Neon.RESET}"
            elif record.levelno == logging.DEBUG:
                return f"{Neon.CYAN}{log_message}{Neon.RESET}"
            else:
                return f"{Neon.GREEN}{log_message}{Neon.RESET}"
    console_formatter = ColorFormatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    return logger

logger = setup_logger(SYMBOL, LOG_DIR)

# --- Session Creation ---
def create_session():
    """Creates a Bybit API session."""
    try:
        return HTTP(testnet=TESTNET, api_key=API_KEY, api_secret=API_SECRET)
    except Exception as e:
        logger.critical(f"Failed to create Bybit session: {e}", exc_info=True)
        sys.exit(1)

session = create_session()

# --- Data Fetching ---
def get_historical_data(symbol, timeframe, periods):
    """Fetches historical kline data from Bybit with explicit error handling."""
    try:
        now = int(time.time() * 1000)
        since = now - (timeframe * 60 * 1000 * periods)
        result = session.get_kline(symbol=symbol, interval=str(timeframe), start=since, category="linear")
        if result['retCode'] == 0:
            klines = result['result']['list']
            # Explicitly handle potential errors with column names
            try:
                columns = ['startTime', 'open', 'high', 'low', 'close', 'volume', 'turnover']
                df = pd.DataFrame(klines, columns=columns)
                # Check if 'volume' column exists after DataFrame creation
                if 'volume' not in df.columns:
                    logger.error("Volume column is missing in klines DataFrame.")
                    return pd.DataFrame()  # Return an empty DataFrame
                return df
            except KeyError as e:
                logger.error(f"KeyError creating DataFrame: {e}")
                return pd.DataFrame()  # Return an empty DataFrame
            except Exception as e:
                logger.error(f"Error creating DataFrame: {e}")
                return pd.DataFrame()  # Return an empty DataFrame
        else:
            logger.error(f"Error fetching historical data: {result['retMsg']}")
            return pd.DataFrame()  # Return an empty DataFrame
    except Exception as e:
        logger.error(f"Error fetching kline data: {e}", exc_info=True)
        return pd.DataFrame()  # Return an empty DataFrame


def get_current_price(symbol):
    """Gets the current price of the specified symbol."""
    try:
        result = session.get_tickers(symbol=symbol, category="linear")
        if result and result['retCode'] == 0:
            return float(result['result']['list'][0]['lastPrice'])
        logger.error(f"Could not get price: {result.get('retMsg', 'Unknown error')}")
        return None
    except Exception as e:
        logger.error(f"Error getting price: {e}", exc_info=True)
        return None

# --- Indicator Calculations ---
def calculate_stoch_rsi(data, period, k_period, d_period):
    """Calculates Stochastic RSI."""
    if data.empty or len(data) < period + k_period + d_period: # Check for empty
        return None, None

    df = data.copy() # Work on copy
    df['close'] = pd.to_numeric(df['close'])
    df['rsi'] = calculate_rsi(df['close'], period)

    if df['rsi'].isnull().any():
        return None, None  # If there is an issue, then return

    df['lowest_rsi'] = df['rsi'].rolling(window=period).min()
    df['highest_rsi'] = df['rsi'].rolling(window=period).max()

    # Avoid Zero Division:
    mask = df['highest_rsi'] != df['lowest_rsi']
    df.loc[mask, 'stoch_rsi'] = 100 * (df.loc[mask, 'rsi'] - df.loc[mask, 'lowest_rsi']) / (df.loc[mask, 'highest_rsi'] - df.loc[mask, 'lowest_rsi'])
    df['stoch_rsi'] = df['stoch_rsi'].fillna(0)  # Cases where it is not calculated.

    df['stoch_rsi_k'] = df['stoch_rsi'].rolling(window=k_period).mean()
    df['stoch_rsi_d'] = df['stoch_rsi_k'].rolling(window=d_period).mean()
    return df['stoch_rsi_k'].iloc[-1], df['stoch_rsi_d'].iloc[-1]

def calculate_rsi(data, period):
    """Calculates the Relative Strength Index (RSI)."""
    delta = data.diff()
    gain = (delta.where(delta > 0, 0)).fillna(0)
    loss = (-delta.where(delta < 0, 0)).fillna(0)

    avg_gain = gain.rolling(window=period, min_periods=1).mean()
    avg_loss = loss.rolling(window=period, min_periods=1).mean()

    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def calculate_average_volume(data, volume_period=20):
    """Calculates average volume."""
    if data.empty or len(data) < volume_period: # Check for empty
        return 0
    df = data.copy() # Work on copy.

    if 'volume' not in df.columns:
        logger.error("Volume column is missing in average volume calc")
        return 0
    df['volume'] = df['volume'].astype(float)
    return df['volume'].tail(volume_period).mean()

# --- Supply and Demand Zone Identification ---
def identify_supply_demand_zones(data, confirmation_periods):
    """Identifies supply and demand zones.  Simplified Approach."""
    if data.empty or len(data) < confirmation_periods: # Check for empty
        return [], []
    df = data.copy() # Work on copy
    for col in ['open', 'high', 'low', 'close']:
        df[col] = pd.to_numeric(df[col])
    supply_zones, demand_zones = [], []

    for i in range(1, len(df) - confirmation_periods):
        # Simplified Demand Zone Detection (Base + Bullish Move)
        if (df['close'][i] > df['open'][i] and  # Bullish candle
            all(df['high'][i+j] > df['high'][i] for j in range(1, confirmation_periods))):  # price goes up

            demand_zones.append((df['low'][i], df['high'][i]))  # Zone = low of the candle to the high of candle
        # Simplified Supply Zone Detection (Base + Bullish Move)
        if (df['close'][i] < df['open'][i] and  # Bearish candle
            all(df['low'][i+j] < df['low'][i] for j in range(1, confirmation_periods))):  # Price goes down

            supply_zones.append((df['low'][i], df['high'][i]))  # Zone = low of the candle to the high of candle

    return supply_zones, demand_zones

# --- Trading Functions ---
def get_wallet_balance(coin="USDT"):
    """Gets the available balance."""
    for attempt in range(MAX_RETRIES):
        try:
            result = session.get_wallet_balance(accountType="UNIFIED", coin=coin)
            if result['retCode'] == 0:
                balance_data = result['result']['list'][0]['coin']
                for c in balance_data:
                    if c['coin'] == coin:
                        return float(c['availableToWithdraw'])
                return 0
            logger.warning(f"Failed to get balance: {result['retMsg']}. Retrying...")
        except Exception as e:
            logger.error(f"Error getting balance: {e}. Retrying...")
        time.sleep(RETRY_DELAY)
    logger.error(f"Failed to get balance after retries.")
    return None

async def place_order(symbol, side, order_type, qty, price=None, time_in_force="GoodTillCancel",
                reduce_only=False, close_on_trigger=False, stop_loss=None, take_profit=None):
    """Places an order."""
    for attempt in range(MAX_RETRIES):
        try:
            order_params = {
                "category": "linear",
                "symbol": symbol,
                "side": side,
                "orderType": order_type,
                "qty": str(qty),
                "timeInForce": time_in_force,
                "reduceOnly": reduce_only,
                "closeOnTrigger": close_on_trigger
            }
            if price:
                order_params['price'] = str(price)
            if stop_loss:
                order_params['stopLoss'] = str(stop_loss)
            if take_profit:
                order_params['takeProfit'] = str(take_profit)
            result = session.place_order(**order_params)
            if result['retCode'] == 0:
                logger.info(f"Order placed successfully: {result['result']}")
                return result['result']
            logger.warning(f"Failed to place order: {result['retMsg']}. Retrying...")
        except Exception as e:
            logger.error(f"Error placing order: {e}. Retrying...")
        await asyncio.sleep(RETRY_DELAY)
    logger.error(f"Failed to place order after retries.")
    return None

def cancel_order(order_id, symbol):
    """Cancels an existing order."""
    try:
        result = session.cancel_order(category="linear", symbol=symbol, orderId=order_id)
        if result['retCode'] == 0:
            logger.info(f"Order {order_id} cancelled successfully.")
            return True
        else:
            logger.warning(f"Failed to cancel order {order_id}: {result['retMsg']}.")
            return False
    except Exception as e:
        logger.error(f"Error cancelling order {order_id}: {e}")
        return False

def calculate_position_size(account_balance, risk_per_trade, entry_price, stop_loss_price):
    """Calculates position size."""
    if abs(entry_price - stop_loss_price) < 1e-6:  # Avoid division by near-zero
        logger.warning(f"Entry and stop prices are too close.")
        return 0

    risk_amount = account_balance * risk_per_trade
    price_difference = abs(entry_price - stop_loss_price)
    quantity = risk_amount / price_difference
    return quantity

def is_price_near_zone(price, zone, proximity_percent):
    """Checks if the price is within a certain percentage of a zone."""
    proximity = price * proximity_percent  # Proximity becomes current price
    lower_bound = min(zone) - proximity
    upper_bound = max(zone) + proximity
    return lower_bound <= price <= upper_bound

def color_code_zone(zone):
    """Returns a color-coded string representation of the zone."""
    return f"{Neon.GREEN}[{zone[0]:.5f}, {zone[1]:.5f}]{Neon.RESET}"  # Green for both

async def async_sleep(seconds):
    """Asynchronously sleeps for the specified number of seconds."""
    await asyncio.sleep(seconds)

# --- Main Strategy Loop ---
async def run_strategy():
    """Main strategy loop for the trading bot."""
    logger.info(f"Starting Supply/Demand Scalping strategy for {SYMBOL} on timeframe {TIMEFRAME}")
    in_position = False  # variable to store state if bot is trading
    current_side = None  # 'Buy' or 'Sell'
    open_order_id = None
    order_placed_time = None

    while True:
        try:
            klines = get_historical_data(SYMBOL, TIMEFRAME, LOOKBACK_PERIOD)
            if klines.empty: # Check for empty dataframe
                logger.warning(f"No kline data. Waiting...")
                await async_sleep(60)
                continue

            current_price = get_current_price(SYMBOL)
            if current_price is None:
                logger.warning(f"Could not get price. Waiting...")
                await async_sleep(60)
                continue
            # Indicator calculation
            stoch_rsi_k, stoch_rsi_d = calculate_stoch_rsi(klines, STOCH_RSI_PERIOD, STOCH_RSI_K, STOCH_RSI_D)
            average_volume = calculate_average_volume(klines)

            # Double-check before accessing 'volume'
            if 'volume' not in klines.columns:
                logger.error("Volume column is missing after get_historical_data")
                current_volume = 0  # Set to a default value
            else:
                current_volume = float(klines['volume'].iloc[-1])

            supply_zones, demand_zones = identify_supply_demand_zones(klines, ZONE_CONFIRMATION_PERIODS)
             # Remove very close zones:

            supply_zones = [(low, high) for low, high in supply_zones if high - low > MIN_ZONE_WIDTH_PERCENT * current_price]  # filter the zones where the price is less than 0.005
            demand_zones = [(low, high) for low, high in demand_zones if high - low > MIN_ZONE_WIDTH_PERCENT * current_price]

            # Sort nearest six by calculating distance with current price:
            supply_zones = sorted(supply_zones, key=lambda zone: abs(current_price - (zone[0]+zone[1])/2))[:6]
            demand_zones = sorted(demand_zones, key=lambda zone: abs(current_price - (zone[0]+zone[1])/2))[:6]

            # Output the nearest zones with color coding:
            logger.debug(f"Nearest Supply Zones: {[color_code_zone(zone) for zone in supply_zones]}")
            logger.debug(f"Nearest Demand Zones: {[color_code_zone(zone) for zone in demand_zones]}")

            # --- Trading Logic ---
            if not in_position:
                # Check for Demand Zone Entry
                for zone in demand_zones:
                    if (is_price_near_zone(current_price, zone, ZONE_PROXIMITY_PERCENT) and
                        stoch_rsi_k is not None and stoch_rsi_d is not None and stoch_rsi_k < stoch_rsi_d and  # Stoch RSI over sold.
                        current_volume > average_volume * VOLUME_THRESHOLD):  # volume is significant
                        account_balance = get_wallet_balance()
                        if account_balance is None:
                            logger.error(f"Could not retrieve account balance.")
                            break  # Exit zone check

                        entry_price = zone[1]  # Enter at the top of the demand zone
                        stop_loss_price = zone[0]  # Stop loss at the bottom
                        take_profit_price = entry_price + (entry_price - stop_loss_price) * REWARD_RISK_RATIO  # Take profit based on reward risk
                        position_size = calculate_position_size(account_balance, RISK_PER_TRADE, entry_price, stop_loss_price)

                        if position_size > 0:
                            order_result = await place_order(SYMBOL, "Buy", "Limit", position_size, price=entry_price, stop_loss=stop_loss_price, take_profit=take_profit_price)

                            if order_result:
                                in_position = True
                                current_side = "Buy"
                                open_order_id = order_result.get('orderId')  # Store to manage
                                order_placed_time = datetime.datetime.now()

                                logger.info(f"Placed Buy Limit Order at {entry_price}  Order ID: {open_order_id}")

                            break  # Exit zone check after placing an order
                # Check for Supply Zone Entry
                for zone in supply_zones:
                    if (is_price_near_zone(current_price, zone, ZONE_PROXIMITY_PERCENT) and
                        stoch_rsi_k is not None and stoch_rsi_d is not None and stoch_rsi_k > stoch_rsi_d and  # Stoch RSI Overbought
                        current_volume > average_volume * VOLUME_THRESHOLD):
                        account_balance = get_wallet_balance()
                        if account_balance is None:
                            logger.error(f"Could not retrieve account balance.")
                            break

                        entry_price = zone[0]  # Enter at the bottom of the supply zone
                        stop_loss_price = zone[1]  # Stop loss at the top
                        take_profit_price = entry_price - (stop_loss_price - entry_price) * REWARD_RISK_RATIO  # 2:1 Risk/Reward
                        position_size = calculate_position_size(account_balance, RISK_PER_TRADE, entry_price, stop_loss_price)
                        if position_size > 0:
                            order_result= await place_order(SYMBOL, "Sell", "Limit", position_size, price=entry_price, stop_loss=stop_loss_price, take_profit=take_profit_price)
                            if order_result:
                                in_position = True
                                current_side = "Sell"
                                open_order_id = order_result.get('orderId')
                                order_placed_time = datetime.datetime.now()

                                logger.info(f"Placed Sell Limit Order at {entry_price} Order ID: {open_order_id}")

                            break  # Exit zone check after placing an order

            # Check for Order Cancellation
            if open_order_id and order_placed_time:
                time_since_order = datetime.datetime.now() - order_placed_time
                if time_since_order.total_seconds() > ORDER_CANCEL_DELAY:
                    logger.info(f"Cancelling order {open_order_id} due to timeout.")
                    cancel_order(open_order_id, SYMBOL)
                    open_order_id = None
                    order_placed_time = None
                    in_position = False
                    current_side = None

        except Exception as e:
            logger.error(f"Main loop error: {e}", exc_info=True)

        await async_sleep(60)

if __name__ == "__main__":
    asyncio.run(run_strategy())
