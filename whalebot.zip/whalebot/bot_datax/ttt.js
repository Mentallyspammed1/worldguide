const fs = require('fs');
const axios = require('axios');
const dotenv = require('dotenv');

dotenv.config(); // Load environment variables from .env file  - IMPORTANT

// Configuration variables
const filePath = 'whalebot.txt';
const analysisInterval = 5000;
const stopLossMultiple = 2;
const baseConfidence = 3;
const confidenceBoostPerFactor = 2;
const rsiOversoldThreshold = 30;
const rsiOverboughtThreshold = 70;
const takeProfitMultiple = 1.5;
const orderBookVolumeRatioThreshold = 2; // Threshold for significant volume imbalance
const orderBookSpreadThresholdMultiplier = 0.5; // Threshold multiplier for spread based on ATR
const atrLookbackPeriod = 20; // Number of periods to calculate ATR - Improvement 1
const mfiOversoldThreshold = 20;
const mfiOverboughtThreshold = 80; // Add MFI thresholds for signal logic

/**
 * Analyzes a log file, extracts trading data, generates scalping signals, and
 * outputs the signals with stop loss, entry price, confidence level (1-10), and reasoning,
 * running in a loop.
 */
function startLogAnalysisLoop() {
    setInterval(() => {
        fs.readFile(filePath, 'utf8', async (err, data) => {
            if (err) {
                console.error(`Failed to read the file: ${filePath}`, err);
                return;
            }

            const cleanData = data.replace(/\x1b\[[0-9;]*m/g, '');
            const logEntries = cleanData.split(/(?=\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} - INFO -)/);

            const signals = [];
            let previousEntryData = null;
            let atrValues = []; // To store ATR values for lookback - Improvement 2

            for (const entry of logEntries) {
                if (!entry.trim()) continue;

                const lines = entry.split('\n');
                const entryData = {};

                for (const line of lines) {
                    const trimmedLine = line.trim();

                    if (trimmedLine.startsWith('Exchange:')) {
                        entryData.exchange = trimmedLine.substring('Exchange:'.length).trim();
                    } else if (trimmedLine.startsWith('Symbol:')) {
                        entryData.symbol = trimmedLine.substring('Symbol:'.length).trim();
                    } else if (trimmedLine.startsWith('Interval:')) {
                        entryData.interval = trimmedLine.substring('Interval:'.length).trim();
                    } else if (trimmedLine.startsWith('Timestamp:')) {
                        entryData.timestamp = trimmedLine.substring('Timestamp:'.length).trim();
                    } else if (trimmedLine.startsWith('Current Price:')) {
                        const priceStr = trimmedLine.substring('Current Price:'.length).trim();
                        entryData.currentPrice = parseFloat(priceStr);
                        if (isNaN(entryData.currentPrice)) {
                            console.warn(`Invalid Current Price found: ${priceStr}`);
                        }
                    } else if (trimmedLine.startsWith('ATR:')) {
                        const atrStr = trimmedLine.substring('ATR:'.length).trim();
                        entryData.atr = parseFloat(atrStr);
                        if (isNaN(entryData.atr)) {
                            console.warn(`Invalid ATR found: ${atrStr}`);
                        } else {
                            atrValues.push(entryData.atr); // Store ATR values for lookback
                            if (atrValues.length > atrLookbackPeriod) {
                                atrValues.shift(); // Keep only the last atrLookbackPeriod values - Improvement 2
                            }
                        }
                    } else if (trimmedLine.startsWith('Trend:')) {
                        entryData.trend = trimmedLine.substring('Trend:'.length).trim();
                    } else if (trimmedLine.startsWith('OBV:')) {
                        entryData.obv = trimmedLine.substring('OBV:'.length).trim();
                    } else if (trimmedLine.startsWith('RSI:')) {
                        const rsiStr = trimmedLine.substring('RSI:'.length).trim();
                        const rsiMatch = rsiStr.match(/\(([\d.]+)\)/);
                        if (rsiMatch && rsiMatch[1]) {
                            entryData.rsi = parseFloat(rsiMatch[1]);
                        } else {
                            entryData.rsi = rsiStr;
                        }
                    } else if (trimmedLine.startsWith('MFI:')) {
                        const mfiStr = trimmedLine.substring('MFI:'.length).trim();
                        const mfiMatch = mfiStr.match(/\(([\d.]+)\)/);
                        if (mfiMatch && mfiMatch[1]) {
                            entryData.mfi = parseFloat(mfiMatch[1]);
                        } else {
                            entryData.mfi = mfiStr;
                        }
                    } else if (trimmedLine.startsWith('CCI:')) {
                        const cciStr = trimmedLine.substring('CCI:'.length).trim();
                        const cciMatch = cciStr.match(/\(([-.\d]+)\)/);
                        if (cciMatch && cciMatch[1]) {
                            entryData.cci = parseFloat(cciMatch[1]);
                        } else {
                            entryData.cci = cciStr;
                        }
                    } else if (trimmedLine.startsWith('Williams %R:')) {
                        const williamsRStr = trimmedLine.substring('Williams %R:'.length).trim();
                        const williamsRMatch = williamsRStr.match(/\(([-.\d]+)\)/);
                        if (williamsRMatch && williamsRMatch[1]) {
                            entryData.williamsR = parseFloat(williamsRMatch[1]);
                        } else {
                            entryData.williamsR = williamsRStr;
                        }
                    } else if (trimmedLine.startsWith('ADX:')) {
                        const adxStr = trimmedLine.substring('ADX:'.length).trim();
                        const adxMatch = adxStr.match(/\(([\d.]+)\)/);
                        if (adxMatch && adxMatch[1]) {
                            entryData.adx = parseFloat(adxMatch[1]);
                        } else {
                            entryData.adx = adxStr;
                        }
                    } else if (trimmedLine.startsWith('ADI:')) {
                        entryData.adi = trimmedLine.substring('ADI:'.length).trim();
                    }
                }

                if (entryData.symbol) {
                    const orderBook = await getBybitOrderBook(entryData.symbol);
                    if (orderBook && orderBook.asks && orderBook.bids && orderBook.asks.length > 0 && orderBook.bids.length > 0) {
                        entryData.orderBook = orderBook;
                    } else {
                        console.warn("Order Book data unavailable or incomplete for " + entryData.symbol);
                        entryData.orderBook = null;
                    }
                }

                if (previousEntryData && entryData.currentPrice) {
                    const signal = generateScalpingSignal(previousEntryData, entryData, atrValues); // Pass atrValues - Improvement 2
                    if (signal) {
                        signals.push(signal);
                    }
                }

                previousEntryData = entryData;
            }

            console.log(JSON.stringify(signals, null, 2));
        });
    }, analysisInterval);
}

/**
 * Generates a scalping signal based on technical indicators and order book data.
 *
 * @param {object} prevData The previous log entry data.
 * @param {object} currentData The current log entry data (including order book).
 * @param {number[]} atrValues Array of recent ATR values - Improvement 2
 * @returns {object|null} A scalping signal object, or null if no signal is generated.
 */
function generateScalpingSignal(prevData, currentData, atrValues) { // Add atrValues as a parameter
    const symbol = currentData.symbol;
    const currentPrice = currentData.currentPrice;
    const atr = currentData.atr;
    const orderBook = currentData.orderBook;

    let reasoningParts = [];
    let confidence = baseConfidence;

    // Order Book Analysis
    if (orderBook && orderBook.asks && orderBook.bids && orderBook.asks.length > 0 && orderBook.bids.length > 0) {
        const asks = orderBook.asks;
        const bids = orderBook.bids;
        const bestAskPrice = parseFloat(asks[0][0]);
        const bestBidPrice = parseFloat(bids[0][0]);
        const askVolume = parseFloat(asks[0][1]);
        const bidVolume = parseFloat(bids[0][1]);
        const spread = bestAskPrice - bestBidPrice;
        const spreadPercentage = (spread / currentPrice) * 100;

        // Bid Volume suggests support
        if (bidVolume > askVolume * orderBookVolumeRatioThreshold) {
            reasoningParts.push(`High bid volume (${bidVolume.toFixed(2)}) relative to ask volume, potential support.`);
            confidence += confidenceBoostPerFactor;
        }

        // Ask Volume suggests resistance
        if (askVolume > bidVolume * orderBookVolumeRatioThreshold) {
            reasoningParts.push(`High ask volume (${askVolume.toFixed(2)}) relative to bid volume, potential resistance.`);
            confidence += confidenceBoostPerFactor;
        }

        // Tightening Spread - volatility
        if (spreadPercentage < orderBookSpreadThresholdMultiplier * (atr / currentPrice) * 100) { // compare spread to ATR for volatility
            reasoningParts.push(`Tightening spread (${spread.toFixed(4)}), potential volatility.`);
            confidence += confidenceBoostPerFactor;
        }

          // Check for large orders on the bid side near current price
        const nearBidLevels = bids.filter(level => parseFloat(level[0]) <= currentPrice && parseFloat(level[0]) >= currentPrice - (atr * orderBookSpreadThresholdMultiplier));
        const nearBidVolumeSum = nearBidLevels.reduce((sum, level) => sum + parseFloat(level[1]), 0);
        if (nearBidVolumeSum > askVolume * orderBookVolumeRatioThreshold) {
            reasoningParts.push(`Significant bid volume (${nearBidVolumeSum.toFixed(2)}) stacked near current price indicating buying interest.`);
            confidence += confidenceBoostPerFactor;
        }

        // Check for large orders on the ask side near current price
        const nearAskLevels = asks.filter(level => parseFloat(level[0]) >= currentPrice && parseFloat(level[0]) <= currentPrice + (atr * orderBookSpreadThresholdMultiplier));
        const nearAskVolumeSum = nearAskLevels.reduce((sum, level) => sum + parseFloat(level[1]), 0);
        if (nearAskVolumeSum > bidVolume * orderBookVolumeRatioThreshold) {
            reasoningParts.push(`Significant ask volume (${nearAskVolumeSum.toFixed(2)}) stacked near current price indicating selling pressure.`);
            confidence += confidenceBoostPerFactor;
        }
    } else {
        console.warn("Order Book data unavailable or incomplete, skipping order book logic.");
    }

    //Long condition
    if (reasoningParts.length === 0) { // Reset reasoning for long signal checks
        reasoningParts = [];
        confidence = baseConfidence;
    }

    //RSI
    if (prevData.rsi <= rsiOversoldThreshold && currentData.rsi > rsiOversoldThreshold) {
        reasoningParts.push(`RSI bounced from oversold territory (below ${rsiOversoldThreshold})`);
        confidence += confidenceBoostPerFactor;
    }

    //Trend
    if (currentData.trend.includes("Downtrend")) {
        reasoningParts.push("Overall Downtrend present");
        confidence += confidenceBoostPerFactor;
    }

    //MFI
    if (prevData.mfi <= mfiOversoldThreshold && currentData.mfi > mfiOversoldThreshold) { // Improvement 3
      reasoningParts.push("MFI bounced from oversold territory");
      confidence += confidenceBoostPerFactor;
    }

    if (reasoningParts.length > 0){ //Signal logic
      const stopLoss = currentPrice - (stopLossMultiple * atr);
      const entryPrice = currentPrice;
      let reasoning = reasoningParts.join(" and ");
       confidence = Math.min(confidence, 10);

        return {
            signalType: "Long",
            symbol: symbol,
            entryPrice: entryPrice,
            currentPrice: currentPrice,
            stopLoss: stopLoss,
            takeProfit: entryPrice + (atr * takeProfitMultiple),
            confidence: confidence,
            reasoning: reasoning,
            timestamp: currentData.timestamp
        };
    }

    // Short condition - Reset reasoning for short signal checks
    reasoningParts = [];
    confidence = baseConfidence;

    //RSI
    if (prevData.rsi >= rsiOverboughtThreshold && currentData.rsi < rsiOverboughtThreshold) {
        reasoningParts.push(`RSI dropped from overbought territory (above ${rsiOverboughtThreshold})`);
        confidence += confidenceBoostPerFactor;
    }
    //Trend
    if (currentData.trend.includes("Uptrend")) {
        reasoningParts.push("Overall Uptrend present");
        confidence += confidenceBoostPerFactor;
    }

    //MFI
    if (prevData.mfi >= mfiOverboughtThreshold && currentData.mfi < mfiOverboughtThreshold) { // Improvement 3
      reasoningParts.push("MFI dropped from overbought territory");
      confidence += confidenceBoostPerFactor;
    }


    if (reasoningParts.length > 0) { //Signal logic
        const stopLoss = currentPrice + (stopLossMultiple * atr);
        const entryPrice = currentPrice;
        let reasoning = reasoningParts.join(" and ");
         confidence = Math.min(confidence, 10);
        return {
            signalType: "Short",
            symbol: symbol,
            entryPrice: entryPrice,
            currentPrice: currentPrice,
            stopLoss: stopLoss,
            takeProfit: entryPrice - (atr * takeProfitMultiple),
            confidence: confidence,
            reasoning: reasoning,
            timestamp: currentData.timestamp
        };
    }

    return null; // No signal generated
}

// Function to Get the ByBit Order Book - Updated typo
async function getBybitOrderBook(symbol) {
    try {
        const apiKey = EXCHANGE_API_KEY;
        const apiSecret = EXCHANGE_API_SECRET;
        const timestamp = Date.now();
        const recvWindow = 5000;
        const endpoint = 'https://api.bybit.com/v5/market/orderbook';
        const signaturePayload = `symbol=${symbol}&limit=50&recvWindow=${recvWindow}×tamp=${timestamp}`;

        const crypto = require('crypto');
        const signature = crypto
            .createHmac('sha256', apiSecret)
            .update(signaturePayload)
            .digest('hex');

        const params = {
            symbol: symbol,
            limit: 50,
            category: 'linear',
        };

        const headers = {
            'X-BAPI-API-KEY': apiKey,
            'X-BAPI-SIGN': signature,
            'X-BAPI-SIGN-TYPE': '2',
            'X-BAPI-TIMESTAMP': timestamp,
            'X-BAPI-RECV-WINDOW': recvWindow,
            'Content-Type': 'application/json'
        };

        const response = await axios.get(endpoint, { params, headers });

        if (response.data.retCode === 0) {
            return response.data.result;
        } else {
            console.error('Error fetching order book:', response.data);
            return null;
        }
    } catch (error) {
        console.error('Error fetching order book:', error);
        return null;
    }
}


// Start the analysis loop
startLogAnalysisLoop();
