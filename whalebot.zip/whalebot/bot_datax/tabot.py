import json
import time
import os
import hmac
import hashlib
from datetime import datetime, timezone
import re
import asyncio
from typing import Optional

import aiohttp  # Use aiohttp for asynchronous requests
from dotenv import load_dotenv

load_dotenv()

# --- Configuration Variables ---
FILE_PATH = 'whalebot.txt'
ANALYSIS_INTERVAL = 5  # Seconds
STOP_LOSS_MULTIPLE = 2
BASE_CONFIDENCE = 3
CONFIDENCE_BOOST_PER_FACTOR = 2
RSI_OVERSOLD_THRESHOLD = 30
RSI_OVERBOUGHT_THRESHOLD = 70
TAKE_PROFIT_MULTIPLE = 1.5
ORDER_BOOK_VOLUME_RATIO_THRESHOLD = 2
ORDER_BOOK_SPREAD_THRESHOLD_MULTIPLIER = 0.5
ATR_LOOKBACK_PERIOD = 20
MFI_OVERSOLD_THRESHOLD = 20
MFI_OVERBOUGHT_THRESHOLD = 80
SIGNAL_COOLDOWN_S = 60  # 1 minute cooldown
ORDER_BOOK_DEBOUNCE_S = 1  # Debounce order book requests by 1 second

# --- Thresholds for significant change ---
PRICE_CHANGE_THRESHOLD = 0.01  # Example: 0.01 (1%)
ATR_CHANGE_THRESHOLD = 0.01  # Example: 0.01 (1%)

# --- State Variables ---
last_signal_timestamp = 0
last_order_book_request_timestamp = 0
cached_entry_data = None  # Cache for significant change check


# --- Logging Function ---
def log(level, message):
    timestamp = datetime.now(timezone.utc).isoformat()
    print(f"{timestamp} - {level} - {message}")


# --- Bybit API Abstraction ---
async def get_bybit_order_book(symbol: str, retries: int = 3) -> Optional[dict]:
    if not symbol:
        raise ValueError('Invalid symbol provided')

    # Debounce logic
    global last_order_book_request_timestamp
    now = time.time()
    if now - last_order_book_request_timestamp < ORDER_BOOK_DEBOUNCE_S:
        log('DEBUG', f'Debouncing order book request for {symbol}')
        return None  # Or return a cached value

    last_order_book_request_timestamp = now

    for i in range(retries):
        try:
            api_key = os.getenv('BYBIT_API_KEY')
            api_secret = os.getenv('BYBIT_API_SECRET')
            timestamp = str(int(time.time() * 1000))
            recv_window = '5000'
            endpoint = 'https://api.bybit.com/v5/market/orderbook'

            params = {
                'symbol': symbol.upper(),
                'limit': 50,
                'category': 'spot',
            }

            param_str = '&'.join([f"{k}={v}" for k, v in params.items()])
            signature_payload = f"{param_str}&recvWindow={recv_window}×tamp={timestamp}"

            signature = hmac.new(
                api_secret.encode('utf-8'),
                signature_payload.encode('utf-8'),
                hashlib.sha256
            ).hexdigest()

            headers = {
                'X-BAPI-API-KEY': api_key,
                'X-BAPI-SIGN': signature,
                'X-BAPI-SIGN-TYPE': '2',
                'X-BAPI-TIMESTAMP': timestamp,
                'X-BAPI-RECV-WINDOW': recv_window,
                'Content-Type': 'application/json',
            }

            async with aiohttp.ClientSession() as session:  # Asynchronous request
                async with session.get(endpoint, params=params, headers=headers) as response:
                    data = await response.json()

                    if data['retCode'] == 0:
                        return data['result']
                    log('WARN', f"Attempt {i + 1}/{retries}: Invalid response from API: retCode={data['retCode']}, retMsg={data['retMsg']}")

        except Exception as error:
            log('ERROR', f"Attempt {i + 1}/{retries} failed: {error}")
            if i == retries - 1:
                raise
            await asyncio.sleep(1)

    return None



# --- Parse Individual Log Entry ---
def parse_log_entry(entry):
    lines = entry.split('\n')
    entry_data = {}

    indicators = {
        'Exchange:': 'exchange',
        'Symbol:': 'symbol',
        'Interval:': 'interval',
        'Timestamp:': 'timestamp',
        'Current Price:': 'currentPrice',
        'ATR:': 'atr',
        'Trend:': 'trend',
        'OBV:': 'obv',
        'RSI:': 'rsi',
        'MFI:': 'mfi',
        'CCI:': 'cci',
        'Williams %R:': 'williamsR',
        'ADX:': 'adx',
        'ADI:': 'adi'
    }

    for line in lines:
        trimmed_line = line.strip()

        for prefix, field in indicators.items():
            if trimmed_line.startswith(prefix):
                value = trimmed_line[len(prefix):].strip()

                # Parse numeric values
                if field in ('currentPrice', 'atr'):
                    try:
                        value = float(value)
                    except (ValueError, TypeError):
                        log('WARN', f"Invalid {field} found: {value}. Setting to None.")
                        value = None  # Set to None for invalid values

                # Parse indicators with patterns
                if field in ('rsi', 'mfi', 'cci', 'williamsR', 'adx'):
                    match = re.search(r'\(([-.\d]+)\)', value)
                    if match:
                        try:  # Ensure the matched value is a valid float
                            value = float(match.group(1))
                        except ValueError:
                            log('WARN', f"Invalid {field} found: {value}. Setting to None")
                            value = None
                    else:
                        value = None # Set to None if not found

                if value == '' or value == 0:
                    log('WARN', f"Empty string or zero found in {field}. Setting to None.")
                    value = None;
                entry_data[field] = value
                break

    return entry_data

# --- Analyze Order Book Data ---
def analyze_order_book(order_book, current_price, atr):
    reasoning = []
    confidence_boost = 0

    if (order_book and order_book.get('asks') and order_book.get('bids') and
            len(order_book['asks']) > 0 and len(order_book['bids']) > 0):
        asks = order_book['asks']
        bids = order_book['bids']
        best_ask_price = float(asks[0][0])
        best_bid_price = float(bids[0][0])
        ask_volume = float(asks[0][1])
        bid_volume = float(bids[0][1])
        spread = best_ask_price - best_bid_price

        # Analyze volumes and spreads
        if bid_volume > ask_volume * ORDER_BOOK_VOLUME_RATIO_THRESHOLD:
            reasoning.append(f"High bid volume ({bid_volume:.2f}) relative to ask volume")
            confidence_boost += CONFIDENCE_BOOST_PER_FACTOR

        if (spread / current_price) * 100 < ORDER_BOOK_SPREAD_THRESHOLD_MULTIPLIER * (atr / current_price) * 100:
            reasoning.append(f"Tight spread ({(spread / current_price * 100):.4f}%)")
            confidence_boost += CONFIDENCE_BOOST_PER_FACTOR

    return reasoning, confidence_boost


# --- Check Conditions for a Long Signal ---
def check_long_signal(prev_data, current_data, atr, reasoning_parts, confidence):
    long_reasons = reasoning_parts[:]
    long_confidence = confidence

    if (prev_data.get('rsi') is not None and current_data.get('rsi') is not None and
            prev_data['rsi'] <= RSI_OVERSOLD_THRESHOLD and current_data['rsi'] > RSI_OVERSOLD_THRESHOLD):
        long_reasons.append(f"RSI bounced from oversold ({current_data['rsi']:.2f})")
        long_confidence += CONFIDENCE_BOOST_PER_FACTOR

    if current_data.get('trend') and "Downtrend" in current_data['trend']:
        long_reasons.append("Downtrend present")
        long_confidence += CONFIDENCE_BOOST_PER_FACTOR

    if (prev_data.get('mfi') is not None and current_data.get('mfi') is not None and
            prev_data['mfi'] <= MFI_OVERSOLD_THRESHOLD and current_data['mfi'] > MFI_OVERSOLD_THRESHOLD):
        long_reasons.append(f"MFI bounced from oversold ({current_data['mfi']:.2f})")
        long_confidence += CONFIDENCE_BOOST_PER_FACTOR
    if long_reasons:

        return {
            'signalType': "Long",
            'symbol': current_data['symbol'],
            'entryPrice': current_data['currentPrice'],
            'stopLoss': current_data['currentPrice'] - (STOP_LOSS_MULTIPLE * atr),
            'takeProfit': current_data['currentPrice'] + (atr * TAKE_PROFIT_MULTIPLE),
            'confidence': min(long_confidence, 10),
            'reasoning': " and ".join(long_reasons),
            'timestamp': current_data['timestamp'],
        }

    return None

# --- Check Conditions for a Short Signal ---
def check_short_signal(prev_data, current_data, atr, reasoning_parts, confidence):
    short_reasons = reasoning_parts[:]
    short_confidence = confidence

    if (prev_data.get('rsi') is not None and current_data.get('rsi') is not None and
        prev_data['rsi'] >= RSI_OVERBOUGHT_THRESHOLD and current_data['rsi'] < RSI_OVERBOUGHT_THRESHOLD):
        short_reasons.append(f"RSI dropped from overbought ({current_data['rsi']:.2f})")
        short_confidence += CONFIDENCE_BOOST_PER_FACTOR

    if current_data.get('trend') and "Uptrend" in current_data['trend']:
        short_reasons.append("Uptrend present")
        short_confidence += CONFIDENCE_BOOST_PER_FACTOR

    if (prev_data.get('mfi') is not None and current_data.get('mfi') is not None and
            prev_data['mfi'] >= MFI_OVERBOUGHT_THRESHOLD and current_data['mfi'] < MFI_OVERBOUGHT_THRESHOLD):
        short_reasons.append(f"MFI dropped from overbought ({current_data['mfi']:.2f})")
        short_confidence += CONFIDENCE_BOOST_PER_FACTOR

    if short_reasons:
        return {
            'signalType': "Short",
            'symbol': current_data['symbol'],
            'entryPrice': current_data['currentPrice'],
            'stopLoss': current_data['currentPrice'] + (STOP_LOSS_MULTIPLE * atr),
            'takeProfit': current_data['currentPrice'] - (atr * TAKE_PROFIT_MULTIPLE),
            'confidence': min(short_confidence, 10),
            'reasoning': " and ".join(short_reasons),
            'timestamp': current_data['timestamp'],
        }

    return None

# --- Generate Scalping Signals ---
def generate_scalping_signal(prev_data, current_data, atr_values):
    if not current_data.get('symbol') or current_data.get('currentPrice') is None or current_data.get('atr') is None:
        return None

    atr = current_data['atr']
    reasoning_parts = []
    confidence = BASE_CONFIDENCE

    # Optional Order Book Analysis
    if current_data.get('orderBook'):
        order_book_reasoning, confidence_boost = analyze_order_book(
            current_data['orderBook'], current_data['currentPrice'], atr
        )
        reasoning_parts.extend(order_book_reasoning)
        confidence += confidence_boost

    # Check for cooldown
    global last_signal_timestamp
    now = time.time()
    if now - last_signal_timestamp < SIGNAL_COOLDOWN_S:
        log('DEBUG', f"Signal cooldown active for {current_data['symbol']}")
        return None

    # Generate Long Signal
    long_signal = check_long_signal(prev_data, current_data, atr, reasoning_parts, confidence)
    if long_signal:
        last_signal_timestamp = now
        return long_signal

    # Generate Short Signal
    short_signal = check_short_signal(prev_data, current_data, atr, reasoning_parts, confidence)
    if short_signal:
        last_signal_timestamp = now
        return short_signal

    return None


# --- Check for Significant Changes ---
def has_significant_changes(new_entry_data, cached_entry_data):
    if not cached_entry_data:
        return True  # First entry, always significant

    # Price change check
    if (new_entry_data.get('currentPrice') is not None and
            cached_entry_data.get('currentPrice') is not None):
        price_change_percent = abs(
            (new_entry_data['currentPrice'] - cached_entry_data['currentPrice']) / cached_entry_data['currentPrice']
        )
        if price_change_percent >= PRICE_CHANGE_THRESHOLD:
            return True

    # ATR change check
    if new_entry_data.get('atr') is not None and cached_entry_data.get('atr') is not None:
        atr_change_percent = abs(
            (new_entry_data['atr'] - cached_entry_data['atr']) / cached_entry_data['atr']
        )
        if atr_change_percent >= ATR_CHANGE_THRESHOLD:
            return True

    # Add checks for other indicators as needed
    return False  # No significant changes

# --- Main Log Analysis Loop ---
async def start_log_analysis_loop():
    # Check if the log file exists
    if not os.path.exists(FILE_PATH):
        log('ERROR', f"Log file not found: {FILE_PATH}")
        return  # Exit if the file doesn't exist

    global cached_entry_data

    while True:
        try:
            with open(FILE_PATH, 'r', encoding='utf-8') as file:
                data = file.read()

            clean_data = re.sub(r'\x1b\[[0-9;]*m', '', data)  # Remove ANSI escape codes
            log_entries = re.split(r'(?=\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} - INFO -)', clean_data)  # Split entries

            signals = []
            previous_entry_data = {}  # Initialize as dictionary
            atr_values = []
            for entry in log_entries:

                if not entry.strip():
                    continue  # Skip empty entries

                entry_data = parse_log_entry(entry)

                # --- Significant Change Check ---
                if not has_significant_changes(entry_data, cached_entry_data):
                    if 'symbol' in entry_data:
                        log('DEBUG', f"Skipping entry for {entry_data.get('symbol', 'N/A')}: No significant changes")
                    continue  # Skip to the next entry

                cached_entry_data = entry_data  # Update cache


                if entry_data.get('symbol'):
                    try:
                        order_book = await get_bybit_order_book(entry_data['symbol'])
                        entry_data['orderBook'] = order_book
                    except Exception as api_error:
                        log('WARN', f"Failed to fetch orderbook for {entry_data.get('symbol', 'N/A')}: {api_error}")
                        entry_data['orderBook'] = None

                if entry_data.get('atr') is not None:
                    atr_values.append(entry_data['atr'])
                    if len(atr_values) > ATR_LOOKBACK_PERIOD:
                        atr_values.pop(0)  # Keep only the last 'atrLookbackPeriod' values

                # Ensure we have previous data and current price before generating a signal
                if previous_entry_data and entry_data.get('currentPrice') is not None:
                    signal = generate_scalping_signal(previous_entry_data, entry_data, atr_values)
                    if signal:
                        signals.append(signal)

                previous_entry_data = entry_data  # Update previous entry

            log('INFO', json.dumps(signals, indent=2))  # Output signals

        except Exception as processing_error:
            log('ERROR', f'Error processing log data: {processing_error}')

        await asyncio.sleep(ANALYSIS_INTERVAL)  # Use asyncio.sleep for non-blocking sleep

# --- Start the Analysis ---
asyncio.run(start_log_analysis_loop())
