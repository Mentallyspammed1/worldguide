const fs = require('fs');

/**
 * Analyzes a log file with the specified format, extracts trading data, and
 * outputs a JSON representation.  Handles ANSI escape codes and inconsistent spacing.
 * @param {string} filePath The path to the log file.
 */
function analyzeLogFile(filePath) {
  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      console.error(`Failed to read the file: ${filePath}`, err);
      return;
    }

    // Remove ANSI escape codes for color formatting
    const cleanData = data.replace(/\x1b\[[0-9;]*m/g, '');

    // Split into log entries.  Use a lookahead assertion to split *before* the log line.
    const logEntries = cleanData.split(/(?=\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} - INFO -)/);

    const results = [];

    logEntries.forEach(entry => {
      if (!entry.trim()) return;

      const lines = entry.split('\n');
      const entryData = {};

      lines.forEach(line => {
        line = line.trim();

        if (line.startsWith('Exchange:')) {
          entryData.exchange = line.substring('Exchange:'.length).trim();
        } else if (line.startsWith('Symbol:')) {
          entryData.symbol = line.substring('Symbol:'.length).trim();
        } else if (line.startsWith('Interval:')) {
          entryData.interval = line.substring('Interval:'.length).trim();
        } else if (line.startsWith('Timestamp:')) {
          entryData.timestamp = line.substring('Timestamp:'.length).trim();
        } else if (line.startsWith('Current Price:')) {
          const priceStr = line.substring('Current Price:'.length).trim();
          entryData.currentPrice = parseFloat(priceStr);
          if (isNaN(entryData.currentPrice)) {
            console.warn(`Invalid Current Price found: ${priceStr}`);
          }
        } else if (line.startsWith('ATR:')) {
            const atrStr = line.substring('ATR:'.length).trim();
            entryData.atr = parseFloat(atrStr);
            if (isNaN(entryData.atr)) {
                console.warn(`Invalid ATR found: ${atrStr}`);
            }
        } else if (line.startsWith('Trend:')) {
          entryData.trend = line.substring('Trend:'.length).trim();
        } else if (line.startsWith('OBV:')) {
          entryData.obv = line.substring('OBV:'.length).trim();
        } else if (line.startsWith('RSI:')) {
          const rsiStr = line.substring('RSI:'.length).trim();
          const rsiMatch = rsiStr.match(/\(([\d.]+)\)/); // Extract number from "Oversold (29.63)"
          if (rsiMatch && rsiMatch[1]) {
            entryData.rsi = parseFloat(rsiMatch[1]);
          } else {
            entryData.rsi = rsiStr; // Store the whole string if no number found
          }
        } else if (line.startsWith('MFI:')) {
            const mfiStr = line.substring('MFI:'.length).trim();
            const mfiMatch = mfiStr.match(/\(([\d.]+)\)/); // Extract number from "Neutral (22.58)"
            if (mfiMatch && mfiMatch[1]) {
              entryData.mfi = parseFloat(mfiMatch[1]);
            } else {
              entryData.mfi = mfiStr; // Store the whole string if no number found
            }
        } else if (line.startsWith('CCI:')) {
            const cciStr = line.substring('CCI:'.length).trim();
            const cciMatch = cciStr.match(/\(([-.\d]+)\)/); // Extract number from "Neutral (-42.59)"
            if (cciMatch && cciMatch[1]) {
              entryData.cci = parseFloat(cciMatch[1]);
            } else {
              entryData.cci = cciStr; // Store the whole string if no number found
            }
        } else if (line.startsWith('Williams %R:')) {
          const williamsRStr = line.substring('Williams %R:'.length).trim();
          const williamsRMatch = williamsRStr.match(/\(([-.\d]+)\)/); // Extract number from "Oversold (-80.83)"
          if (williamsRMatch && williamsRMatch[1]) {
            entryData.williamsR = parseFloat(williamsRMatch[1]);
          } else {
            entryData.williamsR = williamsRStr; // Store the whole string if no number found
          }
        } else if (line.startsWith('ADX:')) {
          const adxStr = line.substring('ADX:'.length).trim();
          const adxMatch = adxStr.match(/\(([\d.]+)\)/); // Extract number from "Ranging (11.80)"
          if (adxMatch && adxMatch[1]) {
            entryData.adx = parseFloat(adxMatch[1]);
          } else {
            entryData.adx = adxStr; // Store the whole string if no number found
          }
        } else if (line.startsWith('ADI:')) {
          entryData.adi = line.substring('ADI:'.length).trim();
        }
      });

      results.push(entryData);
    });

    console.log(JSON.stringify(results, null, 2));
  });
}

const filePath = 'whalebot.txt';
analyzeLogFile(filePath);
