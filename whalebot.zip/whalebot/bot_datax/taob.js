const fs = require('fs');
const axios = require('axios');
const dotenv = require('dotenv');

dotenv.config();

// Configuration variables
const filePath = 'whalebot.txt';
const analysisInterval = 5000;
const stopLossMultiple = 2;
const baseConfidence = 3;
const confidenceBoostPerFactor = 2;
const rsiOversoldThreshold = 30;
const rsiOverboughtThreshold = 70;
const takeProfitMultiple = 1.5;

// API Keys from .env file
const EXCHANGE_API_KEY = process.env.BYBIT_API_KEY;
const EXCHANGE_API_SECRET = process.env.BYBIT_API_SECRET;

if (!EXCHANGE_API_KEY || !EXCHANGE_API_SECRET) {
    console.error("Error: BYBIT_API_KEY and/or BYBIT_API_SECRET not found in .env file.");
    process.exit(1);
}


//Function to Get the ByBit Order Book
async function getBybitOrderBook(symbol) {
  try {
    const apiKey = EXCHANGE_API_KEY;
    const apiSecret = EXCHANGE_API_SECRET;
    const timestamp = Date.now();
    const recvWindow = 5000; // Adjust as needed
    const endpoint = 'https://api.bybit.com/v5/market/orderbook'; // Correct endpoint
    const signaturePayload = `symbol=${symbol}&limit=50&recvWindow=${recvWindow}×tamp=${timestamp}`;

    // Function to generate the signature
    const crypto = require('crypto');
    const signature = crypto
        .createHmac('sha256', apiSecret)
        .update(signaturePayload)
        .digest('hex');


    const params = {
        symbol: symbol,
        limit: 50, // Number of levels to retrieve
        category: 'linear', // Specify the asset category (e.g., spot, linear, inverse)
    };

    const headers = {
        'X-BAPI-API-KEY': apiKey,
        'X-BAPI-SIGN': signature,
        'X-BAPI-SIGN-TYPE': '2',
        'X-BAPI-TIMESTAMP': timestamp,
        'X-BAPI-RECV-WINDOW': recvWindow,
        'Content-Type': 'application/json'
    };



    const response = await axios.get(endpoint, { params, headers });

    if (response.data.retCode === 0) {
      return response.data.result;
    } else {
      console.error('Error fetching order book:', response.data);
      return null;
    }
  } catch (error) {
    console.error('Error fetching order book:', error);
    return null;
  }
}


/**
 * Analyzes a log file, extracts trading data, generates scalping signals, and
 * outputs the signals with stop loss, entry price, confidence level (1-10), and reasoning,
 * running in a loop.
 */
function startLogAnalysisLoop() {
    setInterval(() => {
        fs.readFile(filePath, 'utf8', async (err, data) => { // Make callback async
            if (err) {
                console.error(`Failed to read the file: ${filePath}`, err);
                return;
            }

            // Remove ANSI escape codes
            const cleanData = data.replace(/\x1b\[[0-9;]*m/g, '');

            // Split into log entries
            const logEntries = cleanData.split(/(?=\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} - INFO -)/);

            const signals = [];

            // Keep track of the previous entry for signal generation
            let previousEntryData = null;

            for (const entry of logEntries) { // Changed to for...of loop for async/await
                if (!entry.trim()) continue;

                const lines = entry.split('\n');
                const entryData = {};

                for (const line of lines) { // Changed to for...of loop
                    const trimmedLine = line.trim();

                    if (trimmedLine.startsWith('Exchange:')) {
                        entryData.exchange = trimmedLine.substring('Exchange:'.length).trim();
                    } else if (trimmedLine.startsWith('Symbol:')) {
                        entryData.symbol = trimmedLine.substring('Symbol:'.length).trim();
                    } else if (trimmedLine.startsWith('Interval:')) {
                        entryData.interval = trimmedLine.substring('Interval:'.length).trim();
                    } else if (trimmedLine.startsWith('Timestamp:')) {
                        entryData.timestamp = trimmedLine.substring('Timestamp:'.length).trim();
                    } else if (trimmedLine.startsWith('Current Price:')) {
                        const priceStr = trimmedLine.substring('Current Price:'.length).trim();
                        entryData.currentPrice = parseFloat(priceStr);
                        if (isNaN(entryData.currentPrice)) {
                            console.warn(`Invalid Current Price found: ${priceStr}`);
                        }
                    } else if (trimmedLine.startsWith('ATR:')) {
                        const atrStr = trimmedLine.substring('ATR:'.length).trim();
                        entryData.atr = parseFloat(atrStr);
                        if (isNaN(entryData.atr)) {
                            console.warn(`Invalid ATR found: ${atrStr}`);
                        }
                    } else if (trimmedLine.startsWith('Trend:')) {
                        entryData.trend = trimmedLine.substring('Trend:'.length).trim();
                    } else if (trimmedLine.startsWith('OBV:')) {
                        entryData.obv = trimmedLine.substring('OBV:'.length).trim();
                    } else if (trimmedLine.startsWith('RSI:')) {
                        const rsiStr = trimmedLine.substring('RSI:'.length).trim();
                        const rsiMatch = rsiStr.match(/\(([\d.]+)\)/);
                        if (rsiMatch && rsiMatch[1]) {
                            entryData.rsi = parseFloat(rsiMatch[1]);
                        } else {
                            entryData.rsi = rsiStr;
                        }
                    } else if (trimmedLine.startsWith('MFI:')) {
                        const mfiStr = trimmedLine.substring('MFI:'.length).trim();
                        const mfiMatch = mfiStr.match(/\(([\d.]+)\)/);
                        if (mfiMatch && mfiMatch[1]) {
                            entryData.mfi = parseFloat(mfiMatch[1]);
                        } else {
                            entryData.mfi = mfiStr;
                        }
                    } else if (trimmedLine.startsWith('CCI:')) {
                        const cciStr = trimmedLine.substring('CCI:'.length).trim();
                        const cciMatch = cciStr.match(/\(([-.\d]+)\)/);
                        if (cciMatch && cciMatch[1]) {
                            entryData.cci = parseFloat(cciMatch[1]);
                        } else {
                            entryData.cci = cciStr;
                        }
                    } else if (trimmedLine.startsWith('Williams %R:')) {
                        const williamsRStr = trimmedLine.substring('Williams %R:'.length).trim();
                        const williamsRMatch = williamsRStr.match(/\(([-.\d]+)\)/);
                        if (williamsRMatch && williamsRMatch[1]) {
                            entryData.williamsR = parseFloat(williamsRMatch[1]);
                        } else {
                            entryData.williamsR = williamsRStr;
                        }
                    } else if (trimmedLine.startsWith('ADX:')) {
                        const adxStr = trimmedLine.substring('ADX:'.length).trim();
                        const adxMatch = adxStr.match(/\(([\d.]+)\)/);
                        if (adxMatch && adxMatch[1]) {
                            entryData.adx = parseFloat(adxMatch[1]);
                        } else {
                            entryData.adx = adxStr;
                        }
                    } else if (trimmedLine.startsWith('ADI:')) {
                        entryData.adi = trimmedLine.substring('ADI:'.length).trim();
                    }
                }

              if (entryData.symbol) {
                  console.log("Extracted Symbol:", entryData.symbol); // ADD THIS LINE
                  const orderBook = await getBybitOrderBook(entryData.symbol);
                   if (orderBook && orderBook.asks && orderBook.bids && orderBook.asks.length > 0 && orderBook.bids.length > 0) {
                     entryData.orderBook = orderBook;
                    }
                  else {
                      console.warn("Order Book data unavailable or incomplete for " + entryData.symbol); // ADD THIS LINE
                      entryData.orderBook = null; // Ensure it's null
                     }
                  }

                // Generate signal if we have a previous entry
                if (previousEntryData && entryData.currentPrice) {
                    const signal = generateScalpingSignal(previousEntryData, entryData);
                    if (signal) {
                        signals.push(signal);
                    }
                }

                previousEntryData = entryData; // Store current entry for next iteration
            }

            console.log(JSON.stringify(signals, null, 2));
        });
    }, analysisInterval);
}

/**
 * Generates a scalping signal based on technical indicators and order book data.
 *
 * @param {object} prevData The previous log entry data.
 * @param {object} currentData The current log entry data (including order book).
 * @returns {object|null} A scalping signal object, or null if no signal is generated.
 */
function generateScalpingSignal(prevData, currentData) {
    const symbol = currentData.symbol;
    const currentPrice = currentData.currentPrice;
    const atr = currentData.atr;
    const orderBook = currentData.orderBook; // Get the order book

    let reasoningParts = [];
    let confidence = baseConfidence;

    // Add the orderbook signal in the reasoning parts
     if (orderBook && orderBook.asks && orderBook.bids && orderBook.asks.length > 0 && orderBook.bids.length > 0) {  //ADD THIS CHECK
        const asks = orderBook.asks
        const bids = orderBook.bids
        const bestAskPrice = asks[0][0];
        const bestBidPrice = bids[0][0];
        const askVolume = asks[0][1];
        const bidVolume = bids[0][1];

    // Simple example: High bid volume near current price might suggest support.
    if (bidVolume > askVolume * 1.5 && currentPrice - bestBidPrice < atr / 2) {
      reasoningParts.push(`High bid volume (${bidVolume}) near current price, indicating possible support.`);
      confidence += confidenceBoostPerFactor;
    }

       // Simple example: High ask volume near current price might suggest resistance.
    if (askVolume > bidVolume * 1.5 && bestAskPrice - currentPrice < atr / 2) {
      reasoningParts.push(`High ask volume (${askVolume}) near current price, indicating possible resistance.`);
      confidence += confidenceBoostPerFactor;
    }
   } else{
        console.warn("Order Book data unavailable or incomplete skipping order book logic.");  // AND THIS WARNING.
   }

    //Long condition
    if (prevData.rsi <= rsiOversoldThreshold && currentData.rsi > rsiOversoldThreshold) {
        reasoningParts.push(`RSI bounced from oversold territory (below ${rsiOversoldThreshold})`);
         confidence += confidenceBoostPerFactor;
    }

    if (currentData.trend.includes("Downtrend")) {
        reasoningParts.push("Overall Downtrend present");
        confidence += confidenceBoostPerFactor;
    }

    if ((prevData.mfi <= 20 ) && (currentData.mfi > 20)) {
      reasoningParts.push("Money Flow Index recovered from 20");
      confidence += confidenceBoostPerFactor;
    }

    if (reasoningParts.length > 0){ //Signal logic
      const stopLoss = currentPrice - (stopLossMultiple * atr);
      const entryPrice = currentPrice; // Enter at the current price
      let reasoning = reasoningParts.join(" and ");

       confidence = Math.min(confidence, 10); //Cap Confidence at 10

        return {
            signalType: "Long",
            symbol: symbol,
            entryPrice: entryPrice,
            currentPrice: currentPrice,
            stopLoss: stopLoss,
            takeProfit: entryPrice + (atr * takeProfitMultiple), //Arbitrary Take Profit
            confidence: confidence,
            reasoning: reasoning,
            timestamp: currentData.timestamp
        };
    }


    // Example scalping strategy: Overbought RSI and uptrend suggests potential pullback
      reasoningParts = []; //Reset
    confidence = baseConfidence; //Reset Confidence

    if (prevData.rsi >= rsiOverboughtThreshold && currentData.rsi < rsiOverboughtThreshold) {
        reasoningParts.push(`RSI dropped from overbought territory (above ${rsiOverboughtThreshold})`);
        confidence += confidenceBoostPerFactor;
    }
    if (currentData.trend.includes("Uptrend")) {
        reasoningParts.push("Overall Uptrend present");
        confidence += confidenceBoostPerFactor;
    }

    if ((prevData.mfi >= 80) && (currentData.mfi < 80)){
      reasoningParts.push("Money Flow Index dropped from 80");
      confidence += confidenceBoostPerFactor;
    }

      if (reasoningParts.length > 0) { //Signal logic
        const stopLoss = currentPrice + (stopLossMultiple * atr);
        const entryPrice = currentPrice;
        let reasoning = reasoningParts.join(" and ");
         confidence = Math.min(confidence, 10);  //Cap Confidence at 10
        return {
            signalType: "Short",
            symbol: symbol,
            entryPrice: entryPrice,
            currentPrice: currentPrice,
            stopLoss: stopLoss,
            takeProfit: entryPrice - (atr * takeProfitMultiple), //Arbitrary Take Profit
            confidence: confidence,
            reasoning: reasoning,
            timestamp: currentData.timestamp
        };
    }

    return null; // No signal generated
}

// Start the analysis loop
startLogAnalysisLoop();
