const fs = require('fs');
const axios = require('axios');
const dotenv = require('dotenv');
const crypto = require('crypto');

dotenv.config();

// --- Configuration Variables ---
const filePath = 'whalebot.txt';
const analysisInterval = 5000;      // Milliseconds
const stopLossMultiple = 2;
const baseConfidence = 3;
const confidenceBoostPerFactor = 2;
const rsiOversoldThreshold = 30;
const rsiOverboughtThreshold = 70;
const takeProfitMultiple = 1.5;
const orderBookVolumeRatioThreshold = 2;
const orderBookSpreadThresholdMultiplier = 0.5;
const atrLookbackPeriod = 20;
const mfiOversoldThreshold = 20;
const mfiOverboughtThreshold = 80;
const signalCooldownMs = 20000;    // 1 minute cooldown
const orderBookDebounceMs = 1000;  // Debounce order book requests by 1 second

// --- Thresholds for significant change ---
const priceChangeThreshold = 0.01; // Example: 0.01 (1%)
const atrChangeThreshold = 0.01;   // Example: 0.01 (1%)

// --- State Variables ---
let lastSignalTimestamp = 0;
let lastOrderBookRequestTimestamp = 0;
let cachedEntryData = null; // Cache for significant change check


// --- Logging Function (Simplified) ---
function log(level, message) {
    const timestamp = new Date().toISOString();
    console.log(`${timestamp} - ${level} - ${message}`);
}

// --- Bybit API Abstraction ---
async function getBybitOrderBook(symbol, retries = 3) {
  if (!symbol) {
    throw new Error('Invalid symbol provided');
  }

  // Debounce logic
  const now = Date.now();
  if (now - lastOrderBookRequestTimestamp < orderBookDebounceMs) {
    log('DEBUG', `Debouncing order book request for ${symbol}`);
    return null; // Or return a cached value if you have one
  }
  lastOrderBookRequestTimestamp = now;


  for (let i = 0; i < retries; i++) {
    try {
      const apiKey = process.env.BYBIT_API_KEY;
      const apiSecret = process.env.BYBIT_API_SECRET;
      const timestamp = Date.now();
      const recvWindow = 5000;
      const endpoint = 'https://api.bybit.com/v5/market/orderbook';

      const params = {
        symbol: symbol.toUpperCase(),
        limit: 50,
        category: 'spot',
      };

      const signaturePayload = `symbol=${params.symbol}&limit=${params.limit}&category=${params.category}&recvWindow=${recvWindow}×tamp=${timestamp}`;

      const signature = crypto
        .createHmac('sha256', apiSecret)
        .update(signaturePayload)
        .digest('hex');

      const headers = {
        'X-BAPI-API-KEY': apiKey,
        'X-BAPI-SIGN': signature,
        'X-BAPI-SIGN-TYPE': '2',
        'X-BAPI-TIMESTAMP': timestamp,
        'X-BAPI-RECV-WINDOW': recvWindow,
        'Content-Type': 'application/json',
      };

      const response = await axios.get(endpoint, { params, headers });

      if (response.data.retCode === 0) {
        return response.data.result;
      }

      log('WARN', `Attempt ${i + 1}/${retries}: Invalid response from API: retCode=${response.data.retCode}, retMsg=${response.data.retMsg}`);

    } catch (error) {
      log('ERROR', `Attempt ${i + 1}/${retries} failed: ${error.message}`);
      if (i === retries - 1) throw error;
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
  }

  return null;
}

// --- Parse Individual Log Entry ---
function parseLogEntry(entry) {
     const lines = entry.split('\n');
    const entryData = {};

    const indicators = {
        'Exchange:': 'exchange',
        'Symbol:': 'symbol',
        'Interval:': 'interval',
        'Timestamp:': 'timestamp',
        'Current Price:': 'currentPrice',
        'ATR:': 'atr',
        'Trend:': 'trend',
        'OBV:': 'obv',
        'RSI:': 'rsi',
        'MFI:': 'mfi',
        'CCI:': 'cci',
        'Williams %R:': 'williamsR',
        'ADX:': 'adx',
        'ADI:': 'adi'
    };

    for (const line of lines) {
        const trimmedLine = line.trim();

        for (const [prefix, field] of Object.entries(indicators)) {
            if (trimmedLine.startsWith(prefix)) {
                let value = trimmedLine.substring(prefix.length).trim();

                // Parse numeric values
                if (['currentPrice', 'atr'].includes(field)) {
                    value = parseFloat(value);
                    if (isNaN(value)) {
                        log('WARN', `Invalid ${field} found: ${value}. Setting to null.`);
                        value = null; // Set to null for invalid numeric values
                    }
                }

                // Parse indicators with patterns (RSI, MFI, CCI, Williams %R, ADX)
                if (['rsi', 'mfi', 'cci', 'williamsR', 'adx'].includes(field)) {
                    const match = value.match(/\(([-.\d]+)\)/);
                    if (match && match[1]) {
                        value = parseFloat(match[1]);
                         if (isNaN(value)) { //Handling the case where extracted value isn't number
                            log('WARN', `Invalid ${field} found: ${value}. Setting to null.`);
                            value = null;
                        }
                    } else {
                        value = null; // Set to null if pattern not found
                    }
                }

                 if (value === '' || value === 0){
                     log('WARN', `Empty string or zero found in ${field}. Setting to null`)
                     value = null;
                 }
                entryData[field] = value;
                break;
            }
        }
    }

    return entryData;
}

// --- Analyze Order Book Data ---
function analyzeOrderBook(orderBook, currentPrice, atr) {
    const reasoning = [];
    let confidenceBoost = 0;

    if (orderBook && orderBook.asks && orderBook.bids && orderBook.asks.length > 0 && orderBook.bids.length > 0) {
        const asks = orderBook.asks;
        const bids = orderBook.bids;
        const bestAskPrice = parseFloat(asks[0][0]);
        const bestBidPrice = parseFloat(bids[0][0]);
        const askVolume = parseFloat(asks[0][1]);
        const bidVolume = parseFloat(bids[0][1]);
        const spread = bestAskPrice - bestBidPrice;

        // Analyze volumes and spreads
        if (bidVolume > askVolume * orderBookVolumeRatioThreshold) {
            reasoning.push(`High bid volume (${bidVolume.toFixed(2)}) relative to ask volume`);
            confidenceBoost += confidenceBoostPerFactor;
        }

        if ((spread / currentPrice) * 100 < orderBookSpreadThresholdMultiplier * (atr / currentPrice) * 100) {
            reasoning.push(`Tight spread (${(spread / currentPrice * 100).toFixed(4)}%)`);
            confidenceBoost += confidenceBoostPerFactor;
        }
    }

    return { reasoning, confidenceBoost };
}

// --- Check Conditions for a Long Signal ---
function checkLongSignal(prevData, currentData, atr, reasoningParts, confidence) {
     const longReasons = [...reasoningParts];
    let longConfidence = confidence;

    if (prevData.rsi !== null && currentData.rsi !== null && prevData.rsi <= rsiOversoldThreshold && currentData.rsi > rsiOversoldThreshold) {
        longReasons.push(`RSI bounced from oversold (${currentData.rsi.toFixed(2)})`);
        longConfidence += confidenceBoostPerFactor;
    }

    if (currentData.trend && currentData.trend.includes("Downtrend")) {
        longReasons.push("Downtrend present");
        longConfidence += confidenceBoostPerFactor;
    }

  if (prevData.mfi !== null && currentData.mfi !== null && prevData.mfi <= mfiOversoldThreshold && currentData.mfi > mfiOversoldThreshold) {
        longReasons.push(`MFI bounced from oversold (${currentData.mfi.toFixed(2)})`);
        longConfidence += confidenceBoostPerFactor;
    }

    if (longReasons.length > 0) {
        return {
            signalType: "Long",
            symbol: currentData.symbol,
            entryPrice: currentData.currentPrice, //Use currentData
            stopLoss: currentData.currentPrice - (stopLossMultiple * atr),
            takeProfit: currentData.currentPrice + (atr * takeProfitMultiple),
            confidence: Math.min(longConfidence, 10),
            reasoning: longReasons.join(" and "),
            timestamp: currentData.timestamp,
        };
    }

    return null;
}

// --- Check Conditions for a Short Signal ---
function checkShortSignal(prevData, currentData, atr, reasoningParts, confidence) {
    const shortReasons = [...reasoningParts];
    let shortConfidence = confidence;

    if (prevData.rsi !== null && currentData.rsi !== null && prevData.rsi >= rsiOverboughtThreshold && currentData.rsi < rsiOverboughtThreshold) {
        shortReasons.push(`RSI dropped from overbought (${currentData.rsi.toFixed(2)})`);
        shortConfidence += confidenceBoostPerFactor;
    }

    if (currentData.trend && currentData.trend.includes("Uptrend")) {
        shortReasons.push("Uptrend present");
        shortConfidence += confidenceBoostPerFactor;
    }

    if (prevData.mfi !== null && currentData.mfi !== null && prevData.mfi >= mfiOverboughtThreshold && currentData.mfi < mfiOverboughtThreshold) {
        shortReasons.push(`MFI dropped from overbought (${currentData.mfi.toFixed(2)})`);
        shortConfidence += confidenceBoostPerFactor;
    }

    if (shortReasons.length > 0) {
        return {
            signalType: "Short",
            symbol: currentData.symbol,
            entryPrice: currentData.currentPrice, // Use currentData
            stopLoss: currentData.currentPrice + (stopLossMultiple * atr),
            takeProfit: currentData.currentPrice - (atr * takeProfitMultiple),
            confidence: Math.min(shortConfidence, 10),
            reasoning: shortReasons.join(" and "),
            timestamp: currentData.timestamp,
        };
    }

    return null;
}

// --- Generate Scalping Signals ---
function generateScalpingSignal(prevData, currentData, atrValues) {
    if (!currentData.symbol || currentData.currentPrice === null || currentData.atr === null) {
        return null;
    }

    const atr = currentData.atr;
    let reasoningParts = [];
    let confidence = baseConfidence;

    // Optional Order Book Analysis
    if (currentData.orderBook) {
        const { reasoning: orderBookReasoning, confidenceBoost } = analyzeOrderBook(currentData.orderBook, currentData.currentPrice, atr);
        if (orderBookReasoning.length > 0) {
            reasoningParts.push(...orderBookReasoning);
            confidence += confidenceBoost;
        }
    }

    // Check for cooldown
    const now = Date.now();
    if (now - lastSignalTimestamp < signalCooldownMs) {
        log('DEBUG', `Signal cooldown active for ${currentData.symbol}`);
        return null;
    }

    // Generate Long Signal
    const longSignal = checkLongSignal(prevData, currentData, atr, reasoningParts, confidence);
    if (longSignal) {
      lastSignalTimestamp = now;
      return longSignal;
    }
    // Generate Short Signal
    const shortSignal = checkShortSignal(prevData, currentData, atr, reasoningParts, confidence);
    if (shortSignal) {
      lastSignalTimestamp = now;
      return shortSignal;
    }

    return null;
}
// --- Check for Significant Changes ---
function hasSignificantChanges(newEntryData, cachedEntryData) {
    if (!cachedEntryData) {
        return true; // First entry, always significant
    }

    // Price change check
    if (newEntryData.currentPrice !== null && cachedEntryData.currentPrice !== null) {
        const priceChangePercent = Math.abs((newEntryData.currentPrice - cachedEntryData.currentPrice) / cachedEntryData.currentPrice);
        if (priceChangePercent >= priceChangeThreshold) {
            return true;
        }
    }

    // ATR change check
    if (newEntryData.atr !== null && cachedEntryData.atr !== null) {
        const atrChangePercent = Math.abs((newEntryData.atr - cachedEntryData.atr) / cachedEntryData.atr);
        if (atrChangePercent >= atrChangeThreshold) {
            return true;
        }
    }
    // Add checks for other indicators as needed

    return false; // No significant changes
}
// --- Main Log Analysis Loop ---
function startLogAnalysisLoop() {
    // Check if the log file exists
    if (!fs.existsSync(filePath)) {
        log('ERROR', `Log file not found: ${filePath}`);
        return; // Exit if the file doesn't exist
    }

    setInterval(async () => { //Asynchronous setInterval callback
        fs.readFile(filePath, 'utf8', async (err, data) => {
            if (err) {
                log('ERROR', `Failed to read the file: ${filePath}`, err);
                return;
            }

            try {
                const cleanData = data.replace(/\x1b\[[0-9;]*m/g, ''); // Remove ANSI escape codes
                const logEntries = cleanData.split(/(?=\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} - INFO -)/); // Split into entries

                const signals = [];
                let previousEntryData = null;
                let atrValues = [];

                for (const entry of logEntries) {
                    if (!entry.trim()) continue; // Skip empty entries

                    const entryData = parseLogEntry(entry);

                    // --- Significant Change Check ---
                    if (!hasSignificantChanges(entryData, cachedEntryData)) {
                        log('DEBUG', `Skipping entry for ${entryData.symbol}: No significant changes`);
                        continue; // Skip to the next entry
                    }
                    cachedEntryData = entryData; // Update cache


                    if (entryData.symbol) {
                      try {
                        const orderBook = await getBybitOrderBook(entryData.symbol); //Simplified to one call due to debounce
                        entryData.orderBook = orderBook;
                      } catch (apiError){
                        log('WARN', `Failed to fetch order book for ${entryData.symbol}: ${apiError.message}`);
                        entryData.orderBook = null;
                      }
                    }


                    if (entryData.atr !== null) {
                        atrValues.push(entryData.atr);
                        if (atrValues.length > atrLookbackPeriod) {
                            atrValues.shift(); // Keep only the last 'atrLookbackPeriod' values
                        }
                    }

                    // Ensure we have previous data and current price before generating a signal
                    if (previousEntryData && entryData.currentPrice !== null) {
                        const signal = generateScalpingSignal(previousEntryData, entryData, atrValues);
                        if (signal) {
                            signals.push(signal);
                        }
                    }

                    previousEntryData = entryData; // Update previous entry
                }

                log('INFO', JSON.stringify(signals, null, 2)); // Output signals
            } catch (processingError) {
                log('ERROR', 'Error processing log data:', processingError);
            }
        });
    }, analysisInterval);
}
// --- Start the Analysis ---
startLogAnalysisLoop();
