const fs = require('fs');

// Configuration variables
const filePath = 'whalebot.txt'; // Path to the log file
const analysisInterval = 5000;  // milliseconds (5 seconds) - how often to analyze
const stopLossMultiple = 2; // Multiple of ATR for stop loss
const confidenceBoost = 0.10; // How much to increase confidence if the reasoning includes multiple factors.

/**
 * Analyzes a log file, extracts trading data, generates scalping signals, and
 * outputs the signals with stop loss, entry price, confidence level, and reasoning,
 * running in a loop.
 */
function startLogAnalysisLoop() {
    setInterval(() => {
        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) {
                console.error(`Failed to read the file: ${filePath}`, err);
                return;
            }

            // Remove ANSI escape codes
            const cleanData = data.replace(/\x1b\[[0-9;]*m/g, '');

            // Split into log entries
            const logEntries = cleanData.split(/(?=\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} - INFO -)/);

            const signals = [];

            // Keep track of the previous entry for signal generation
            let previousEntryData = null;

            logEntries.forEach(entry => {
                if (!entry.trim()) return;

                const lines = entry.split('\n');
                const entryData = {};

                lines.forEach(line => {
                    line = line.trim();

                    if (line.startsWith('Exchange:')) {
                        entryData.exchange = line.substring('Exchange:'.length).trim();
                    } else if (line.startsWith('Symbol:')) {
                        entryData.symbol = line.substring('Symbol:'.length).trim();
                    } else if (line.startsWith('Interval:')) {
                        entryData.interval = line.substring('Interval:'.length).trim();
                    } else if (line.startsWith('Timestamp:')) {
                        entryData.timestamp = line.substring('Timestamp:'.length).trim();
                    } else if (line.startsWith('Current Price:')) {
                        const priceStr = line.substring('Current Price:'.length).trim();
                        entryData.currentPrice = parseFloat(priceStr);
                        if (isNaN(entryData.currentPrice)) {
                            console.warn(`Invalid Current Price found: ${priceStr}`);
                        }
                    } else if (line.startsWith('ATR:')) {
                        const atrStr = line.substring('ATR:'.length).trim();
                        entryData.atr = parseFloat(atrStr);
                        if (isNaN(entryData.atr)) {
                            console.warn(`Invalid ATR found: ${atrStr}`);
                        }
                    } else if (line.startsWith('Trend:')) {
                        entryData.trend = line.substring('Trend:'.length).trim();
                    } else if (line.startsWith('OBV:')) {
                        entryData.obv = line.substring('OBV:'.length).trim();
                    } else if (line.startsWith('RSI:')) {
                        const rsiStr = line.substring('RSI:'.length).trim();
                        const rsiMatch = rsiStr.match(/\(([\d.]+)\)/);
                        if (rsiMatch && rsiMatch[1]) {
                            entryData.rsi = parseFloat(rsiMatch[1]);
                        } else {
                            entryData.rsi = rsiStr;
                        }
                    } else if (line.startsWith('MFI:')) {
                        const mfiStr = line.substring('MFI:'.length).trim();
                        const mfiMatch = mfiStr.match(/\(([\d.]+)\)/);
                        if (mfiMatch && mfiMatch[1]) {
                            entryData.mfi = parseFloat(mfiMatch[1]);
                        } else {
                            entryData.mfi = mfiStr;
                        }
                    } else if (line.startsWith('CCI:')) {
                        const cciStr = line.substring('CCI:'.length).trim();
                        const cciMatch = cciStr.match(/\(([-.\d]+)\)/);
                        if (cciMatch && cciMatch[1]) {
                            entryData.cci = parseFloat(cciMatch[1]);
                        } else {
                            entryData.cci = cciStr;
                        }
                    } else if (line.startsWith('Williams %R:')) {
                        const williamsRStr = line.substring('Williams %R:'.length).trim();
                        const williamsRMatch = williamsRStr.match(/\(([-.\d]+)\)/);
                        if (williamsRMatch && williamsRMatch[1]) {
                            entryData.williamsR = parseFloat(williamsRMatch[1]);
                        } else {
                            entryData.williamsR = williamsRStr;
                        }
                    } else if (line.startsWith('ADX:')) {
                        const adxStr = line.substring('ADX:'.length).trim();
                        const adxMatch = adxStr.match(/\(([\d.]+)\)/);
                        if (adxMatch && adxMatch[1]) {
                            entryData.adx = parseFloat(adxMatch[1]);
                        } else {
                            entryData.adx = adxStr;
                        }
                    } else if (line.startsWith('ADI:')) {
                        entryData.adi = line.substring('ADI:'.length).trim();
                    }
                });

                // Generate signal if we have a previous entry
                if (previousEntryData && entryData.currentPrice) {
                    const signal = generateScalpingSignal(previousEntryData, entryData);
                    if (signal) {
                        signals.push(signal);
                    }
                }

                previousEntryData = entryData; // Store current entry for next iteration
            });

            console.log(JSON.stringify(signals, null, 2));
        });
    }, analysisInterval);
}

/**
 * Generates a scalping signal based on technical indicators.
 *
 * @param {object} prevData The previous log entry data.
 * @param {object} currentData The current log entry data.
 * @returns {object|null} A scalping signal object, or null if no signal is generated.
 */
function generateScalpingSignal(prevData, currentData) {
    const symbol = currentData.symbol;
    const currentPrice = currentData.currentPrice;
    const atr = currentData.atr;

    let reasoningParts = []; //Array to store the reasoning parts

    let confidence = 0.5;  //Base Confidence.

    // Example scalping strategy:  Oversold RSI and downtrend suggests potential bounce
    if (prevData.rsi <= 30 && currentData.rsi > 30) {
        reasoningParts.push("RSI bounced from oversold territory");
    }

    if (currentData.trend.includes("Downtrend")) {
        reasoningParts.push("Overall Downtrend present");
    }

    if (reasoningParts.length > 0){ //Signal logic
      const stopLoss = currentPrice - (stopLossMultiple * atr);
      const entryPrice = currentPrice; // Enter at the current price
      let reasoning = reasoningParts.join(" and ");
        if (reasoningParts.length > 1) {
            confidence += confidenceBoost;  //Increase Confidence
        }

        return {
            signalType: "Long",
            symbol: symbol,
            entryPrice: entryPrice,
            stopLoss: stopLoss,
            takeProfit: entryPrice + (atr * 1.5), //Arbitrary Take Profit
            confidence: Math.min(confidence, 1.0), //Cap Confidence at 1.0
            reasoning: reasoning,
            timestamp: currentData.timestamp
        };
    }


    // Example scalping strategy: Overbought RSI and uptrend suggests potential pullback
      reasoningParts = []; //Reset

    if (prevData.rsi >= 70 && currentData.rsi < 70) {
        reasoningParts.push("RSI dropped from overbought territory");
    }
    if (currentData.trend.includes("Uptrend")) {
        reasoningParts.push("Overall Uptrend present");
    }

      if (reasoningParts.length > 0) { //Signal logic
        const stopLoss = currentPrice + (stopLossMultiple * atr);
        const entryPrice = currentPrice;
        let reasoning = reasoningParts.join(" and ");
        if (reasoningParts.length > 1) {
            confidence += confidenceBoost;  //Increase Confidence
        }
        return {
            signalType: "Short",
            symbol: symbol,
            entryPrice: entryPrice,
            stopLoss: stopLoss,
            takeProfit: entryPrice - (atr * 1.5), //Arbitrary Take Profit
            confidence: Math.min(confidence, 1.0),  //Cap Confidence at 1.0
            reasoning: reasoning,
            timestamp: currentData.timestamp
        };
    }

    return null; // No signal generated
}

// Start the analysis loop
startLogAnalysisLoop();
