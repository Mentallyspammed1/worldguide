import curses
import time
from datetime import datetime
from typing import Dict
from bybit_client import BybitClient

class TradingTerminal:
    def __init__(self):
        self.client = None
        self.running = True
        self.market_data = {
            'symbol': 'BTCUSDT',
            'bid': '--',
            'ask': '--',
            'last': '--',
            'volume': '--',
            'change': '--'
        }
        self.positions = {}
        self.orders = []

    def init_client(self):
        """Initialize trading client with error handling"""
        try:
            self.client = BybitClient()
            self.client.subscribe_market_data(
                self.market_data['symbol'],
                {
                    'orderbook': self.handle_orderbook,
                    'ticker': self.handle_ticker
                }
            )
        except Exception as e:
            self.show_error(f"Initialization failed: {str(e)}")
            self.shutdown()

    def handle_orderbook(self, data: Dict):
        """Process orderbook updates"""
        if 'data' in data:
            book = data['data']
            self.market_data['bid'] = book['b'][0][0]
            self.market_data['ask'] = book['a'][0][0]

    def handle_ticker(self, data: Dict):
        """Process ticker updates"""
        if 'data' in data:
            ticker = data['data']
            self.market_data.update({
                'last': ticker['lastPrice'],
                'volume': ticker['volume24h'],
                'change': f"{float(ticker['price24hPcnt']) * 100:.2f}%"
            })

    def show_error(self, message: str):
        """Display error messages"""
        print(f"\nERROR: {message}\n")

    def init_ui(self, stdscr):
        """Initialize terminal UI"""
        curses.curs_set(0)
        stdscr.nodelay(1)
        self.windows = {
            'market': curses.newwin(8, 50, 0, 0),
            'orderbook': curses.newwin(15, 30, 8, 0),
            'positions': curses.newwin(10, 50, 0, 51),
            'orders': curses.newwin(15, 50, 10, 51),
            'log': curses.newwin(5, 80, 18, 0)
        }
        self.draw_borders()

    def draw_borders(self):
        """Draw window borders"""
        for win in self.windows.values():
            win.border()
            win.refresh()

    def update_market_display(self):
        """Update market data window"""
        win = self.windows['market']
        win.addstr(1, 2, f"SYMBOL: {self.market_data['symbol']}")
        win.addstr(2, 2, f"Bid/Ask: {self.market_data['bid']} / {self.market_data['ask']}")
        win.addstr(3, 2, f"Last Price: {self.market_data['last']}")
        win.addstr(4, 2, f"24h Change: {self.market_data['change']}")
        win.addstr(5, 2, f"24h Volume: {self.market_data['volume']}")
        win.refresh()

    def run(self):
        """Main application loop"""
        self.init_client()
        curses.wrapper(self.ui_loop)

    def ui_loop(self, stdscr):
        """Curses UI main loop"""
        self.init_ui(stdscr)
        while self.running:
            self.update_market_display()
            self.handle_input(stdscr)
            time.sleep(0.1)

    def handle_input(self, stdscr):
        """Process user input"""
        key = stdscr.getch()
        if key == ord('q'):
            self.shutdown()
        elif key == ord('b'):
            self.execute_order('Buy')
        elif key == ord('s'):
            self.execute_order('Sell')

    def execute_order(self, side: str):
        """Execute market order"""
        if self.client:
            result = self.client.place_market_order(
                symbol=self.market_data['symbol'],
                side=side,
                qty=0.001
            )
            if result:
                self.log_order(f"{side} order executed: {result['orderId']}")

    def log_order(self, message: str):
        """Log order execution"""
        win = self.windows['log']
        win.addstr(1, 2, f"{datetime.now().strftime('%H:%M:%S')} - {message}")
        win.refresh()

    def shutdown(self):
        """Clean shutdown procedure"""
        self.running = False
        if self.client:
            self.client.shutdown()
        exit()

if __name__ == "__main__":
    terminal = TradingTerminal()
    terminal.run()
