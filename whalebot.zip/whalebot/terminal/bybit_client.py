import os
import logging
from typing import Dict, List, Callable, Optional
from pybit.unified_trading import HTTP, WebSocket, WebSocketTrading
from dotenv import load_dotenv

load_dotenv()

class BybitClient:
    """Bybit API client for production trading"""
    
    def __init__(self):
        """
        Initialize Bybit client with production environment
        """
        self.api_key = os.getenv("BYBIT_API_KEY")
        self.api_secret = os.getenv("BYBIT_API_SECRET")
        self._validate_credentials()
        self._init_connections()
        self.logger = self._configure_logging()

    def _configure_logging(self):
        """Set up logging system"""
        logger = logging.getLogger("BybitClient")
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        
        # Console handler
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        logger.addHandler(ch)
        
        return logger

    def _validate_credentials(self):
        """Validate API credentials format"""
        if not self.api_key or not self.api_secret:
            raise ValueError("API credentials missing from .env file")
        if len(self.api_key) != 36 or len(self.api_secret) != 64:
            raise ValueError("Invalid API credentials format")

    def _init_connections(self):
        """Initialize all API connections"""
        try:
            # Initialize REST client
            self.http = HTTP(
                api_key=self.api_key,
                api_secret=self.api_secret,
                testnet=False
            )
            
            # Initialize public WebSocket
            self.ws_public = WebSocket(
                testnet=False,
                channel_type="linear",
                api_key=self.api_key
            )
            
            # Initialize private WebSocket
            self.ws_private = WebSocketTrading(
                testnet=False,
                api_key=self.api_key,
                api_secret=self.api_secret
            )
            
            self.logger.info("Successfully connected to Bybit production environment")
            
        except Exception as e:
            self.logger.error(f"Connection initialization failed: {str(e)}")
            raise

    def get_account_balance(self) -> Dict:
        """Get current account balance"""
        try:
            response = self.http.get_wallet_balance(accountType="CONTRACT", coin="USDT")
            if response['retCode'] == 0:
                return response['result']['list'][0]['coin'][0]
            return {}
        except Exception as e:
            self.logger.error(f"Failed to get balance: {str(e)}")
            return {}

    def subscribe_market_data(self, symbol: str, callbacks: Dict[str, Callable]):
        """Subscribe to real-time market data"""
        try:
            # Orderbook subscription
            self.ws_public.orderbook_stream(
                depth=25,
                symbol=symbol,
                callback=callbacks.get('orderbook')
            )
            # Ticker subscription
            self.ws_public.ticker_stream(
                symbol=symbol,
                callback=callbacks.get('ticker')
            )
            self.logger.info(f"Subscribed to {symbol} market data")
        except Exception as e:
            self.logger.error(f"Market data subscription failed: {str(e)}")
            raise

    def shutdown(self):
        """Gracefully close all connections"""
        try:
            self.ws_public.exit()
            self.ws_private.exit()
            self.logger.info("WebSocket connections closed")
        except Exception as e:
            self.logger.error(f"Shutdown error: {str(e)}")

    def place_market_order(self, symbol: str, side: str, qty: float) -> Dict:
        """Execute market order with validation"""
        try:
            if qty <= 0:
                raise ValueError("Order quantity must be positive")

            response = self.http.place_order(
                category="linear",
                symbol=symbol,
                side=side.capitalize(),
                orderType="Market",
                qty=str(qty),
                timeInForce="GTC"
            )
            
            if response['retCode'] != 0:
                self.logger.error(f"Order failed: {response['retMsg']}")
                return {}
            
            return response['result']
            
        except Exception as e:
            self.logger.error(f"Order execution error: {str(e)}")
            return {}
