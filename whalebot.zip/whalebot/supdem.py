import os
import time
import datetime
import logging
import sys
import asyncio
import pandas as pd
from dotenv import load_dotenv
from pybit.unified_trading import HTTP
from colorama import Fore, Style, init
import requests  # Import the requests library

init(autoreset=True)


class Neon:
    GREEN = Fore.GREEN + Style.BRIGHT
    CYAN = Fore.CYAN + Style.BRIGHT
    MAGENTA = Fore.MAGENTA + Style.BRIGHT
    YELLOW = Fore.YELLOW + Style.BRIGHT
    RED = Fore.RED + Style.BRIGHT
    BLUE = Fore.BLUE + Style.BRIGHT  # Corrected this line
    WHITE = Fore.WHITE + Style.BRIGHT
    RESET = Style.RESET_ALL


load_dotenv()
API_KEY = os.getenv("BYBIT_API_KEY")
API_SECRET = os.getenv("BYBIT_API_SECRET")
TESTNET = os.getenv("TESTNET", "false").lower() == "true"


def get_valid_input(prompt, data_type, validation_func=None, error_message=None):
    while True:
        try:
            value = data_type(input(f"{Neon.CYAN}{prompt}{Neon.RESET}"))
            if validation_func is None or validation_func(value):
                return value
            else:
                print(f"{Neon.RED}{error_message or 'Invalid input.'}{Neon.RESET}")
        except ValueError:
            print(f"{Neon.RED}Invalid input type. Please enter a valid {data_type.__name__}.{Neon.RESET}")


def get_env_var(var_name, default_value, data_type):
    try:
        return data_type(os.getenv(var_name, default_value))
    except (TypeError, ValueError) as e:
        print(
            f"{Neon.RED}Error reading {var_name}: {e}. Using default value: {default_value}{Neon.RESET}")
        return data_type(default_value)


# --- Constants ---
SYMBOL = get_valid_input("Enter the trading symbol (e.g., BTCUSDT): ", str, lambda x: x.strip(),
                         "Symbol cannot be empty.").upper().strip()
TIMEFRAME = get_valid_input("Enter the timeframe in minutes (e.g., 1, 5, 15): ", int, lambda x: x > 0,
                             "Timeframe must be positive.")
RISK_PER_TRADE = get_env_var("RISK_PER_TRADE", 0.01, float)
LOOKBACK_PERIOD = get_env_var("LOOKBACK_PERIOD", 100, int)
ZONE_CONFIRMATION_PERIODS = get_env_var("ZONE_CONFIRMATION_PERIODS", 10, int)
ZONE_PROXIMITY_PERCENT = get_env_var("ZONE_PROXIMITY_PERCENT", 0.01, float)
REWARD_RISK_RATIO = get_env_var("REWARD_RISK_RATIO", 1.0, float)
ORDER_CANCEL_DELAY = get_env_var("ORDER_CANCEL_DELAY", 30, int)
STOCH_RSI_K = get_env_var("STOCH_RSI_K", 3, int)
STOCH_RSI_D = get_env_var("STOCH_RSI_D", 3, int)
STOCH_RSI_PERIOD = get_env_var("STOCH_RSI_PERIOD", 14, int)
VOLUME_THRESHOLD = get_env_var("VOLUME_THRESHOLD", 1.5, float)
MIN_ZONE_WIDTH_PERCENT = get_env_var("MIN_ZONE_WIDTH_PERCENT", 0.005, float)
LOG_DIR = "logs"
MAX_RETRIES = 3  # Retries for data fetching
RETRY_DELAY = 5  # Delay between retries (in seconds)
API_TIMEOUT = 15  # Timeout for API requests (in seconds)


# --- Logging Setup ---
def setup_logger(symbol, log_dir):
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_filename = os.path.join(log_dir, f"{symbol}_{timestamp}.log")
    logger = logging.getLogger(symbol)
    logger.setLevel(logging.DEBUG)

    class ColorFormatter(logging.Formatter):
        def format(self, record):
            log_message = super().format(record)
            if record.levelno == logging.WARNING:
                return f"{Neon.YELLOW}{log_message}{Neon.RESET}"
            elif record.levelno == logging.ERROR or record.levelno == logging.CRITICAL:
                return f"{Neon.RED}{log_message}{Neon.RESET}"
            elif record.levelno == logging.DEBUG:
                return f"{Neon.CYAN}{log_message}{Neon.RESET}"
            else:
                return f"{Neon.GREEN}{log_message}{Neon.RESET}"

    formatter = ColorFormatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    file_handler = logging.FileHandler(log_filename)
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)  # Set console handler to INFO level
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    return logger


logger = setup_logger(SYMBOL, LOG_DIR)


# --- Bybit Session ---
def create_session():
    try:
        session = HTTP(testnet=TESTNET, api_key=API_KEY, api_secret=API_SECRET)
        session.request_timeout = API_TIMEOUT  # Set the timeout after creating the session
        return session
    except Exception as e:
        logger.critical(f"Failed to create Bybit session: {e}", exc_info=True)
        sys.exit(1)


session = create_session()


# --- Data Retrieval ---
def get_historical_data(symbol, timeframe, periods):
    for attempt in range(MAX_RETRIES):
        try:
            now = int(time.time() * 1000)
            since = now - (timeframe * 60 * 1000 * periods)
            result = session.get_kline(symbol=symbol, interval=str(timeframe), start=since, category="linear")
            if result['retCode'] == 0:
                klines = result['result']['list']
                columns = ['startTime', 'open', 'high', 'low', 'close', 'volume', 'turnover']
                df = pd.DataFrame(klines, columns=columns)
                if 'volume' not in df.columns:
                    logger.error("Volume column is missing in klines DataFrame.")
                    return pd.DataFrame()
                # Convert numeric columns to appropriate types.  Error if conversion fails.
                for col in columns[1:]:  # Exclude 'startTime'
                    df[col] = pd.to_numeric(df[col], errors='raise')
                return df
            else:
                logger.error(f"Error fetching historical data (attempt {attempt + 1}): {result['retMsg']}")

        except requests.exceptions.ReadTimeout as e:  # Catch the specific timeout exception
            logger.error(f"Timeout error fetching kline data (attempt {attempt + 1}): {e}")

        except Exception as e:
            logger.error(f"Error fetching kline data (attempt {attempt + 1}): {e}", exc_info=True)

        if attempt < MAX_RETRIES - 1:  # Don't sleep after the last attempt
            time.sleep(RETRY_DELAY)

    logger.error(f"Failed to fetch historical data after {MAX_RETRIES} retries.")  # Log failure after all retries
    return pd.DataFrame()


def get_current_price(symbol):
    for attempt in range(MAX_RETRIES):
        try:
            result = session.get_tickers(symbol=symbol, category="linear")
            if result and result['retCode'] == 0:
                return float(result['result']['list'][0]['lastPrice'])
            logger.error(f"Could not get price (attempt {attempt + 1}): {result.get('retMsg', 'Unknown error')}")

        except requests.exceptions.ReadTimeout as e:
            logger.error(f"Timeout error getting current price (attempt {attempt + 1}): {e}")

        except Exception as e:
            logger.error(f"Error getting price (attempt {attempt + 1}): {e}", exc_info=True)

        if attempt < MAX_RETRIES - 1:
            time.sleep(RETRY_DELAY)

    logger.error(f"Failed to get current price after {MAX_RETRIES} retries")
    return None


# --- Calculations ---
def calculate_stoch_rsi(data, period, k_period, d_period):
    if data.empty or len(data) < period + k_period + d_period:
        return None, None

    df = data.copy()
    # Ensure 'close' is numeric; otherwise, calculations will fail.
    df['close'] = pd.to_numeric(df['close'], errors='raise')
    df['rsi'] = calculate_rsi(df['close'], period)

    if df['rsi'].isnull().any():
        return None, None

    df['lowest_rsi'] = df['rsi'].rolling(window=period).min()
    df['highest_rsi'] = df['rsi'].rolling(window=period).max()

    mask = df['highest_rsi'] != df['lowest_rsi']
    df.loc[mask, 'stoch_rsi'] = 100 * (df.loc[mask, 'rsi'] - df.loc[mask, 'lowest_rsi']) / (
            df.loc[mask, 'highest_rsi'] - df.loc[mask, 'lowest_rsi'])
    df['stoch_rsi'] = df['stoch_rsi'].fillna(0)
    df['stoch_rsi_k'] = df['stoch_rsi'].rolling(window=k_period).mean()
    df['stoch_rsi_d'] = df['stoch_rsi_k'].rolling(window=d_period).mean()
    return df['stoch_rsi_k'].iloc[-1], df['stoch_rsi_d'].iloc[-1]


def calculate_rsi(data, period):
    delta = data.diff()
    gain = (delta.where(delta > 0, 0)).fillna(0)
    loss = (-delta.where(delta < 0, 0)).fillna(0)
    avg_gain = gain.rolling(window=period, min_periods=1).mean()
    avg_loss = loss.rolling(window=period, min_periods=1).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi


def calculate_average_volume(data, volume_period=20):
    if data.empty or len(data) < volume_period:
        return 0
    df = data.copy()
    if 'volume' not in df.columns:
        logger.error("Volume column is missing in average volume calc")
        return 0
    df['volume'] = pd.to_numeric(df['volume'], errors='raise')  # Ensure volume is numeric
    return df['volume'].tail(volume_period).mean()


def identify_supply_demand_zones(data, confirmation_periods):
    if data.empty or len(data) < confirmation_periods:
        return [], []
    df = data.copy()
    for col in ['open', 'high', 'low', 'close']:
        df[col] = pd.to_numeric(df[col], errors='raise')  # Ensure numeric types
    supply_zones, demand_zones = [], []
    for i in range(1, len(df) - confirmation_periods):
        if (df['close'][i] > df['open'][i] and
                all(df['high'][i + j] > df['high'][i] for j in range(1, confirmation_periods))):
            demand_zones.append((df['low'][i], df['high'][i]))
        if (df['close'][i] < df['open'][i] and
                all(df['low'][i + j] < df['low'][i] for j in range(1, confirmation_periods))):
            supply_zones.append((df['low'][i], df['high'][i]))
    return supply_zones, demand_zones


# --- Wallet & Order Management ---
def get_wallet_balance(coin="USDT"):
    for attempt in range(MAX_RETRIES):
        try:
            result = session.get_wallet_balance(accountType="UNIFIED", coin=coin)
            if result['retCode'] == 0:
                balance_data = result['result']['list'][0]['coin']
                for c in balance_data:
                    if c['coin'] == coin:
                        return float(c['availableToWithdraw'])
                return 0  # Coin not found, but request successful
            logger.warning(f"Failed to get balance (attempt {attempt + 1}): {result['retMsg']}. Retrying...")

        except requests.exceptions.ReadTimeout as e:
            logger.error(f"Timeout error getting wallet balance (attempt {attempt + 1}): {e}")

        except Exception as e:
            logger.error(f"Error getting balance (attempt {attempt + 1}): {e}. Retrying...")
        time.sleep(RETRY_DELAY)
    logger.error(f"Failed to get balance after {MAX_RETRIES} retries.")
    return None


async def place_order(symbol, side, order_type, qty, price=None, time_in_force="GoodTillCancel",
                      reduce_only=False, close_on_trigger=False, stop_loss=None, take_profit=None):
    for attempt in range(MAX_RETRIES):
        try:
            order_params = {
                "category": "linear",
                "symbol": symbol,
                "side": side,
                "orderType": order_type,
                "qty": str(qty),
                "timeInForce": time_in_force,
                "reduceOnly": reduce_only,
                "closeOnTrigger": close_on_trigger
            }
            if price:
                order_params['price'] = str(price)
            if stop_loss:
                order_params['stopLoss'] = str(stop_loss)
            if take_profit:
                order_params['takeProfit'] = str(take_profit)
            result = session.place_order(**order_params)
            if result['retCode'] == 0:
                logger.info(f"Order placed successfully: {result['result']}")
                return result['result']
            logger.warning(f"Failed to place order (attempt {attempt + 1}): {result['retMsg']}. Retrying...")
        except requests.exceptions.ReadTimeout as e:
            logger.error(f"Timeout error placing order (attempt {attempt + 1}): {e}")
        except Exception as e:
            logger.error(f"Error placing order (attempt {attempt + 1}): {e}. Retrying...")
        await asyncio.sleep(RETRY_DELAY)
    logger.error(f"Failed to place order after {MAX_RETRIES} retries.")
    return None


def cancel_order(order_id, symbol):
    for attempt in range(MAX_RETRIES):
        try:
            result = session.cancel_order(category="linear", symbol=symbol, orderId=order_id)
            if result['retCode'] == 0:
                logger.info(f"Order {order_id} cancelled successfully.")
                return True
            else:
                logger.warning(f"Failed to cancel order {order_id} (attempt {attempt + 1}): {result['retMsg']}.")

        except requests.exceptions.ReadTimeout as e:
            logger.error(f"Timeout during order cancellation (attempt {attempt + 1}): {e}")
        except Exception as e:
            logger.error(f"Error cancelling order {order_id} (attempt {attempt + 1}): {e}")
        if attempt < MAX_RETRIES - 1:
            time.sleep(RETRY_DELAY)

    logger.error(f"Failed to cancel order after {MAX_RETRIES} retries")
    return False


def calculate_position_size(account_balance, risk_per_trade, entry_price, stop_loss_price):
    if abs(entry_price - stop_loss_price) < 1e-6:
        logger.warning(f"Entry and stop prices are too close.")
        return 0
    risk_amount = account_balance * risk_per_trade
    price_difference = abs(entry_price - stop_loss_price)
    quantity = risk_amount / price_difference
    return quantity


def is_price_near_zone(price, zone, proximity_percent):
    proximity = price * proximity_percent
    lower_bound = min(zone) - proximity
    upper_bound = max(zone) + proximity
    return lower_bound <= price <= upper_bound


def color_code_zone(zone):
    return f"{Neon.GREEN}[{zone[0]:.5f}, {zone[1]:.5f}]{Neon.RESET}"


async def async_sleep(seconds):
    await asyncio.sleep(seconds)


# --- Strategy Execution ---
async def run_strategy():
    logger.info(
        f"Starting Supply/Demand Scalping strategy for {SYMBOL} on timeframe {TIMEFRAME}")
    in_position = False
    current_side = None
    open_order_id = None
    order_placed_time = None

    while True:
        try:
            klines = get_historical_data(SYMBOL, TIMEFRAME, LOOKBACK_PERIOD)
            if klines.empty:
                logger.warning(f"No kline data. Waiting...")
                await async_sleep(60)
                continue

            current_price = get_current_price(SYMBOL)
            if current_price is None:
                logger.warning(f"Could not get price. Waiting...")
                await async_sleep(60)
                continue

            stoch_rsi_k, stoch_rsi_d = calculate_stoch_rsi(klines, STOCH_RSI_PERIOD, STOCH_RSI_K,
                                                            STOCH_RSI_D)
            average_volume = calculate_average_volume(klines)

            if 'volume' not in klines.columns:
                logger.error("Volume column is missing after get_historical_data")
                current_volume = 0  # Default to 0 if volume is missing
            else:
                current_volume = float(klines['volume'].iloc[-1])  # Ensure it is a float

            supply_zones, demand_zones = identify_supply_demand_zones(klines, ZONE_CONFIRMATION_PERIODS)

            # Filter zones by minimum width
            supply_zones = [(low, high) for low, high in supply_zones if
                            high - low > MIN_ZONE_WIDTH_PERCENT * current_price]
            demand_zones = [(low, high) for low, high in demand_zones if
                            high - low > MIN_ZONE_WIDTH_PERCENT * current_price]

            # Sort zones by proximity to current price, take top 6
            supply_zones = sorted(supply_zones, key=lambda zone: abs(current_price - (zone[0] + zone[1]) / 2))[:6]
            demand_zones = sorted(demand_zones, key=lambda zone: abs(current_price - (zone[0] + zone[1]) / 2))[:6]

            logger.debug(
                f"Nearest Supply Zones: {[color_code_zone(zone) for zone in supply_zones]}")
            logger.debug(
                f"Nearest Demand Zones: {[color_code_zone(zone) for zone in demand_zones]}")

            if not in_position:
                for zone in demand_zones:
                    if (is_price_near_zone(current_price, zone, ZONE_PROXIMITY_PERCENT) and
                            stoch_rsi_k is not None and stoch_rsi_d is not None and stoch_rsi_k < stoch_rsi_d and
                            current_volume > average_volume * VOLUME_THRESHOLD):
                        account_balance = get_wallet_balance()
                        if account_balance is None:
                            logger.error(f"Could not retrieve account balance.")
                            break

                        entry_price = zone[1]
                        stop_loss_price = zone[0]
                        take_profit_price = entry_price + (
                                entry_price - stop_loss_price) * REWARD_RISK_RATIO
                        position_size = calculate_position_size(account_balance, RISK_PER_TRADE,
                                                                entry_price, stop_loss_price)

                        if position_size > 0:
                            order_result = await place_order(SYMBOL, "Buy", "Limit", position_size,
                                                             price=entry_price,
                                                             stop_loss=stop_loss_price,
                                                             take_profit=take_profit_price)

                            if order_result:
                                in_position = True
                                current_side = "Buy"
                                open_order_id = order_result.get('orderId')
                                order_placed_time = datetime.datetime.now()

                                logger.info(
                                    f"Placed Buy Limit Order at {entry_price}  Order ID: {open_order_id}")
                            break

                for zone in supply_zones:
                    if (is_price_near_zone(current_price, zone, ZONE_PROXIMITY_PERCENT) and
                            stoch_rsi_k is not None and stoch_rsi_d is not None and stoch_rsi_k > stoch_rsi_d and
                            current_volume > average_volume * VOLUME_THRESHOLD):
                        account_balance = get_wallet_balance()
                        if account_balance is None:
                            logger.error(f"Could not retrieve account balance.")
                            break

                        entry_price = zone[0]
                        stop_loss_price = zone[1]
                        take_profit_price = entry_price - (
                                stop_loss_price - entry_price) * REWARD_RISK_RATIO
                        position_size = calculate_position_size(account_balance, RISK_PER_TRADE,
                                                                entry_price, stop_loss_price)
                        if position_size > 0:
                            order_result = await place_order(SYMBOL, "Sell", "Limit", position_size,
                                                             price=entry_price,
                                                             stop_loss=stop_loss_price,
                                                             take_profit=take_profit_price)
                            if order_result:
                                in_position = True
                                current_side = "Sell"
                                open_order_id = order_result.get('orderId')
                                order_placed_time = datetime.datetime.now()

                                logger.info(
                                    f"Placed Sell Limit Order at {entry_price}  Order ID: {open_order_id}")
                            break

            # Order cancellation logic (only if an order is open)
            if open_order_id and order_placed_time:
                time_since_order = datetime.datetime.now() - order_placed_time
                if time_since_order.total_seconds() > ORDER_CANCEL_DELAY:
                    logger.info(f"Cancelling order {open_order_id} due to timeout.")
                    cancel_order(open_order_id, SYMBOL)
                    open_order_id = None  # Reset order ID after cancellation
                    order_placed_time = None  # Reset order placement time
                    in_position = False  # Reset position status
                    current_side = None  # Reset current side

        except Exception as e:
            logger.error(f"Main loop error: {e}", exc_info=True)

        await async_sleep(60)


if __name__ == "__main__":
    asyncio.run(run_strategy())
