import re


def analyze_output_text(output_text):
    """
    Analyzes the output text from a trading bot, extracts indicators,
    and generates trading signals with confidence levels, take profit,
    and stop loss levels.

    Args:
        output_text (str): The output text from the trading bot.

    Returns:
        dict: A dictionary containing the trading signal, confidence level,
              take profit, stop loss, and reasoning.
    """

    lines = output_text.split("\n")
    indicators = {}
    trend = ""
    strength = 0.0
    support_levels = []
    resistance_levels = []
    current_price = 0.0
    atr = 0.0

    for line in lines:
        line = line.strip()  # Remove leading/trailing whitespace
        if line.startswith("Trend:"):
            parts = line.split(":")
            trend = parts[1].strip().split(" ")[0]
            match = re.search(r"Strength: ([\d.]+)", parts[1])
            strength = (
                float(match.group(1)) if match else 0.0
            )  # Extract strength using regex

        elif line.startswith("RSI:"):
            indicators["rsi"] = line.split(":")[1].strip()
        elif line.startswith("MFI:"):
            indicators["mfi"] = line.split(":")[1].strip()
        elif line.startswith("CCI:"):
            indicators["cci"] = line.split(":")[1].strip()
        elif line.startswith("Williams %R:"):
            indicators["wr"] = line.split(":")[1].strip()
        elif line.startswith("ADX:"):
            indicators["adx"] = line.split(":")[1].strip()
        elif line.startswith("OBV:"):
            indicators["obv"] = line.split(":")[1].strip()
        elif line.startswith("ADI:"):
            indicators["adi"] = line.split(":")[1].strip()
        elif line.startswith("Momentum:"):
            indicators["momentum"] = line.split(":")[1].strip()
        elif line.startswith("PSAR:"):
            indicators["psar"] = line.split(":")[1].strip()
        elif line.startswith("Current Price:"):
            try:
                current_price = float(line.split(":")[1].strip())
            except ValueError:
                print(f"Warning: Could not parse current price from line: {line}")
                current_price = 0.0
        elif line.startswith("ATR:"):
            try:
                atr = float(line.split(":")[1].strip())
            except ValueError:
                print(f"Warning: Could not parse ATR from line: {line}")
                atr = 0.0
        elif line.startswith("S:"):
            try:
                label = line.split("$")[0].split(":")[1].strip()
                price = float(line.split("$")[1].strip())
                support_levels.append({"label": label, "price": price})
            except (IndexError, ValueError):
                print(f"Warning: Could not parse support level from line: {line}")
        elif line.startswith("R:"):
            try:
                label = line.split("$")[0].split(":")[1].strip()
                price = float(line.split("$")[1].strip())
                resistance_levels.append({"label": label, "price": price})
            except (IndexError, ValueError):
                print(f"Warning: Could not parse resistance level from line: {line}")

    signal = "Neutral"
    confidence = 0.0
    tp = None
    sl = None
    signal_reasoning = []

    if trend == "Uptrend" and indicators.get("adx", "").find("Trending") != -1:
        if (
            any(indicator in indicators.get("rsi", "") for indicator in ["Oversold"])
            or any(indicator in indicators.get("mfi", "") for indicator in ["Oversold"])
            or any(indicator in indicators.get("cci", "") for indicator in ["Oversold"])
            or any(indicator in indicators.get("wr", "") for indicator in ["Oversold"])
            or any(indicator in indicators.get("obv", "") for indicator in ["Bullish"])
            or any(
                indicator in indicators.get("adi", "") for indicator in ["Accumulation"]
            )
        ):

            signal = "Long"
            confidence += 2
            signal_reasoning.append("Uptrend confirmed by ADX.")
            if any(
                indicator in indicators.get("rsi", "") for indicator in ["Oversold"]
            ):
                confidence += 1
                signal_reasoning.append("RSI Oversold.")
            if any(
                indicator in indicators.get("mfi", "") for indicator in ["Oversold"]
            ):
                confidence += 1
                signal_reasoning.append("MFI Oversold.")
            if any(
                indicator in indicators.get("cci", "") for indicator in ["Oversold"]
            ):
                confidence += 1
                signal_reasoning.append("CCI Oversold.")
            if any(indicator in indicators.get("wr", "") for indicator in ["Oversold"]):
                confidence += 1
                signal_reasoning.append("Williams %R Oversold.")
            if any(indicator in indicators.get("obv", "") for indicator in ["Bullish"]):
                confidence += 1
                signal_reasoning.append("OBV Bullish.")
            if any(
                indicator in indicators.get("adi", "") for indicator in ["Accumulation"]
            ):
                confidence += 1
                signal_reasoning.append("ADI Accumulation.")

            nearest_resistance = next(
                (curr for curr in resistance_levels if curr["price"] > current_price),
                {"price": float("inf")},
            )
            if nearest_resistance["price"] != float("inf"):
                tp = f"{nearest_resistance['price']:.2f}"
            elif resistance_levels:
                tp = f"{resistance_levels[0]['price']:.2f}"
            else:
                tp = f"{current_price + 2 * atr:.2f}"  # Fallback TP based on ATR

            nearest_support = next(
                (curr for curr in support_levels if curr["price"] < current_price),
                {"price": float("-inf")},
            )
            if nearest_support["price"] != float("-inf"):
                sl = f"{nearest_support['price']:.2f}"
            elif support_levels:
                sl = f"{support_levels[-1]['price']:.2f}"
            else:
                sl = f"{current_price - 1.5 * atr:.2f}"  # Fallback SL based on ATR

    elif trend == "Downtrend" and indicators.get("adx", "").find("Trending") != -1:
        if (
            any(indicator in indicators.get("rsi", "") for indicator in ["Overbought"])
            or any(
                indicator in indicators.get("mfi", "") for indicator in ["Overbought"]
            )
            or any(
                indicator in indicators.get("cci", "") for indicator in ["Overbought"]
            )
            or any(
                indicator in indicators.get("wr", "") for indicator in ["Overbought"]
            )
            or any(indicator in indicators.get("obv", "") for indicator in ["Bearish"])
            or any(
                indicator in indicators.get("adi", "") for indicator in ["Distribution"]
            )
        ):

            signal = "Short"
            confidence += 2
            signal_reasoning.append("Downtrend confirmed by ADX.")
            if any(
                indicator in indicators.get("rsi", "") for indicator in ["Overbought"]
            ):
                confidence += 1
                signal_reasoning.append("RSI Overbought.")
            if any(
                indicator in indicators.get("mfi", "") for indicator in ["Overbought"]
            ):
                confidence += 1
                signal_reasoning.append("MFI Overbought.")
            if any(
                indicator in indicators.get("cci", "") for indicator in ["Overbought"]
            ):
                confidence += 1
                signal_reasoning.append("CCI Overbought.")
            if any(
                indicator in indicators.get("wr", "") for indicator in ["Overbought"]
            ):
                confidence += 1
                signal_reasoning.append("Williams %R Overbought.")
            if any(indicator in indicators.get("obv", "") for indicator in ["Bearish"]):
                confidence += 1
                signal_reasoning.append("OBV Bearish.")
            if any(
                indicator in indicators.get("adi", "") for indicator in ["Distribution"]
            ):
                confidence += 1
                signal_reasoning.append("ADI Distribution.")

            nearest_support = next(
                (curr for curr in support_levels if curr["price"] < current_price),
                {"price": float("-inf")},
            )
            if nearest_support["price"] != float("-inf"):
                tp = f"{nearest_support['price']:.2f}"
            elif support_levels:
                tp = f"{support_levels[-1]['price']:.2f}"
            else:
                tp = f"{current_price - 2 * atr:.2f}"  # Fallback TP based on ATR

            nearest_resistance = next(
                (curr for curr in resistance_levels if curr["price"] > current_price),
                {"price": float("inf")},
            )
            if nearest_resistance["price"] != float("inf"):
                sl = f"{nearest_resistance['price']:.2f}"
            elif resistance_levels:
                sl = f"{resistance_levels[0]['price']:.2f}"
            else:
                sl = f"{current_price + 1.5 * atr:.2f}"  # Fallback SL based on ATR

    confidence = min(
        10, confidence * 1.0
    )  # Adjust confidence scaling if needed, max 10

    return {
        "signal": signal,
        "confidence": f"{confidence:.1f}",
        "tp": tp,
        "sl": sl,
        "reasoning": ", ".join(signal_reasoning)
        or "Neutral market conditions or conflicting indicators.",
    }


if __name__ == "__main__":
    # This is an example of how to use the function
    example_output = """
Trend: Uptrend Strength: 0.65
RSI: 68.22
MFI: 55.12
CCI: 110.50
Williams %R: -25.78
ADX: 35.20 Trending
OBV: 123456789
ADI: 987654321
Momentum: 5.20
PSAR: 45000.00
Current Price: 46000.00
ATR: 250.00
S: Level1 $45500.00
S: Level2 $45000.00
R: Level1 $46500.00
R: Level2 $47000.00
"""

    analysis_result = analyze_output_text(example_output)
    print("Example Analysis:")
    print(f"  Signal: {analysis_result['signal']}")
    print(f"  Confidence: {analysis_result['confidence']}")
    print(f"  Take Profit: {analysis_result['tp']}")
    print(f"  Stop Loss: {analysis_result['sl']}")
    print(f"  Reasoning: {analysis_result['reasoning']}")
