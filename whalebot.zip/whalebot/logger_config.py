import os
import logging
import sys
import time  # Import the time module

class RealtimeFileHandler(logging.Handler):
    """
    A handler class which writes logging records,
    appropriately formatted,
    to a file in realtime.  It inherits from
    logging.Handler and ensures
    that every log message is immediately written to the file.
    """
    def __init__(self, filename, mode='a', encoding=None):
        """
        Open the specified file and use it as the
        stream for logging.
        :param filename: The filename to write
        logs to.
        :param mode: The file opening mode ('a'
        for append, 'w' for write).
        :param encoding: The encoding to use when
        writing to the file.
        """
        logging.Handler.__init__(self)
        self.filename = filename
        self.mode = mode
        self.encoding = encoding
        self.stream = None
        self.open_file()  # Open the file immediately

    def open_file(self):
        """Opens the file for writing, creating
        the directory if needed."""
        dirname = os.path.dirname(self.filename)
        if dirname and not os.path.exists(dirname):
            os.makedirs(dirname, exist_ok=True)  # Create directories if they don't exist
        try:
            if self.encoding:
                self.stream = open(self.filename,
                self.mode, encoding=self.encoding)
            else:
                self.stream = open(self.filename, self.mode)
        except OSError:
            if sys.stderr:
                print(f"Unable to open file: {self.filename}", file=sys.stderr)  # Print to stderr if possible.
            self.stream = None

    def emit(self, record):
        """
        Emit a record.
        If a formatter is specified, it is used to
        format the record.
        The record is then written to the stream
        with a trailing newline.
        If exception information is present, it is
        formatted using
        traceback.print_exception and appended to
        the stream.
        If the stream has a 'flush' method, it is
        called.
        :param record: The log record to emit.
        """
        try:
            if self.stream is None:
                self.open_file()  # Re-open file
                # if it was closed or failed to open initially.
            if self.stream is None:
                return  # Can't open file, giving up
            msg = self.format(record)
            self.stream.write(msg)
            self.stream.write(self.terminator)
            self.stream.flush()  # Ensure immediate writing
        except Exception:
            self.handleError(record)

    def close(self):
        """
        Close the stream.
        """
        self.acquire()
        try:
            if self.stream:
                try:
                    self.stream.flush()
                    self.stream.close()
                except OSError:
                    pass  # Ignore errors closing the stream.
                self.stream = None
            logging.Handler.close(self)
        finally:
            self.release()

    @property
    def terminator(self):
        """Line terminator defaults to
        os.linesep"""
        return os.linesep

def setup_custom_logger(name):
    """Sets up a custom logger with file and
    console handlers."""
    log_dir = 'bot_datax'
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    log_file_path = os.path.join(log_dir, f'{name}.txt')  # Changed extension to .txt
    plain_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s') # Plain formatter

    # File handler - Use plain formatter for file output (no colors)
    file_handler = RealtimeFileHandler(log_file_path)
    file_handler.setFormatter(plain_formatter) # Apply plain formatter to file handler

    stream_handler = logging.StreamHandler()  # Keep stream handler for console output
    # You can choose to keep colors in console output or make it plain as well.
    # If you want plain console output too, use plain_formatter here as well:
    # stream_handler.setFormatter(plain_formatter)
    # For now, let's assume you want to keep colors in console, so we use the colored formatter (if you have one) or default.
    stream_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')) # Or your colored formatter if you are still using colorama in whalebv1.py

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)  # Set default level to DEBUG
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    return logger
