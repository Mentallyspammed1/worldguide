import os
import time
import datetime
import logging
import sys
from dotenv import load_dotenv
from pybit.unified_trading import HTTP
from colorama import Fore, Style, init
import pandas as pd
import numpy as np
import asyncio
import signal

init(autoreset=True)

class Neon:
    GREEN = Fore.GREEN + Style.BRIGHT
    CYAN = Fore.CYAN + Style.BRIGHT
    MAGENTA = Fore.MAGENTA + Style.BRIGHT
    YELLOW = Fore.YELLOW + Style.BRIGHT
    RED = Fore.RED + Style.BRIGHT
    BLUE = Fore.BLUE + Style.BRIGHT
    WHITE = Fore.WHITE + Style.BRIGHT
    RESET = Style.RESET_ALL

load_dotenv()
API_KEY = os.getenv("BYBIT_API_KEY")
API_SECRET = os.getenv("BYBIT_API_SECRET")
TESTNET = os.getenv("TESTNET", "false").lower() == "true"

# Input validation and handling
while True:
    SYMBOL = input(f"{Neon.CYAN}Enter the trading symbol (e.g., BTCUSDT): {Neon.RESET}").upper().strip()
    if SYMBOL:
        break
    else:
        print(f"{Neon.RED}Symbol cannot be empty.{Neon.RESET}")

while True:
    try:
        TIMEFRAME = int(input(f"{Neon.CYAN}Enter the timeframe in minutes (e.g., 1, 5, 15): {Neon.RESET}"))
        if TIMEFRAME > 0:
            break
        else:
            print(f"{Neon.RED}Timeframe must be positive.{Neon.RESET}")
    except ValueError:
        print(f"{Neon.RED}Invalid input. Please enter a number.{Neon.RESET}")


# Parameter loading with error handling and defaults
try:
    RISK_PER_TRADE = float(os.getenv("RISK_PER_TRADE", 0.01))
    LOOKBACK_PERIOD = int(os.getenv("LOOKBACK_PERIOD", 100))
    ZONE_CONFIRMATION_PERIODS = int(os.getenv("ZONE_CONFIRMATION_PERIODS", 3))  # Adjusted for faster zone detection
    ZONE_PROXIMITY_PERCENT = float(os.getenv("ZONE_PROXIMITY_PERCENT", 0.02)) # Increased for wider zone
    REWARD_RISK_RATIO = float(os.getenv("REWARD_RISK_RATIO", 1.5))  # Increased R:R
    ORDER_CANCEL_DELAY = int(os.getenv("ORDER_CANCEL_DELAY", 60))  # Increased delay
    STOCH_RSI_K = int(os.getenv("STOCH_RSI_K", 3))
    STOCH_RSI_D = int(os.getenv("STOCH_RSI_D", 3))
    STOCH_RSI_PERIOD = int(os.getenv("STOCH_RSI_PERIOD", 14))
    VOLUME_THRESHOLD = float(os.getenv("VOLUME_THRESHOLD", 1.2))  # Lowered threshold
    MIN_ZONE_WIDTH_PERCENT = float(os.getenv("MIN_ZONE_WIDTH_PERCENT", 0.002))  # Lowered for smaller zones
    ACCOUNT_TYPE = os.getenv("ACCOUNT_TYPE", "UNIFIED")  # Added account type
    COIN = os.getenv("COIN", "USDT") # Added Coin type

except (TypeError, ValueError) as e:
    print(f"{Neon.RED}Error reading environment variables: {e}.  Please ensure they are set correctly.{Neon.RESET}")
    sys.exit(1)

LOG_DIR = "logs"
MAX_RETRIES = 3
RETRY_DELAY = 5
MIN_ORDER_QTY = 0.0001  # Example minimum order quantity (adjust for your symbol)


def setup_logger(symbol, log_dir):
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_filename = os.path.join(log_dir, f"{symbol}_{timestamp}.log")
    logger = logging.getLogger(symbol)
    logger.setLevel(logging.DEBUG)

    # File Handler
    file_handler = logging.FileHandler(log_filename)
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    # Console Handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)  # Set console to INFO level

    class ColorFormatter(logging.Formatter):
        COLORS = {
            logging.DEBUG: Neon.CYAN,
            logging.INFO: Neon.GREEN,
            logging.WARNING: Neon.YELLOW,
            logging.ERROR: Neon.RED,
            logging.CRITICAL: Neon.RED + Style.BRIGHT,
        }

        def format(self, record):
            log_message = super().format(record)
            color = self.COLORS.get(record.levelno, Neon.WHITE)
            return f"{color}{log_message}{Neon.RESET}"

    console_formatter = ColorFormatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    return logger

logger = setup_logger(SYMBOL, LOG_DIR)


async def create_session():
    """Creates and returns an asynchronous Bybit session."""
    try:
        return HTTP(testnet=TESTNET, api_key=API_KEY, api_secret=API_SECRET)
    except Exception as e:
        logger.critical(f"Failed to create Bybit session: {e}", exc_info=True)
        sys.exit(1)

session = None  # Initialize session outside the loop

async def initialize_session():
    """Initializes the global session object."""
    global session
    if session is None:
        session = await create_session()

async def fetch_klines(symbol, timeframe, limit):
    """Fetches klines with retries and improved error handling."""
    await initialize_session() # Ensure session is initialized
    for attempt in range(MAX_RETRIES):
        try:
            # Calculate 'start' based on the current time and the desired historical data
            now = int(time.time() * 1000)
            start_time = now - (timeframe * 60 * 1000 * limit)
            result = await asyncio.to_thread(
                session.get_kline,
                category="linear",
                symbol=symbol,
                interval=str(timeframe),
                start=start_time,
                limit=limit
            )
            if result['retCode'] == 0:
                return result['result']['list']
            else:
                logger.error(f"Attempt {attempt + 1}/{MAX_RETRIES}: Error fetching klines: {result['retMsg']}")
        except Exception as e:
            logger.error(f"Attempt {attempt + 1}/{MAX_RETRIES}: Error fetching klines: {e}", exc_info=True)
        await asyncio.sleep(RETRY_DELAY)
    logger.error(f"Failed to fetch klines after {MAX_RETRIES} retries.")
    return None


async def get_historical_data(symbol, timeframe, periods):
    """Fetches historical data and returns a Pandas DataFrame."""
    klines = await fetch_klines(symbol, timeframe, periods)
    if klines is None:
        return pd.DataFrame()

    try:
        df = pd.DataFrame(klines, columns=['startTime', 'open', 'high', 'low', 'close', 'volume', 'turnover'])
        # Convert to numeric and handle potential errors
        for col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        df.dropna(inplace=True)  # Drop rows with NaN values
        df['startTime'] = pd.to_datetime(df['startTime'], unit='ms')
        df.set_index('startTime', inplace=True)
        df.sort_index(inplace=True)  # Ensure data is sorted by time

        return df
    except (KeyError, ValueError) as e:
        logger.error(f"Error creating DataFrame: {e}")
        return pd.DataFrame()
    except Exception as e:
        logger.error(f"Unexpected error creating DataFrame: {e}", exc_info=True)
        return pd.DataFrame()

async def get_current_price(symbol):
    """Gets the current price using get_tickers."""
    await initialize_session() # Ensure session is initialized
    for attempt in range(MAX_RETRIES):
        try:
            result = await asyncio.to_thread(session.get_tickers, category="linear", symbol=symbol)
            if result and result['retCode'] == 0:
                return float(result['result']['list'][0]['lastPrice'])
            logger.error(f"Attempt {attempt+1}/{MAX_RETRIES}: Could not get price: {result.get('retMsg', 'Unknown error')}")
        except Exception as e:
            logger.error(f"Attempt {attempt+1}/{MAX_RETRIES}: Error getting price: {e}", exc_info=True)
        await asyncio.sleep(RETRY_DELAY)
    logger.error(f"Failed to get current price after {MAX_RETRIES} retries.")
    return None


def calculate_stoch_rsi(data, period=STOCH_RSI_PERIOD, k_period=STOCH_RSI_K, d_period=STOCH_RSI_D):
    """Calculates Stochastic RSI with error handling."""
    if data.empty:
        return None, None

    try:
        df = data.copy()
        close = df['close'].astype(float)
        rsi = calculate_rsi(close, period)

        if rsi is None:  # Handle cases where RSI calculation fails
             return None, None

        df['rsi'] = rsi
        low_rsi = df['rsi'].rolling(window=period, min_periods=0).min()
        high_rsi = df['rsi'].rolling(window=period, min_periods=0).max()

        stoch_rsi = 100 * ((df['rsi'] - low_rsi) / (high_rsi - low_rsi))
        stoch_rsi_k = stoch_rsi.rolling(window=k_period, min_periods=0).mean()
        stoch_rsi_d = stoch_rsi_k.rolling(window=d_period, min_periods=0).mean()

        return stoch_rsi_k.iloc[-1], stoch_rsi_d.iloc[-1]

    except Exception as e:
        logger.error(f"Error calculating Stoch RSI: {e}", exc_info=True)
        return None, None


def calculate_rsi(data, period=14):
    """Calculates RSI."""
    if len(data) < period + 1:  # Need at least period + 1 data points
      return None
    try:
        delta = data.diff()
        gain = (delta.where(delta > 0, 0)).fillna(0)
        loss = (-delta.where(delta < 0, 0)).fillna(0)
        avg_gain = gain.rolling(window=period, min_periods=1).mean()
        avg_loss = loss.rolling(window=period, min_periods=1).mean()
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    except Exception as e:
      logger.error(f"Error in calculating RSI {e}", exc_info = True)
      return None

def calculate_average_volume(data, volume_period=20):
    """Calculates average volume."""
    if data.empty or len(data) < volume_period:
        return 0
    return data['volume'].tail(volume_period).mean()


def identify_supply_demand_zones(df, confirmation_periods):
    """Identifies supply and demand zones."""
    if len(df) < confirmation_periods + 1:
        return [], []

    supply_zones = []
    demand_zones = []
    for i in range(1, len(df) - confirmation_periods):  # Corrected loop range
        high = df['high'].iloc[i]
        low = df['low'].iloc[i]
        close = df['close'].iloc[i]
        open_price = df['open'].iloc[i]

        # Demand Zone:  Strong bullish candle followed by higher highs
        if (close > open_price and
            all(df['high'].iloc[i + j] > high for j in range(1, confirmation_periods + 1))):
            demand_zones.append((low, high))

        # Supply Zone: Strong bearish candle followed by lower lows
        if (close < open_price and
             all(df['low'].iloc[i + j] < low for j in range(1, confirmation_periods + 1))):
            supply_zones.append((low, high))

    return supply_zones, demand_zones

async def get_wallet_balance(account_type=ACCOUNT_TYPE, coin=COIN):
    """Gets wallet balance with retries."""
    await initialize_session() # Ensure session is initialized
    for attempt in range(MAX_RETRIES):
        try:
            result = await asyncio.to_thread(session.get_wallet_balance, accountType=account_type, coin=coin)
            if result['retCode'] == 0:
                balance_data = result['result']['list'][0]['coin']
                for c in balance_data:
                    if c['coin'] == coin:
                        return float(c['availableToWithdraw'])
                return 0.0  # Return 0 if the coin isn't found
            logger.warning(f"Attempt {attempt+1}/{MAX_RETRIES}: Failed to get balance: {result['retMsg']}. Retrying...")
        except Exception as e:
            logger.error(f"Attempt {attempt+1}/{MAX_RETRIES}: Error getting balance: {e}. Retrying...")
        await asyncio.sleep(RETRY_DELAY)
    logger.error(f"Failed to get balance after {MAX_RETRIES} retries.")
    return None


async def place_order(symbol, side, order_type, qty, price=None, time_in_force="GoodTillCancel",
                reduce_only=False, close_on_trigger=False, stop_loss=None, take_profit=None):
    """Places an order with comprehensive error handling."""
    await initialize_session()
    qty = round(qty, 4)  # Round quantity
    if qty < MIN_ORDER_QTY:
        logger.warning(f"Order quantity {qty} is below minimum {MIN_ORDER_QTY}.  Cannot place order.")
        return None

    for attempt in range(MAX_RETRIES):
        try:
            order_params = {
                "category": "linear",
                "symbol": symbol,
                "side": side,
                "orderType": order_type,
                "qty": str(qty),
                "timeInForce": time_in_force,
                "reduceOnly": reduce_only,
                "closeOnTrigger": close_on_trigger
            }
            if price is not None:
                order_params['price'] = str(round(price, 5))  # Round price and handle None
            if stop_loss is not None:
                order_params['stopLoss'] = str(round(stop_loss, 5))
            if take_profit is not None:
                order_params['takeProfit'] = str(round(take_profit, 5))


            result = await asyncio.to_thread(session.place_order, **order_params)

            if result['retCode'] == 0:
                logger.info(f"Order placed successfully: {result['result']}")
                return result['result']
            else:
                logger.warning(f"Attempt {attempt+1}/{MAX_RETRIES}: Failed to place order: {result['retMsg']}. Retrying...")

        except Exception as e:
            logger.error(f"Attempt {attempt+1}/{MAX_RETRIES}: Error placing order: {e}. Retrying...")
        await asyncio.sleep(RETRY_DELAY)
    logger.error(f"Failed to place order after {MAX_RETRIES} retries.")
    return None


async def cancel_order(order_id, symbol):
    """Cancels an order with retries."""
    await initialize_session()
    for attempt in range(MAX_RETRIES):
        try:
            result = await asyncio.to_thread(session.cancel_order, category="linear", symbol=symbol, orderId=order_id)
            if result['retCode'] == 0:
                logger.info(f"Order {order_id} cancelled successfully.")
                return True
            else:
                logger.warning(f"Attempt {attempt+1}/{MAX_RETRIES}: Failed to cancel order {order_id}: {result['retMsg']}. Retrying...")
        except Exception as e:
            logger.error(f"Attempt {attempt+1}/{MAX_RETRIES}: Error cancelling order {order_id}: {e}. Retrying...")
        await asyncio.sleep(RETRY_DELAY)
    logger.error(f"Failed to cancel order after {MAX_RETRIES} retries.")
    return False

async def get_open_orders(symbol):
    """Retrieves open orders for the given symbol."""
    await initialize_session()  # Ensure session is initialized
    for attempt in range(MAX_RETRIES):
        try:
            result = await asyncio.to_thread(session.get_open_orders, category="linear", symbol=symbol)
            if result['retCode'] == 0:
                return result['result']['list']
            else:
                logger.warning(f"Attempt {attempt + 1}/{MAX_RETRIES}: Failed to get open orders: {result['retMsg']}. Retrying...")
        except Exception as e:
            logger.error(f"Attempt {attempt + 1}/{MAX_RETRIES}: Error getting open orders: {e}. Retrying...")
        await asyncio.sleep(RETRY_DELAY)
    logger.error(f"Failed to get open orders after {MAX_RETRIES} retries.")
    return []

def calculate_position_size(account_balance, risk_per_trade, entry_price, stop_loss_price):
    """Calculates position size, handling edge cases."""
    if account_balance is None or entry_price is None or stop_loss_price is None:
        return 0  # Cannot calculate without these values

    if abs(entry_price - stop_loss_price) < 1e-8:  # Avoid division by zero
        logger.warning("Entry price and stop loss price are too close.")
        return 0

    risk_amount = account_balance * risk_per_trade
    price_difference = abs(entry_price - stop_loss_price)
    quantity = risk_amount / price_difference
    return quantity


def is_price_near_zone(price, zone, proximity_percent):
    """Checks if the price is near a zone."""
    lower_bound = zone[0] * (1 - proximity_percent)
    upper_bound = zone[1] * (1 + proximity_percent)
    return lower_bound <= price <= upper_bound

def color_code_zone(zone):
	return f"{Neon.GREEN}[{zone[0]:.5f}, {zone[1]:.5f}]{Neon.RESET}"

async def run_strategy():
    """Main strategy logic."""
    logger.info(f"Starting Supply/Demand Scalping strategy for {SYMBOL} on timeframe {TIMEFRAME}")
    in_position = False
    current_side = None
    open_order_id = None
    order_placed_time = None

    # Graceful Shutdown
    def signal_handler(sig, frame):
        logger.info("Shutting down gracefully...")
        if open_order_id:
            asyncio.create_task(cancel_order(open_order_id, SYMBOL))  # Cancel order asynchronously
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    while True:
        try:
            klines = await get_historical_data(SYMBOL, TIMEFRAME, LOOKBACK_PERIOD)
            if klines.empty:
                logger.warning("No kline data. Waiting...")
                await asyncio.sleep(60)
                continue

            current_price = await get_current_price(SYMBOL)
            if current_price is None:
                logger.warning("Could not get current price. Waiting...")
                await asyncio.sleep(60)
                continue

            stoch_rsi_k, stoch_rsi_d = calculate_stoch_rsi(klines)
            if stoch_rsi_k is None or stoch_rsi_d is None:
                logger.info("Could not calculate Stoch RSI. Waiting...")
                await asyncio.sleep(60)
                continue

            average_volume = calculate_average_volume(klines)
            current_volume = float(klines['volume'].iloc[-1])  # Current volume

            supply_zones, demand_zones = identify_supply_demand_zones(klines, ZONE_CONFIRMATION_PERIODS)

            # Filter and keep only the nearest zones (up to 6)
            supply_zones = [(low, high) for low, high in supply_zones if high - low > MIN_ZONE_WIDTH_PERCENT * current_price]
            demand_zones = [(low, high) for low, high in demand_zones if high - low > MIN_ZONE_WIDTH_PERCENT * current_price]

            #Sort zones by proximity
            supply_zones = sorted(supply_zones, key=lambda zone: abs(current_price - (zone[0]+zone[1])/2))[:6]
            demand_zones = sorted(demand_zones, key=lambda zone: abs(current_price - (zone[0]+zone[1])/2))[:6]

            logger.debug(f"Nearest Supply Zones: {[color_code_zone(zone) for zone in supply_zones]}")
            logger.debug(f"Nearest Demand Zones: {[color_code_zone(zone) for zone in demand_zones]}")
            logger.debug(f"Stoch RSI K: {stoch_rsi_k:.2f}, Stoch RSI D: {stoch_rsi_d:.2f}")
            logger.debug(f"Average Volume: {average_volume:.2f}, Current Volume: {current_volume:.2f}, Threshold: {average_volume * VOLUME_THRESHOLD:.2f}")

            # Check for existing open orders and cancel if necessary.
            open_orders = await get_open_orders(SYMBOL)
            if open_orders:
                 for order in open_orders:
                    if order['orderId'] == open_order_id: # Check if it is your order.
                        if order_placed_time is not None:
                            time_since_order = datetime.datetime.utcnow() - order_placed_time.replace(tzinfo=datetime.timezone.utc)  # Ensure timezone awareness
                            if time_since_order.total_seconds() > ORDER_CANCEL_DELAY:
                                logger.info(f"Cancelling order {open_order_id} due to timeout.")
                                await cancel_order(open_order_id, SYMBOL)
                                open_order_id = None
                                order_placed_time = None
                                in_position = False  # Reset in_position after cancellation
                                current_side = None

            if not in_position:
                 # Demand Zone Entry
                for zone in demand_zones:
                    if (is_price_near_zone(current_price, zone, ZONE_PROXIMITY_PERCENT) and
                        stoch_rsi_k < stoch_rsi_d and stoch_rsi_k < 20 and # Added oversold condition
                        current_volume > average_volume * VOLUME_THRESHOLD):

                        account_balance = await get_wallet_balance()
                        if account_balance is None:
                            logger.error("Could not retrieve account balance.")
                            break  # Exit zone loop

                        entry_price = zone[1]
                        stop_loss_price = zone[0]
                        take_profit_price = entry_price + (entry_price - stop_loss_price) * REWARD_RISK_RATIO
                        position_size = calculate_position_size(account_balance, RISK_PER_TRADE, entry_price, stop_loss_price)

                        if position_size >= MIN_ORDER_QTY:
                            order_result = await place_order(
                                SYMBOL, "Buy", "Limit", position_size, price=entry_price,
                                stop_loss=stop_loss_price, take_profit=take_profit_price
                            )
                            if order_result:
                                open_order_id = order_result.get('orderId')
                                order_placed_time = datetime.datetime.now(datetime.timezone.utc)  # Store time with timezone
                                in_position = True
                                current_side = "Buy"
                                logger.info(f"Placed Buy Limit Order at {entry_price}. Order ID: {open_order_id}")
                            break  # Exit zone loop after placing order

                # Supply Zone Entry
                for zone in supply_zones:
                    if (is_price_near_zone(current_price, zone, ZONE_PROXIMITY_PERCENT) and
                        stoch_rsi_k > stoch_rsi_d and stoch_rsi_k > 80 and # Added overbought condition
                        current_volume > average_volume * VOLUME_THRESHOLD):

                        account_balance = await get_wallet_balance()
                        if account_balance is None:
                            logger.error("Could not retrieve account balance.")
                            break

                        entry_price = zone[0]
                        stop_loss_price = zone[1]
                        take_profit_price = entry_price - (stop_loss_price - entry_price) * REWARD_RISK_RATIO
                        position_size = calculate_position_size(account_balance, RISK_PER_TRADE, entry_price, stop_loss_price)

                        if position_size >= MIN_ORDER_QTY:
                            order_result = await place_order(
                                SYMBOL, "Sell", "Limit", position_size, price=entry_price,
                                stop_loss=stop_loss_price, take_profit=take_profit_price
                            )
                            if order_result:
                                open_order_id = order_result.get('orderId')
                                order_placed_time = datetime.datetime.now(datetime.timezone.utc)
                                in_position = True
                                current_side = "Sell"
                                logger.info(f"Placed Sell Limit Order at {entry_price}.  Order ID: {open_order_id}")
                            break
        except Exception as e:
            logger.error(f"Unexpected error in main loop: {e}", exc_info=True)

        await asyncio.sleep(60)


if __name__ == "__main__":
    asyncio.run(run_strategy())
