function createNetworkSpeedTest() {
  let downloadSize = 2000000;
  let uploadSize = 1000000;
  let downloadUrl = 'https://www.speedtest.net/speedtest-config.php'; // Example, replace with a suitable test file URL
  let uploadUrl = '/upload'; // Replace with your upload endpoint if needed, or simulate upload

  async function measureDownloadSpeed() {
    let startTime = new Date().getTime();
    try {
      const response = await fetch(downloadUrl + '?r=' + Math.random()); // Cache busting
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      await response.blob(); // Download the body to measure time
      let endTime = new Date().getTime();
      let duration = (endTime - startTime) / 1000;
      let bitsLoaded = downloadSize * 8;
      let speedMbps = (bitsLoaded / duration) / (1024 * 1024);
      return speedMbps.toFixed(2);
    } catch (error) {
      console.error("Download speed test error:", error);
      return 'Error';
    }
  }

  async function measureUploadSpeed() {
    let startTime = new Date().getTime();
    try {
      const blob = new Blob([new ArrayBuffer(uploadSize)]);
      const response = await fetch(uploadUrl, {  // Simulate upload to a dummy endpoint
        method: 'POST',
        body: blob
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      let endTime = new Date().getTime();
      let duration = (endTime - startTime) / 1000;
      let bitsSent = uploadSize * 8;
      let speedMbps = (bitsSent / duration) / (1024 * 1024);
      return speedMbps.toFixed(2);
    } catch (error) {
      console.error("Upload speed test error:", error);
      return 'Error';
    }
  }

  async function runSpeedTest() {
    let downloadSpeed = 'Testing...';
    let uploadSpeed = 'Testing...';
    updateDisplay(downloadSpeed, uploadSpeed);

    downloadSpeed = await measureDownloadSpeed();
    updateDisplay(downloadSpeed, uploadSpeed, 'download');

    uploadSpeed = await measureUploadSpeed();
    updateDisplay(downloadSpeed, uploadSpeed, 'upload');
  }

  function updateDisplay(downloadSpeed, uploadSpeed, type = 'both') {
    const downloadSpeedElement = document.getElementById('download-speed');
    const uploadSpeedElement = document.getElementById('upload-speed');

    if (downloadSpeedElement && (type === 'both' || type === 'download')) {
      downloadSpeedElement.textContent = downloadSpeed + (downloadSpeed !== 'Error' && downloadSpeed !== 'Testing...' ? ' Mbps' : '');
    }
    if (uploadSpeedElement && (type === 'both' || type === 'upload')) {
      uploadSpeedElement.textContent = uploadSpeed + (uploadSpeed !== 'Error' && uploadSpeed !== 'Testing...' ? ' Mbps' : '');
    }
  }

  function createUI() {
    const container = document.createElement('div');
    container.innerHTML = `
      <div>
        <button id="start-test">Start Speed Test</button>
      </div>
      <div>
        Download Speed: <span id="download-speed"></span>
      </div>
      <div>
        Upload Speed: <span id="upload-speed"></span>
      </div>
    `;
    document.body.appendChild(container);
    document.getElementById('start-test').addEventListener('click', runSpeedTest);
  }

  createUI();
}

createNetworkSpeedTest();
