import os
import logging
import requests
import pandas as pd
import numpy as np
from datetime import datetime
import hmac
import hashlib
import time
from dotenv import load_dotenv
from typing import Dict, Tuple, List, Union
from colorama import init, Fore, Style
from zoneinfo import ZoneInfo
from logger_config import setup_custom_logger  # Assuming you have this
from decimal import Decimal, getcontext
import json

getcontext().prec = 10
logger = setup_custom_logger('whalebot')
init(autoreset=True)

load_dotenv()

API_KEY = os.getenv("BYBIT_API_KEY")
API_SECRET = os.getenv("BYBIT_API_SECRET")
if not API_KEY or not API_SECRET:
    raise ValueError("BYBIT_API_KEY and BYBIT_API_SECRET must be set in .env")
BASE_URL = os.getenv("BYBIT_BASE_URL", "https://api.bybit.com")

CONFIG_FILE = "config.json"
LOG_DIRECTORY = "bot_logs"
TIMEZONE = ZoneInfo("America/Chicago")
MAX_API_RETRIES = 3
RETRY_DELAY_SECONDS = 5
VALID_INTERVALS = ["1", "3", "5", "15", "30", "60", "120", "240", "D", "W", "M"]
RETRY_ERROR_CODES = [429, 500, 502, 503, 504]

NEON_GREEN = Fore.LIGHTGREEN_EX
NEON_BLUE = Fore.CYAN
NEON_PURPLE = Fore.MAGENTA
NEON_YELLOW = Fore.YELLOW
NEON_RED = Fore.LIGHTRED_EX
RESET = Style.RESET_ALL

os.makedirs(LOG_DIRECTORY, exist_ok=True)

def load_config(filepath: str) -> dict:
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            config = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        print(f"{NEON_YELLOW}Could not load or parse config. Loading defaults.{RESET}")
        config = {
            "interval": "15",
            "analysis_interval": 30,
            "retry_delay": 5,
            "momentum_period": 10,
            "momentum_ma_short": 12,
            "momentum_ma_long": 26,
            "volume_ma_period": 20,
            "atr_period": 14,
            "trend_strength_threshold": 0.4,
            "sideways_atr_multiplier": 1.5,
            "indicators": {
                "ema_alignment": True,
                "momentum": True,
                "volume_confirmation": True,
                "divergence": True,
                "stoch_rsi": True,
                "rsi": False,
                "macd": False,
                "vwap": True,
            },
            "weight_sets": {
                "low_volatility": {  # Renamed for clarity
                    "ema_alignment": 0.4,
                    "momentum": 0.3,
                    "volume_confirmation": 0.2,
                    "divergence": 0.1,
                    "stoch_rsi": 0.7,  # High initial weight
                    "rsi": 0.0,
                    "macd": 0.0,
                    "vwap": 0.5,
                },
            },
            # --- Stoch RSI Specific Configuration ---
            "stoch_rsi_oversold_threshold": 20,  # Configurable oversold threshold
            "stoch_rsi_overbought_threshold": 80, # Configurable overbought threshold
            "stoch_rsi_confidence_boost": 5,     # High confidence boost
            "stoch_rsi_mandatory": False,          # Optional: Make Stoch RSI mandatory
            # --- Other Indicator Confidence Boosts ---
            "rsi_confidence_boost" : 2,
            "mfi_confidence_boost" : 2,
            "order_book_support_confidence_boost" : 3,
            "order_book_resistance_confidence_boost" : 3,
              # --- Scalping Specific ---
            "stop_loss_multiple" : 1.5,
            "take_profit_multiple" : 1,
            "order_book_wall_threshold_multiplier" : 2,
            "order_book_depth_to_check" : 10,
            "price_change_threshold" : 0.005,
            "atr_change_threshold" : 0.005,
            "signal_cooldown_s": 60,       # 1 minute cooldown
            "order_book_debounce_s": 1,     # Debounce orderbook
        }
    return config


CONFIG = load_config(CONFIG_FILE)


def setup_logger(symbol: str) -> logging.Logger:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = os.path.join(LOG_DIRECTORY, f"{symbol}_{timestamp}.log")
    logger = logging.getLogger(symbol)
    logger.setLevel(logging.INFO)

    file_handler = logging.FileHandler(log_filename)
    file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    logger.addHandler(file_handler)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(
        logging.Formatter(NEON_BLUE + "%(asctime)s" + RESET + " - %(levelname)s - %(message)s")
    )
    logger.addHandler(stream_handler)
    return logger

def generate_signature(params: dict) -> str:
    param_str = "&".join(f"{key}={value}" for key, value in sorted(params.items()))
    return hmac.new(API_SECRET.encode(), param_str.encode(), hashlib.sha256).hexdigest()

def fetch_current_price(symbol: str, logger: logging.Logger) -> Union[Decimal, None]:
    endpoint = "/v5/market/tickers"
    params = {
        "category": "linear",
        "symbol": symbol
    }
    response = bybit_request("GET", endpoint, params, logger)

    if not response or response.get("retCode") != 0 or not response.get("result"):
        logger.error(f"{NEON_RED}Failed to fetch ticker data: {response}{RESET}")
        return None

    tickers = response["result"].get("list", [])
    for ticker in tickers:
        if ticker.get("symbol") == symbol:
            last_price_str = ticker.get("lastPrice")
            if not last_price_str:
                logger.error(f"{NEON_RED}No lastPrice in ticker data{RESET}")
                return None
            try:
                return Decimal(last_price_str)
            except Exception as e:
                logger.error(f"{NEON_RED}Error parsing last price: {e}{RESET}")
                return None

    logger.error(f"{NEON_RED}Symbol {symbol} not found in ticker data{RESET}")
    return None

def safe_json_response(response: requests.Response, logger: logging.Logger = None) -> Union[dict, None]:
    try:
        return response.json()
    except ValueError:
        if logger:
            logger.error(f"{NEON_RED}Invalid JSON response: {response.text}{RESET}")
        return None

def bybit_request(method: str, endpoint: str, params: dict = None, logger: logging.Logger = None) -> Union[dict, None]:
    for retry in range(MAX_API_RETRIES):
        try:
            params = params or {}
            timestamp = str(int(datetime.now(TIMEZONE).timestamp() * 1000))
            signature_params = params.copy()
            signature_params['timestamp'] = timestamp
            param_str = "&".join(f"{key}={value}" for key, value in sorted(signature_params.items()))
            signature = hmac.new(API_SECRET.encode(), param_str.encode(), hashlib.sha256).hexdigest()

            headers = {
                "X-BAPI-API-KEY": API_KEY,
                "X-BAPI-TIMESTAMP": timestamp,
                "X-BAPI-SIGN": signature,
                "Content-Type": "application/json"
            }
            url = f"{BASE_URL}{endpoint}"

            request_kwargs = {
                'method': method,
                'url': url,
                'headers': headers,
                'timeout': 10
            }

            if method == "GET":
                request_kwargs['params'] = params
            elif method == "POST":
                request_kwargs['json'] = params

            response = requests.request(**request_kwargs)
            if response.status_code == 200:
                json_response = safe_json_response(response, logger)
                if json_response:
                    return json_response
                else:
                    if logger:
                        logger.error(f"{NEON_RED}Empty or invalid JSON response: {response.text}{RESET}")
                    return None
            elif response.status_code in RETRY_ERROR_CODES:
                if logger:
                    logger.warning(
                        f"{NEON_YELLOW}Rate limited or server error. Retrying {retry + 1}/{MAX_API_RETRIES} after {RETRY_DELAY_SECONDS * (2**retry)} seconds...{RESET}"
                    )
                time.sleep(RETRY_DELAY_SECONDS * (2**retry))
            else:
                if logger:
                    logger.error(
                        f"{NEON_RED}Bybit API error: {response.status_code} - {response.text}{RESET}"
                    )
                return None

        except requests.exceptions.RequestException as e:
            if logger:
                logger.error(f"{NEON_RED}API request failed: {e}{RESET}")
            time.sleep(RETRY_DELAY_SECONDS * (2**retry))
    if logger:
        logger.error(f"{NEON_RED}Max retries exceeded for endpoint: {endpoint}{RESET}")
    return None

def fetch_klines(symbol: str, interval: str, limit: int = 200, logger: logging.Logger = None) -> pd.DataFrame:
    try:
        endpoint = "/v5/market/kline"
        params = {"symbol": symbol, "interval": interval, "limit": limit, "category": "linear"}
        response = bybit_request("GET", endpoint, params, logger)
        if (
            response
            and response.get("retCode") == 0
            and response.get("result")
            and response["result"].get("list")
        ):
            data = response["result"]["list"]
            columns = ["start_time", "open", "high", "low", "close", "volume"]
            if data and len(data[0]) > 6 and data[0][6]:
                columns.append("turnover")
            df = pd.DataFrame(data, columns=columns)
            df["start_time"] = pd.to_numeric(df["start_time"])
            df["start_time"] = pd.to_datetime(df["start_time"], unit="ms")

            for col in ["open", "high", "low", "close", "volume", "turnover"]:
                df[col] = pd.to_numeric(df[col], errors="coerce")
            for col in ["open", "high", "low", "close", "volume", "turnover"]:
                if col not in df.columns:
                    df[col] = np.nan
            if not {"close", "high", "low", "volume"}.issubset(df.columns):
                if logger:
                    logger.error(f"{NEON_RED}Kline data missing required columns after processing.{RESET}")
                return pd.DataFrame()
            return df.astype({c: float for c in columns if c != "start_time"})
        if logger:
            logger.error(f"{NEON_RED}Failed to fetch klines: {response}{RESET}")
            return pd.DataFrame()
    except (requests.exceptions.RequestException, KeyError, ValueError, TypeError) as e:
        if logger:
            logger.exception(f"{NEON_RED}Error fetching klines: {e}{RESET}")
        return pd.DataFrame()


class TradingAnalyzer:
    def __init__(self, df: pd.DataFrame, logger: logging.Logger, config: dict, symbol: str, interval: str):
        self.df = df
        self.logger = logger
        self.levels = {}
        self.fib_levels = {}
        self.config = config
        self.signal = None
        self.weight_sets = config["weight_sets"]
        self.user_defined_weights = self.weight_sets["low_volatility"]
        self.symbol = symbol
        self.interval = interval
        self.stoch_rsi_df = self.calculate_stoch_rsi()  # Calculate once and store


    def calculate_sma(self, window: int) -> pd.Series:
        try:
            return self.df["close"].rolling(window=window).mean()
        except KeyError as e:
            self.logger.error(f"{NEON_RED}Missing 'close' column for SMA calculation: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_momentum(self, period: int = 10) -> pd.Series:
        try:
            return ((self.df["close"] - self.df["close"].shift(period)) / self.df["close"].shift(period)) * 100
        except (KeyError, ZeroDivisionError) as e:
            self.logger.error(f"{NEON_RED}Momentum calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_cci(self, window: int = 20, constant: float = 0.015) -> pd.Series:
        try:
            typical_price = (self.df["high"] + self.df["low"] + self.df["close"]) / 3
            sma_typical_price = typical_price.rolling(window=window).mean()
            mean_deviation = typical_price.rolling(window=window).apply(lambda x: np.abs(x - x.mean()).mean(), raw=True)
            cci = (typical_price - sma_typical_price) / (constant * mean_deviation)
            return cci
        except (KeyError, ZeroDivisionError) as e:
            self.logger.error(f"{NEON_RED}CCI calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")
        except Exception as e:
            self.logger.exception(f"{NEON_RED}Unexpected error during CCI calculation: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_williams_r(self, window: int = 14) -> pd.Series:
        try:
            highest_high = self.df["high"].rolling(window=window).max()
            lowest_low = self.df["low"].rolling(window=window).min()
            wr = (highest_high - self.df["close"]) / (highest_high - lowest_low) * -100
            return wr
        except KeyError as e:
            self.logger.error(f"{NEON_RED}Williams %R calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_mfi(self, window: int = 14) -> pd.Series:
        try:
            typical_price = (self.df["high"] + self.df["low"] + self.df["close"]) / 3
            raw_money_flow = typical_price * self.df["volume"]
            positive_flow = []
            negative_flow = []
            for i in range(1, len(typical_price)):
                if typical_price[i] > typical_price[i - 1]:
                    positive_flow.append(raw_money_flow[i - 1])
                    negative_flow.append(0)
                elif typical_price[i] < typical_price[i - 1]:
                    negative_flow.append(raw_money_flow[i - 1])
                    positive_flow.append(0)
                else:
                    positive_flow.append(0)
                    negative_flow.append(0)

            positive_mf = pd.Series(positive_flow).rolling(window=window).sum()
            negative_mf = pd.Series(negative_flow).rolling(window=window).sum()

            money_ratio = positive_mf / negative_mf
            mfi = 100 - (100 / (1 + money_ratio))
            return mfi
        except (KeyError, ZeroDivisionError) as e:
            self.logger.error(f"{NEON_RED}MFI calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_fibonacci_retracement(self, high: float, low: float, current_price: float) -> Dict[str, float]:
        try:
            diff = high - low
            if diff == 0:
                return {}
            fib_levels = {
                "Fib 23.6%": high - diff * 0.236,
                "Fib 38.2%": high - diff * 0.382,
                "Fib 50.0%": high - diff * 0.5,
                "Fib 61.8%": high - diff * 0.618,
                "Fib 78.6%": high - diff * 0.786,
                "Fib 88.6%": high - diff * 0.886,
                "Fib 94.1%": high - diff * 0.941,
            }
            self.levels = {"Support": {}, "Resistance": {}}
            for label, value in fib_levels.items():
                if value < current_price:
                    self.levels["Support"][label] = value
                elif value > current_price:
                    self.levels["Resistance"][label] = value
            self.fib_levels = fib_levels
            return self.fib_levels
        except ZeroDivisionError:
            self.logger.error(f"{NEON_RED}Fibonacci calculation error: Division by zero.{RESET}")
            return {}
        except Exception as e:
            self.logger.exception(f"{NEON_RED}Fibonacci calculation error: {e}{RESET}")
            return {}

    def calculate_pivot_points(self, high: float, low: float, close: float):
        try:
            pivot = (high + low + close) / 3
            r1 = (2 * pivot) - low
            s1 = (2 * pivot) - high
            r2 = pivot + (high - low)
            s2 = pivot - (high - low)
            r3 = high + 2 * (pivot - low)
            s3 = low - 2 * (high - pivot)
            self.levels.update(
                {
                    "pivot": pivot,
                    "r1": r1,
                    "s1": s1,
                    "r2": r2,
                    "s2": s2,
                    "r3": r3,
                    "s3": s3,
                }
            )
        except Exception as e:
            self.logger.exception(f"{NEON_RED}Pivot point calculation error: {e}{RESET}")
            self.levels = {}

    def find_nearest_levels(self, current_price: float, num_levels: int = 5) -> Tuple[List[Tuple[str, float]], List[Tuple[str, float]]]:
        try:
            support_levels = []
            resistance_levels = []

            def process_level(label, value):
                if value < current_price:
                    support_levels.append((label, value))
                elif value > current_price:
                    resistance_levels.append((label, value))

            for label, value in self.levels.items():
                if isinstance(value, dict):
                    for sub_label, sub_value in value.items():
                        if isinstance(sub_value, (float, Decimal)):
                            process_level(f"{label} ({sub_label})", sub_value)
                elif isinstance(value, (float, Decimal)):
                    process_level(label, value)

            support_levels = sorted(
                support_levels, key=lambda x: abs(x[1] - current_price), reverse=True
            )
            nearest_supports = sorted(support_levels[-num_levels:], key=lambda x: x[1])

            resistance_levels = sorted(
                resistance_levels, key=lambda x: abs(x[1] - current_price)
            )
            nearest_resistances = sorted(
                resistance_levels[:num_levels], key=lambda x: x[1]
            )

            return nearest_supports, nearest_resistances
        except (KeyError, TypeError) as e:
            self.logger.error(f"{NEON_RED}Error finding nearest levels: {e}{RESET}")
            return [], []
        except Exception as e:
            self.logger.exception(f"{NEON_RED}Unexpected error finding nearest levels: {e}{RESET}")
            return [], []

    def calculate_atr(self, window: int = 20) -> pd.Series:
        try:
            high_low = self.df["high"] - self.df["low"]
            high_close = (self.df["high"] - self.df["close"].shift()).abs()
            low_close = (self.df["low"] - self.df["close"].shift()).abs()
            tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
            atr = tr.rolling(window=window).mean()
            return atr
        except KeyError as e:
            self.logger.error(f"{NEON_RED}ATR calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_rsi(self, window: int = 14) -> pd.Series:
        try:
            delta = self.df["close"].diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
            rs = gain / loss
            rsi = np.where(loss == 0, 100, 100 - (100 / (1 + rs)))
            return pd.Series(rsi, index=gain.index)
        except ZeroDivisionError:
            self.logger.error(f"{NEON_RED}RSI calculation error: Division by zero (handled). Returning NaN.{RESET}")
            return pd.Series(np.nan, index=self.df.index)
        except KeyError as e:
            self.logger.error(f"{NEON_RED}RSI calculation error: Missing column - {e}{RESET}")
            return pd.Series(dtype="float64")
        except Exception as e:
            self.logger.exception(f"{NEON_RED}Unexpected error during RSI calculation: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_stoch_rsi(self, rsi_window: int = 14, stoch_window: int = 14,  # Corrected default value
                            k_window: int = 3, d_window: int = 3) -> pd.DataFrame:
        try:
            rsi = self.calculate_rsi(window=rsi_window)
            stoch_rsi = (rsi - rsi.rolling(stoch_window).min()) / (
                rsi.rolling(stoch_window).max() - rsi.rolling(stoch_window).min()
            )
            k_line = stoch_rsi.rolling(window=k_window).mean()
            d_line = k_line.rolling(window=d_window).mean()
            return pd.DataFrame({"stoch_rsi": stoch_rsi, "k": k_line, "d": d_line})
        except (ZeroDivisionError, KeyError, ValueError) as e:
            self.logger.error(f"{NEON_RED}Stochastic RSI calculation error: {e}{RESET}")
            return pd.DataFrame()
        except Exception as e:  # Catch any other unexpected exceptions
            self.logger.exception(f"{NEON_RED}Unexpected error during Stochastic RSI calculation: {e}{RESET}")
            return pd.DataFrame()

    def calculate_momentum_ma(self) -> None:
        try:
            self.df["momentum"] = self.df["close"].diff(self.config["momentum_period"])
            self.df["momentum_ma_short"] = self.df["momentum"].rolling(window=self.config["momentum_ma_short"]).mean()
            self.df["momentum_ma_long"] = self.df["momentum"].rolling(window=self.config["momentum_ma_long"]).mean()
            self.df["volume_ma"] = self.df["volume"].rolling(window=self.config["volume_ma_period"]).mean()
        except KeyError as e:
            self.logger.error(f"{NEON_RED}Momentum/MA calculation error: Missing column {e}{RESET}")

    def calculate_macd(self) -> pd.DataFrame:
        try:
            close_prices = self.df["close"]
            ma_short = close_prices.ewm(span=12, adjust=False).mean()
            ma_long = close_prices.ewm(span=26, adjust=False).mean()
            macd = ma_short - ma_long
            signal = macd.ewm(span=9, adjust=False).mean()
            histogram = macd - signal
            return pd.DataFrame({"macd": macd, "signal": signal, "histogram": histogram})
        except KeyError:
            self.logger.error(f"{NEON_RED}Missing 'close' column for MACD calculation.{RESET}")
            return pd.DataFrame()

    def detect_macd_divergence(self) -> str | None:
        if self.df.empty or len(self.df) < 30:
            return None
        macd_df = self.calculate_macd()
        if macd_df.empty:
            return None
        prices = self.df["close"]
        macd_histogram = macd_df["histogram"]

        if (prices.iloc[-2] > prices.iloc[-1] and macd_histogram.iloc[-2] < macd_histogram.iloc[-1]):
            return "bullish"
        elif (prices.iloc[-2] < prices.iloc[-1] and macd_histogram.iloc[-2] > macd_histogram.iloc[-1]):
            return "bearish"
        return None

    def calculate_ema(self, window: int) -> pd.Series:
        try:
            return self.df["close"].ewm(span=window, adjust=False).mean()
        except KeyError as e:
            self.logger.error(f"{NEON_RED}Missing 'close' column for EMA calculation: {e}{RESET}")
            return pd.Series(dtype="float64")

    def determine_trend_momentum(self) -> dict:
        if self.df.empty or len(self.df) < 26:
            return {"trend": "Insufficient Data", "strength": 0}

        atr = self.calculate_atr()
        if atr.iloc[-1] == 0:
            self.logger.warning(f"{NEON_YELLOW}ATR is zero, cannot calculate trend strength.{RESET}")
            return {"trend": "Neutral", "strength": 0}

        self.calculate_momentum_ma()
        if self.df["momentum_ma_short"].iloc[-1] > self.df["momentum_ma_long"].iloc[-1]:
            trend = "Uptrend"
        elif self.df["momentum_ma_short"].iloc[-1] < self.df["momentum_ma_long"].iloc[-1]:
            trend = "Downtrend"
        else:
            trend = "Neutral"

        trend_strength = abs(self.df["momentum_ma_short"].iloc[-1] - self.df["momentum_ma_long"].iloc[-1]) / atr.iloc[-1]
        return {"trend": trend, "strength": trend_strength}

    def calculate_adx(self, window: int = 14) -> float:
        try:
            df = self.df.copy()

            df["TR"] = pd.concat([df["high"] - df["low"],
                                  abs(df["high"] - df["close"].shift()),
                                  abs(df["low"] - df["close"].shift())], axis=1).max(axis=1)

            df["+DM"] = np.where((df["high"] - df["high"].shift()) > (df["low"].shift() - df["low"]),
                                 np.maximum(df["high"] - df["high"].shift(), 0), 0)
            df["-DM"] = np.where((df["low"].shift() - df["low"]) > (df["high"] - df["high"].shift()),
                                 np.maximum(df["low"].shift() - df["low"], 0), 0)

            df["TR"] = df["TR"].rolling(window).sum()
            df["+DM"] = df["+DM"].rolling(window).sum()
            df["-DM"] = df["-DM"].rolling(window).sum()

            df["+DI"] = 100 * (df["+DM"] / df["TR"])
            df["-DI"] = 100 * (df["-DM"] / df["TR"])
            df["DX"] = 100 * (abs(df["+DI"] - df["-DI"]) / (df["+DI"] + df["-DI"]))

            adx = df["DX"].rolling(window).mean().iloc[-1]
            return adx

        except (KeyError, ZeroDivisionError) as e:
            self.logger.error(f"{NEON_RED}ADX calculation error: {e}{RESET}")
            return 0.0
        except Exception as e:
            self.logger.exception(f"{NEON_RED}Unexpected ADX calculation error: {e}{RESET}")
            return 0.0

    def calculate_obv(self) -> pd.Series:
        try:
            obv = np.where(self.df["close"] > self.df["close"].shift(1),
                           self.df["volume"],
                           np.where(self.df["close"] < self.df["close"].shift(1),
                                    -self.df["volume"],
                                    0))
            return pd.Series(np.cumsum(obv), index=self.df.index)
        except KeyError as e:
            self.logger.error(f"{NEON_RED}OBV calculation error: Missing column {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_adi(self) -> pd.Series:
        try:
            money_flow_multiplier = ((self.df["close"] - self.df["low"]) - (self.df["high"] - self.df["close"])) / (self.df["high"] - self.df["low"])
            money_flow_volume = money_flow_multiplier * self.df["volume"]
            return money_flow_volume.cumsum()
        except (KeyError, ZeroDivisionError) as e:
            self.logger.error(f"{NEON_RED}ADI calculation error: {e}{RESET}")
            return pd.Series(dtype="float64")

    def calculate_psar(self, acceleration=0.02, max_acceleration=0.2) -> pd.Series:
        psar = pd.Series(index=self.df.index, dtype="float64")
        psar.iloc[0] = self.df["low"].iloc[0]
        trend = 1
        ep = self.df["high"].iloc[0]
        af = acceleration

        for i in range(1, len(self.df)):
            if trend == 1:
                psar.iloc[i] = psar.iloc[i-1] + af * (ep - psar.iloc[i-1])
                if self.df["high"].iloc[i] > ep:
                    ep = self.df["high"].iloc[i]
                    af = min(af + acceleration, max_acceleration)
                if self.df["low"].iloc[i] < psar.iloc[i]:
                    trend = -1
                    psar.
