#!/bin/bash

# Create project directory structure
mkdir -p trading_analyzer/bot_logs

# Create and populate constants.py
cat << 'EOF' > trading_analyzer/constants.py
"""Constants and configurations for the trading signal analyzer."""

# Indicator Keywords
TREND_KEYWORDS = {
    'BULLISH': ['Bullish', 'Accumulation', 'Oversold'],
    'BEARISH': ['Bearish', 'Distribution', 'Overbought']
}

# Confidence Scores
TREND_CONFIRMATION_SCORE = 2.0
INDICATOR_CONFIRMATION_SCORE = 1.0
MAX_CONFIDENCE = 10.0

# ATR Multipliers
TP_ATR_MULTIPLIER = 2.0
SL_ATR_MULTIPLIER = 1.5

# File System
BOT_LOGS_DIR = "bot_logs"
EOF

# Create and populate models.py
cat << 'EOF' > trading_analyzer/models.py
"""Data models for trading analysis."""
from dataclasses import dataclass
from typing import Dict, List, Optional

@dataclass
class PriceLevel:
    label: str
    price: float

@dataclass
class AnalysisResult:
    signal: str
    confidence: float
    tp: Optional[str]
    sl: Optional[str]
    reasoning: str
    
@dataclass
class TradingIndicators:
    trend: str
    strength: float
    indicators: Dict[str, str]
    current_price: float
    atr: float
    support_levels: List[PriceLevel]
    resistance_levels: List[PriceLevel]
EOF

# Create and populate signal_analyzer.py
cat << 'EOF' > trading_analyzer/signal_analyzer.py
"""Main signal analysis logic."""
import re
from typing import Dict, List, Optional
from models import AnalysisResult, TradingIndicators, PriceLevel
from constants import (
    TREND_KEYWORDS, TREND_CONFIRMATION_SCORE,
    INDICATOR_CONFIRMATION_SCORE, MAX_CONFIDENCE,
    TP_ATR_MULTIPLIER, SL_ATR_MULTIPLIER
)

class SignalAnalyzer:
    @staticmethod
    def parse_price_level(line: str, prefix: str) -> Optional[PriceLevel]:
        """Parse a price level line into a PriceLevel object."""
        try:
            label = line.split("$")[0].split(":")[1].strip()
            price = float(line.split("$")[1].strip())
            return PriceLevel(label=label, price=price)
        except (IndexError, ValueError):
            print(f"Warning: Could not parse {prefix} level from line: {line}")
            return None

    @staticmethod
    def parse_indicators(lines: List[str]) -> TradingIndicators:
        """Parse raw text lines into structured indicator data."""
        indicators: Dict[str, str] = {}
        trend = ""
        strength = 0.0
        support_levels: List[PriceLevel] = []
        resistance_levels: List[PriceLevel] = []
        current_price = 0.0
        atr = 0.0

        for line in lines:
            line = line.strip()
            
            if line.startswith("Trend:"):
                parts = line.split(":")
                trend = parts[1].strip().split(" ")[0]
                match = re.search(r"Strength: ([\d.]+)", parts[1])
                strength = float(match.group(1)) if match else 0.0
            
            elif ":" in line:
                indicator_name, value = line.split(":", 1)
                indicator_name = indicator_name.lower().strip()
                
                if indicator_name == "current price":
                    try:
                        current_price = float(value.strip())
                    except ValueError:
                        print(f"Warning: Could not parse current price from line: {line}")
                elif indicator_name == "atr":
                    try:
                        atr = float(value.strip())
                    except ValueError:
                        print(f"Warning: Could not parse ATR from line: {line}")
                elif line.startswith("S:"):
                    level = SignalAnalyzer.parse_price_level(line, "support")
                    if level:
                        support_levels.append(level)
                elif line.startswith("R:"):
                    level = SignalAnalyzer.parse_price_level(line, "resistance")
                    if level:
                        resistance_levels.append(level)
                else:
                    indicators[indicator_name] = value.strip()

        return TradingIndicators(
            trend=trend,
            strength=strength,
            indicators=indicators,
            current_price=current_price,
            atr=atr,
            support_levels=support_levels,
            resistance_levels=resistance_levels
        )

    def analyze_signals(self, trading_data: TradingIndicators) -> AnalysisResult:
        """Analyze trading signals and generate trading recommendations."""
        signal = "Neutral"
        confidence = 0.0
        tp = None
        sl = None
        signal_reasoning = []

        # Analysis logic for uptrend
        if self._is_confirmed_uptrend(trading_data):
            signal, confidence, signal_reasoning = self._analyze_uptrend(trading_data)
            tp, sl = self._calculate_levels(
                trading_data, is_long=True
            )

        # Analysis logic for downtrend
        elif self._is_confirmed_downtrend(trading_data):
            signal, confidence, signal_reasoning = self._analyze_downtrend(trading_data)
            tp, sl = self._calculate_levels(
                trading_data, is_long=False
            )

        confidence = min(MAX_CONFIDENCE, confidence)
        
        return AnalysisResult(
            signal=signal,
            confidence=confidence,
            tp=tp,
            sl=sl,
            reasoning=", ".join(signal_reasoning) or "Neutral market conditions or conflicting indicators."
        )

    def _is_confirmed_uptrend(self, data: TradingIndicators) -> bool:
        """Check if there's a confirmed uptrend."""
        return (
            data.trend == "Uptrend" and 
            data.indicators.get("adx", "").find("Trending") != -1
        )

    def _is_confirmed_downtrend(self, data: TradingIndicators) -> bool:
        """Check if there's a confirmed downtrend."""
        return (
            data.trend == "Downtrend" and 
            data.indicators.get("adx", "").find("Trending") != -1
        )

    def _analyze_uptrend(self, data: TradingIndicators) -> tuple:
        """Analyze uptrend signals."""
        signal = "Long"
        confidence = TREND_CONFIRMATION_SCORE
        reasoning = ["Uptrend confirmed by ADX"]
        
        for indicator, keywords in TREND_KEYWORDS['BULLISH'].items():
            if any(kw in data.indicators.get(indicator, "") for kw in keywords):
                confidence += INDICATOR_CONFIRMATION_SCORE
                reasoning.append(f"{indicator.upper()} {keywords[0]}")
                
        return signal, confidence, reasoning

    def _analyze_downtrend(self, data: TradingIndicators) -> tuple:
        """Analyze downtrend signals."""
        signal = "Short"
        confidence = TREND_CONFIRMATION_SCORE
        reasoning = ["Downtrend confirmed by ADX"]
        
        for indicator, keywords in TREND_KEYWORDS['BEARISH'].items():
            if any(kw in data.indicators.get(indicator, "") for kw in keywords):
                confidence += INDICATOR_CONFIRMATION_SCORE
                reasoning.append(f"{indicator.upper()} {keywords[0]}")
                
        return signal, confidence, reasoning

    def _calculate_levels(self, data: TradingIndicators, is_long: bool) -> tuple:
        """Calculate take profit and stop loss levels."""
        if is_long:
            tp = self._calculate_long_tp(data)
            sl = self._calculate_long_sl(data)
        else:
            tp = self._calculate_short_tp(data)
            sl = self._calculate_short_sl(data)
        
        return tp, sl

    def _calculate_long_tp(self, data: TradingIndicators) -> str:
        nearest_resistance = next(
            (level for level in data.resistance_levels if level.price > data.current_price),
            None
        )
        if nearest_resistance:
            return f"{nearest_resistance.price:.2f}"
        return f"{data.current_price + TP_ATR_MULTIPLIER * data.atr:.2f}"

    def _calculate_long_sl(self, data: TradingIndicators) -> str:
        nearest_support = next(
            (level for level in data.support_levels if level.price < data.current_price),
            None
        )
        if nearest_support:
            return f"{nearest_support.price:.2f}"
        return f"{data.current_price - SL_ATR_MULTIPLIER * data.atr:.2f}"
EOF

# Create and populate main.py
cat << 'EOF' > trading_analyzer/main.py
"""Main entry point for the trading signal analyzer."""
import os
from signal_analyzer import SignalAnalyzer
from constants import BOT_LOGS_DIR

def get_latest_log_content() -> str:
    """Get content from the latest log file."""
    try:
        log_files = [
            f for f in os.listdir(BOT_LOGS_DIR) 
            if os.path.isfile(os.path.join(BOT_LOGS_DIR, f))
        ]
        
        if not log_files:
            raise FileNotFoundError(f"No log files found in {BOT_LOGS_DIR} directory.")
            
        latest_log_file = max(
            log_files,
            key=lambda f: os.path.getmtime(os.path.join(BOT_LOGS_DIR, f))
        )
        
        with open(os.path.join(BOT_LOGS_DIR, latest_log_file), "r") as file:
            return file.read()
            
    except Exception as e:
        raise RuntimeError(f"Error reading log file: {str(e)}")

def main():
    try:
        # Get the latest log content
        output_text = get_latest_log_content()
        
        # Initialize the analyzer
        analyzer = SignalAnalyzer()
        
        # Parse the indicators from the log
        trading_data = analyzer.parse_indicators(output_text.split("\n"))
        
        # Analyze the signals
        analysis_result = analyzer.analyze_signals(trading_data)
        
        # Print the results
        print("Analysis of the latest log file:")
        print(f"  Signal: {analysis_result.signal}")
        print(f"  Confidence: {analysis_result.confidence:.1f}")
        print(f"  Take Profit: {analysis_result.tp}")
        print(f"  Stop Loss: {analysis_result.sl}")
        print(f"  Reasoning: {analysis_result.reasoning}")
        
    except Exception as e:
        print(f"Error analyzing trading signals: {str(e)}")

if __name__ == "__main__":
    main()
EOF

echo "Setup complete. Your project structure is ready."
