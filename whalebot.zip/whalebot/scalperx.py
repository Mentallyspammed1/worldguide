import os
import logging
import time
import hmac
import hashlib
import unittest  # Unused import
from datetime import datetime
from typing import Dict, List, Optional  # Added Optional
from decimal import Decimal, getcontext
from zoneinfo import ZoneInfo

import requests
import pandas as pd
import numpy as np
import sklearn
from sklearn.preprocessing import StandardScaler
from dotenv import load_dotenv
import colorama
from colorama import Fore, Style  # Unused import Style
import joblib  # For loading ML models

# Initialize colorama and decimal precision
colorama.init(autoreset=True)
getcontext().prec = 10

# Load environment variables
load_dotenv()

# Configuration constants
CONFIG = {
    "symbol": "BTCUSDT",
    "interval": "15",
    "analysis_window": 200,
    "risk_reward_ratio": 1.5,
    "max_drawdown": 0.05,
    "indicators": {
        "ema_alignment": True,
        "momentum": True,
        "volume_confirmation": True,
        "divergence": True,
        "stoch_rsi": True,
        "macd": True,
        "psar": True,
        "atr": True,
    },
    "weight_sets": {
        "default": {
            "ema_alignment": 0.15,
            "momentum": 0.20,
            "volume_confirmation": 0.10,
            "divergence": 0.15,
            "stoch_rsi": 0.25,
            "macd": 0.10,
            "psar": 0.05,
        },
        "scalping": {
            "ema_alignment": 0.20,
            "momentum": 0.30,
            "volume_confirmation": 0.15,
            "divergence": 0.05,
            "stoch_rsi": 0.15,
            "macd": 0.10,
            "psar": 0.05,
        }
    },
    "stoch_rsi_levels": {"overbought": 0.8, "oversold": 0.2},
    "psar_acceleration": 0.02,
    "psar_max_acceleration": 0.2,
    "atr_signal_threshold_multiplier": 0.2,
    "valid_intervals": ["1", "3", "5", "15", "30", "60", "120", "240", "D"]
}

# API configuration
API_KEY = os.getenv("BYBIT_API_KEY")
API_SECRET = os.getenv("BYBIT_API_SECRET")
BASE_URL = os.getenv("BYBIT_BASE_URL", "https://api.bybit.com")  # Added default value for BASE_URL
TIMEZONE = ZoneInfo("America/Chicago")
MAX_RETRIES = 3
RETRY_DELAY = 5


def configure_logging() -> logging.Logger:
    """Configure logging system with file and console handlers."""
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    formatter = logging.Formatter(
        "%(asctime)s - %(levelname)s - %(message)s - %(filename)s:%(lineno)d"  # Enhanced formatter
    )

    # Console handler
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # File handler
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    fh = logging.FileHandler(f"{log_dir}/quantum_bot.log")
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    return logger


logger = configure_logging()


class BybitAPI:
    """Unified Bybit API client with retry logic and error handling."""

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})

    def _generate_signature(self, params: Dict) -> str:
        """Generate HMAC SHA256 signature for API requests."""
        param_str = "&".join(
            f"{k}={v}" for k, v in sorted(params.items()) if v is not None
        )
        return hmac.new(
            API_SECRET.encode("utf-8"),
            param_str.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()

    def _send_request(self, method: str, endpoint: str, params: Dict) -> Optional[Dict]:  # Return type Optional[Dict]
        """Send authenticated API request with retry logic."""
        for attempt in range(MAX_RETRIES):
            try:
                params.update({
                    "api_key": API_KEY,
                    "timestamp": str(int(time.time() * 1000)),
                    "recv_window": "5000",
                })
                params["sign"] = self._generate_signature(params)

                response = self.session.request(
                    method,
                    f"{BASE_URL}{endpoint}",
                    params=params,
                    timeout=10
                )
                response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
                return response.json()

            except requests.exceptions.HTTPError as http_err:  # Specific HTTP error handling
                logger.warning(
                    f"HTTP error (attempt {attempt + 1}/{MAX_RETRIES}): {http_err} - Response: {http_err.response.text}"  # Log response text
                )
            except requests.exceptions.ConnectionError as conn_err:  # Specific connection error handling
                logger.warning(
                    f"Connection error (attempt {attempt + 1}/{MAX_RETRIES}): {conn_err}"
                )
            except requests.exceptions.Timeout as timeout_err:  # Specific timeout error handling
                logger.warning(
                    f"Timeout error (attempt {attempt + 1}/{MAX_RETRIES}): {timeout_err}"
                )
            except requests.exceptions.RequestException as req_err:  # Catch-all for other request exceptions
                logger.warning(
                    f"Request error (attempt {attempt + 1}/{MAX_RETRIES}): {req_err}"
                )

            time.sleep(RETRY_DELAY * (attempt + 1))

        logger.error(f"Max API retries exceeded for endpoint: {endpoint} with params: {params}")  # Log endpoint and params
        return None  # Indicate failure

    def get_historical_data(self, symbol: str, interval: str) -> pd.DataFrame:
        """Fetch historical kline data from Bybit."""
        if interval not in CONFIG["valid_intervals"]:  # Validate interval
            logger.error(f"Invalid interval: {interval}. Must be one of {CONFIG['valid_intervals']}")
            return pd.DataFrame()

        params = {
            "category": "linear",
            "symbol": symbol,
            "interval": interval,
            "limit": CONFIG["analysis_window"]
        }

        data = self._send_request("GET", "/v5/market/kline", params)
        if not data:  # Check for None response from _send_request
            return pd.DataFrame()
        if data.get("ret_code") != 0 or not data.get("result") or not data.get("result").get("list"):  # Check for 'list' key
            logger.error(f"Failed to fetch historical data. Response: {data}")  # Log full response
            return pd.DataFrame()

        df = pd.DataFrame(
            data["result"]["list"],
            columns=["timestamp", "open", "high", "low", "close", "volume", "turnover"]
        )

        # Convert and validate data
        numeric_cols = ["open", "high", "low", "close", "volume"]
        for col in numeric_cols:  # Iterate through columns for clarity
            df[col] = pd.to_numeric(df[col], errors="coerce")
            if df[col].isnull().any():  # Check for NaN after conversion
                logger.error(f"NaN values found in historical data column: {col}")
                return pd.DataFrame() # Return empty DataFrame if NaN is found

        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", errors='coerce').dt.tz_localize(TIMEZONE)  # Added errors='coerce'
        if df["timestamp"].isnull().any(): # Check for NaN in timestamp
            logger.error("NaN values found in timestamp conversion")
            return pd.DataFrame()

        df = df.dropna() # Drop rows with NaN values after all conversions, in case errors='coerce' introduced NaNs
        return df.iloc[-CONFIG["analysis_window"]:]

    def get_account_balance(self) -> float:
        """Fetch USDT balance from Bybit account."""
        params = {"accountType": "UNIFIED"}
        data = self._send_request("GET", "/v5/account/wallet-balance", params)
        if not data:  # Check for None response
            return 0.0
        if data.get("ret_code") == 0 and data.get("result") and data.get("result").get("list"):  # Added checks for 'result' and 'list'
            for asset in data["result"]["list"][0]["coin"]:
                if asset["coin"] == "USDT":
                    return float(asset["walletBalance"])
        logger.error(f"Failed to fetch account balance. Response: {data}") # Log response on failure
        return 0.0

    def place_order(self, symbol: str, side: str, qty: float) -> Optional[Dict]:  # Return type Optional[Dict]
        """Place a market order on Bybit."""
        params = {
            "category": "linear",
            "symbol": symbol,
            "side": side,
            "orderType": "Market",
            "qty": str(qty),
            "timeInForce": "GTC"
        }
        data = self._send_request("POST", "/v5/order/create", params)
        if not data or data.get("ret_code") != 0: # Check for None and ret_code
            logger.error(f"Failed to place order. Response: {data}") # Log response on failure
            return None # Indicate failure
        return data


class PositionManager:
    """Manages trading positions and calculates position size based on risk."""

    def __init__(self):
        self.positions = {}
        self.risk_per_trade = 0.02  # 2% risk per trade

    def calculate_position_size(self, entry_price: float, stop_loss: float, account_balance: float) -> float:
        """Calculate position size based on risk parameters."""
        if not all(isinstance(arg, (int, float)) and arg >= 0 for arg in [entry_price, stop_loss, account_balance]): # Input validation
            logger.error(f"Invalid input for calculate_position_size: entry_price={entry_price}, stop_loss={stop_loss}, account_balance={account_balance}")
            return 0.0 # Return 0 to prevent trade
        if entry_price <= stop_loss: # Ensure entry price is greater than stop loss for long positions
            logger.error(f"Entry price must be greater than stop loss for long positions. entry_price={entry_price}, stop_loss={stop_loss}")
            return 0.0

        risk_amount = account_balance * self.risk_per_trade
        price_risk = abs(entry_price - stop_loss)
        if price_risk == 0: # Prevent division by zero
            logger.error("Price risk is zero, cannot calculate position size.")
            return 0.0
        return risk_amount / price_risk

    def add_position(self, symbol: str, entry_price: float, stop_loss: float, take_profit: float, size: float):
        """Add a new position to the manager."""
        if symbol in self.positions: # Prevent duplicate positions
            logger.warning(f"Position for {symbol} already exists. Ignoring new position.")
            return
        if not all(isinstance(arg, (int, float)) and arg >= 0 for arg in [entry_price, stop_loss, take_profit, size]): # Input validation
            logger.error(f"Invalid input for add_position: entry_price={entry_price}, stop_loss={stop_loss}, take_profit={take_profit}, size={size}")
            return

        self.positions[symbol] = {
            'entry_price': entry_price,
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'size': size,
            'timestamp': datetime.now(TIMEZONE)
        }
        logger.info(f"Position opened for {symbol} at {entry_price}, SL={stop_loss}, TP={take_profit}, Size={size}") # Log position opening

    def close_position(self, symbol: str, exit_price: float) -> float:
        """Close a position and calculate PnL."""
        if not isinstance(exit_price, (int, float)): # Input validation
            logger.error(f"Invalid exit_price for close_position: {exit_price}")
            return 0.0

        position = self.positions.pop(symbol, None)
        if position:
            pnl = (exit_price - position["entry_price"]) * position["size"]
            logger.info(f"Position closed for {symbol} at {exit_price}, PnL={pnl:.2f}") # Log position closing and PnL
            return pnl
        else:
            logger.warning(f"No position found for {symbol} to close.") # Log if no position found
            return 0.0


class RiskManager:
    """Monitors risk parameters for trading operations."""

    def __init__(self, max_open_positions: int = 3):
        if not isinstance(max_open_positions, int) or max_open_positions <= 0: # Input validation
            logger.error(f"Invalid max_open_positions: {max_open_positions}. Using default value 3.")
            max_open_positions = 3 # Fallback to default
        self.max_open_positions = max_open_positions
        self.daily_drawdown = 0
        self.max_daily_drawdown = CONFIG['max_drawdown']

    def can_open_position(self, position_manager: PositionManager) -> bool:
        """Check if new position can be opened based on risk parameters."""
        if not isinstance(position_manager, PositionManager): # Type validation
            logger.error("Invalid position_manager object passed to can_open_position.")
            return False

        if len(position_manager.positions) >= self.max_open_positions:
            logger.warning(f"Maximum open positions reached ({self.max_open_positions}). Cannot open new position.") # Log reason for blocking position
            return False
        if self.daily_drawdown >= self.max_daily_drawdown:
            logger.warning(f"Maximum daily drawdown reached ({self.max_daily_drawdown:.2f}). Cannot open new position.") # Log reason for blocking position
            return False
        return True

    def update_drawdown(self, pnl: float, account_balance: float):
        """Update daily drawdown tracking."""
        if not all(isinstance(arg, (int, float)) for arg in [pnl, account_balance]): # Input validation
            logger.error(f"Invalid input for update_drawdown: pnl={pnl}, account_balance={account_balance}")
            return

        if account_balance <= 0: # Prevent division by zero or negative balance
            logger.error(f"Invalid account balance for drawdown calculation: {account_balance}")
            return

        drawdown_percentage = -pnl / account_balance if pnl < 0 else 0 # Only calculate drawdown if PnL is negative
        self.daily_drawdown = max(self.daily_drawdown, drawdown_percentage)
        logger.info(f"Daily Drawdown updated: {self.daily_drawdown:.4f}") # Log drawdown update

    def reset_daily_drawdown(self):
        """Reset daily drawdown at midnight."""
        now = datetime.now(TIMEZONE)
        if now.hour == 0 and now.minute == 0: # Reset at the start of the day
            self.daily_drawdown = 0
            logger.info("Daily drawdown reset.") # Log drawdown reset


class PerformanceMonitor:
    """Tracks performance metrics for trades."""

    def __init__(self):
        self.trades = []
        self.metrics = {
            'win_rate': 0,
            'avg_profit': 0,
            'max_drawdown': 0,
            'sharpe_ratio': 0
        }

    def add_trade(self, trade_data: Dict):
        """Add a new trade to the monitor."""
        if not isinstance(trade_data, dict) or 'pnl' not in trade_data: # Input validation
            logger.error(f"Invalid trade_data format: {trade_data}. Must be a dict with 'pnl' key.")
            return

        self.trades.append(trade_data)
        self._update_metrics()

    def _update_metrics(self):
        """Update performance metrics based on trades."""
        if not self.trades:
            return

        profits = [t['pnl'] for t in self.trades]
        if not profits: # Check if profits list is empty to avoid division by zero in win_rate calculation
            return

        win_count = sum(1 for p in profits if p > 0) # More efficient way to count wins
        self.metrics['win_rate'] = win_count / len(profits) if profits else 0 # Avoid division by zero
        self.metrics['avg_profit'] = np.mean(profits) if profits else 0
        self.metrics['sharpe_ratio'] = self._calculate_sharpe_ratio(profits)
        logger.info(f"Performance Metrics updated: Win Rate={self.metrics['win_rate']:.2f}, Avg Profit={self.metrics['avg_profit']:.2f}, Sharpe Ratio={self.metrics['sharpe_ratio']:.2f}") # Log metrics update

    def _calculate_sharpe_ratio(self, returns: List[float]) -> float:
        """Calculate Sharpe ratio for trade returns."""
        if not returns or len(returns) < 2:  # Need at least 2 returns to calculate std dev
            return 0.0
        returns_np = np.array(returns)
        std_dev = np.std(returns_np)
        if std_dev == 0: # Handle case where std dev is zero
            return 0.0
        return np.mean(returns_np) / std_dev


class MLSignalEnhancer:
    """Enhances trading signal using machine learning."""

    def __init__(self, model_path: str = "models/signal_model.pkl"):
        self.model = None # Initialize model to None
        self.scaler = None # Initialize scaler to None
        self.model_path = model_path # Store model path for logging

        try:
            with open(model_path, "rb") as f:
                self.model = joblib.load(f)
            self.scaler = StandardScaler()
            logger.info(f"ML model loaded successfully from {model_path}") # Log successful model loading
        except FileNotFoundError:
            logger.warning(f"ML model file not found at {model_path}. ML enhancement disabled.") # Log warning if model not found
        except Exception as e:
            logger.error(f"Failed to load ML model from {model_path}: {e}") # Log specific error


    def prepare_features(self, df: pd.DataFrame) -> Optional[np.ndarray]:  # Return type Optional[np.ndarray]
        """Prepare features for ML model."""
        if not isinstance(df, pd.DataFrame) or df.empty: # Input validation
            logger.error("Invalid or empty DataFrame passed to prepare_features.")
            return None

        feature_columns = ['ema_short', 'ema_long', 'macd', 'signal', 'psar', 'atr', 'stoch_k', 'stoch_d', 'momentum', 'vol_ma', 'vol_conf'] # Define feature columns explicitly
        missing_columns = [col for col in feature_columns if col not in df.columns] # Check for missing columns
        if missing_columns:
            logger.error(f"DataFrame is missing required feature columns for ML model: {missing_columns}")
            return None

        try:
            features = df[feature_columns].values
            if self.scaler is None:
                logger.warning("Scaler not initialized, consider fitting scaler before use.") # Warning if scaler is unexpectedly None
                self.scaler = StandardScaler() # Initialize scaler if it's None, to prevent errors later
                features = self.scaler.fit_transform(features)
            else:
                features = self.scaler.transform(features)
            return features
        except KeyError as e:
            logger.error(f"KeyError in prepare_features, missing column: {e}") # Log KeyError if feature column is missing
            return None
        except Exception as e:
            logger.error(f"Error preparing features for ML model: {e}") # Catch-all for other errors
            return None


    def enhance_signal(self, base_signal: Dict, features: Optional[np.ndarray]) -> Dict:  # Feature can be None
        """Enhance trading signal with ML predictions."""
        if self.model is None:
            logger.debug("ML model not loaded. Signal enhancement skipped.") # Debug log if model is not loaded
            return base_signal
        if not isinstance(base_signal, dict) or 'score' not in base_signal: # Input validation for base_signal
            logger.error(f"Invalid base_signal format: {base_signal}. Must be a dict with 'score' key.")
            return base_signal
        if features is None or not isinstance(features, np.ndarray) or features.ndim != 2 or features.shape[0] == 0: # Input validation for features
            logger.error(f"Invalid features format: {type(features)}, shape: {getattr(features, 'shape', None)}. Expected non-empty 2D numpy array.")
            return base_signal


        try:
            pred_prob = self.model.predict_proba(features[-1].reshape(1, -1))[0]
            confidence = max(pred_prob)

            if confidence > 0.7:  # Minimum confidence threshold
                enhanced_score = base_signal['score'] * confidence
                logger.info(f"ML enhanced signal score from {base_signal['score']:.2f} to {enhanced_score:.2f} with confidence {confidence:.2f}") # Log signal enhancement
                return {"signal": base_signal['signal'], "score": enhanced_score} # Return enhanced signal with updated score
            else:
                logger.debug(f"ML confidence ({confidence:.2f}) below threshold (0.7). Signal not enhanced.") # Debug log if confidence is below threshold
                return base_signal # Return original signal if confidence is low

        except Exception as e:
            logger.error(f"Error enhancing signal with ML: {e}") # Log error during signal enhancement
            return base_signal # Return original signal in case of error


class MarketAnalyzer:
    """Advanced market analysis with multiple technical indicators."""

    def __init__(self, df: pd.DataFrame):
        if not isinstance(df, pd.DataFrame) or df.empty: # Input validation
            logger.error("Invalid or empty DataFrame passed to MarketAnalyzer.")
            raise ValueError("DataFrame cannot be empty or None")

        self.df = df.copy()
        try:
            self._validate_data()
            self._calculate_indicators()
        except ValueError as e:
            logger.error(f"Data validation or indicator calculation failed: {e}") # Log error during initialization
            raise


    def _validate_data(self):
        """Ensure data quality and completeness."""
        if len(self.df) < CONFIG["analysis_window"]: # Use CONFIG for analysis window
            raise ValueError(f"Insufficient data (minimum {CONFIG['analysis_window']} periods required, got {len(self.df)})")
        if self.df.isnull().values.any():
            raise ValueError("Dataset contains missing values after initial cleaning. Check data fetching.")


    def _calculate_indicators(self):
        """Calculate all enabled technical indicators."""
        try:
            # Price-based indicators
            if CONFIG["indicators"]["ema_alignment"]:
                self._calculate_ema()
            if CONFIG["indicators"]["macd"]:
                self._calculate_macd()
            if CONFIG["indicators"]["psar"]:
                self._calculate_psar()
            if CONFIG["indicators"]["atr"]:
                self._calculate_atr()

            # Momentum indicators
            if CONFIG["indicators"]["stoch_rsi"]:
                self._calculate_stoch_rsi()
            if CONFIG["indicators"]["momentum"]:
                self._calculate_momentum()
            if CONFIG["indicators"]["divergence"]:
                self._calculate_divergence()

            # Volume indicators
            if CONFIG["indicators"]["volume_confirmation"]:
                self._calculate_volume_confirmation()

        except Exception as e:
            logger.error(f"Error during indicator calculation: {e}") # Log error during indicator calculation
            raise


    def _calculate_ema(self):
        """Calculate Exponential Moving Averages."""
        try:
            self.df["ema_short"] = self.df["close"].ewm(span=20, adjust=False).mean()
            self.df["ema_long"] = self.df["close"].ewm(span=50, adjust=False).mean()
        except KeyError as e:
            logger.error(f"KeyError in _calculate_ema: {e}. Ensure 'close' column exists.") # Log specific KeyError
            raise
        except Exception as e:
            logger.error(f"Error calculating EMA: {e}") # Catch-all for other errors
            raise


    def _calculate_macd(self):
        """Calculate Moving Average Convergence Divergence."""
        try:
            ema12 = self.df["close"].ewm(span=12, adjust=False).mean()
            ema26 = self.df["close"].ewm(span=26, adjust=False).mean()
            self.df["macd"] = ema12 - ema26
            self.df["signal"] = self.df["macd"].ewm(span=9, adjust=False).mean()
        except KeyError as e:
            logger.error(f"KeyError in _calculate_macd: {e}. Ensure 'close' column exists.") # Log specific KeyError
            raise
        except Exception as e:
            logger.error(f"Error calculating MACD: {e}") # Catch-all for other errors
            raise


    def _calculate_psar(self):
        """Calculate Parabolic SAR with dynamic acceleration."""
        try:
            high = self.df["high"].values
            low = self.df["low"].values
            psar = np.full(len(high), np.nan)
            bull = True
            acc = CONFIG["psar_acceleration"]
            max_acc = CONFIG["psar_max_acceleration"]

            psar[0] = low[0]
            extreme = high[0]

            for i in range(1, len(high)):
                psar[i] = psar[i - 1] + acc * (extreme - psar[i - 1])

                if bull:
                    if low[i] < psar[i]:
                        bull = False
                        psar[i] = extreme
                        extreme = low[i]
                        acc = CONFIG["psar_acceleration"]
                    else:
                        if high[i] > extreme:
                            extreme = high[i]
                            acc = min(acc + CONFIG["psar_acceleration"], max_acc)
                else:
                    if high[i] > psar[i]:
                        bull = True
                        psar[i] = extreme
                        extreme = high[i]
                        acc = CONFIG["psar_acceleration"]
                    else:
                        if low[i] < extreme:
                            extreme = low[i]
                            acc = min(acc + CONFIG["psar_acceleration"], max_acc)

            self.df["psar"] = psar
        except KeyError as e:
            logger.error(f"KeyError in _calculate_psar: {e}. Ensure 'high' and 'low' columns exist.") # Log specific KeyError
            raise
        except Exception as e:
            logger.error(f"Error calculating PSAR: {e}") # Catch-all for other errors
            raise


    def _calculate_atr(self):
        """Calculate Average True Range."""
        try:
            high_low = self.df["high"] - self.df["low"]
            high_close = (self.df["high"] - self.df["close"].shift()).abs()
            low_close = (self.df["low"] - self.df["close"].shift()).abs()
            tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
            self.df["atr"] = tr.rolling(14).mean()
        except KeyError as e:
            logger.error(f"KeyError in _calculate_atr: {e}. Ensure 'high', 'low', and 'close' columns exist.") # Log specific KeyError
            raise
        except Exception as e:
            logger.error(f"Error calculating ATR: {e}") # Catch-all for other errors
            raise


    def _calculate_stoch_rsi(self):
        """Calculate Stochastic RSI with triple smoothing."""
        try:
            rsi = self._calculate_rsi()
            stoch_k = (rsi - rsi.rolling(14).min()) / (rsi.rolling(14).max() - rsi.rolling(14).min())
            self.df["stoch_k"] = stoch_k.rolling(3).mean()
            self.df["stoch_d"] = self.df["stoch_k"].rolling(3).mean()
        except KeyError as e:
            logger.error(f"KeyError in _calculate_stoch_rsi: {e}. Ensure 'close' column exists for RSI calculation.") # Log specific KeyError
            raise
        except Exception as e:
            logger.error(f"Error calculating Stochastic RSI: {e}") # Catch-all for other errors
            raise


    def _calculate_rsi(self) -> pd.Series:
        """Calculate Relative Strength Index."""
        try:
            delta = self.df["close"].diff()
            gain = delta.where(delta > 0, 0.0)
            loss = -delta.where(delta < 0, 0.0)

            avg_gain = gain.rolling(14).mean()
            avg_loss = loss.rolling(14).mean()

            rs = avg_gain / avg_loss
            return 100 - (100 / (1 + rs))
        except KeyError as e:
            logger.error(f"KeyError in _calculate_rsi: {e}. Ensure 'close' column exists.") # Log specific KeyError
            raise
        except ZeroDivisionError:
            logger.warning("ZeroDivisionError in RSI calculation, returning default RSI.") # Warning for ZeroDivisionError
            return pd.Series(np.full(len(self.df), 50)) # Return neutral RSI if division by zero
        except Exception as e:
            logger.error(f"Error calculating RSI: {e}") # Catch-all for other errors
            raise


    def _calculate_momentum(self):
        """Calculate price momentum."""
        try:
            self.df["momentum"] = self.df["close"].diff(10)
        except KeyError as e:
            logger.error(f"KeyError in _calculate_momentum: {e}. Ensure 'close' column exists.") # Log specific KeyError
            raise
        except Exception as e:
            logger.error(f"Error calculating Momentum: {e}") # Catch-all for other errors
            raise


    def _calculate_divergence(self):
        """Detect price/indicator divergences."""
        try:
            rsi = self._calculate_rsi()
            self.df["bull_div"] = (self.df["close"] < self.df["close"].shift()) & (rsi > rsi.shift())
            self.df["bear_div"] = (self.df["close"] > self.df["close"].shift()) & (rsi < rsi.shift())
        except KeyError as e:
            logger.error(f"KeyError in _calculate_divergence: {e}. Ensure 'close' column exists for divergence calculation.") # Log specific KeyError
            raise
        except Exception as e:
            logger.error(f"Error calculating Divergence: {e}") # Catch-all for other errors
            raise


    def _calculate_volume_confirmation(self):
        """Analyze volume confirmation signals."""
        try:
            self.df["vol_ma"] = self.df["volume"].rolling(20).mean()
            self.df["vol_conf"] = self.df["volume"] > self.df["vol_ma"] * 1.2
        except KeyError as e:
            logger.error(f"KeyError in _calculate_volume_confirmation: {e}. Ensure 'volume' column exists.") # Log specific KeyError
            raise
        except Exception as e:
            logger.error(f"Error calculating Volume Confirmation: {e}") # Catch-all for other errors
            raise


    def generate_signal(self) -> Dict:
        """Generate trading signal based on weighted indicator analysis."""
        weights = CONFIG["weight_sets"]["default"]
        score = 0.0
        current = self.df.iloc[-1]

        try:
            # EMA Alignment
            if CONFIG["indicators"]["ema_alignment"]:
                if current["ema_short"] > current["ema_long"]:
                    score += weights["ema_alignment"]

            # Momentum
            if CONFIG["indicators"]["momentum"]:
                score += weights["momentum"] * np.tanh(current["momentum"] / current["atr"])

            # Volume Confirmation
            if CONFIG["indicators"]["volume_confirmation"]:
                if current["vol_conf"]:
                    score += weights["volume_confirmation"]

            # Divergence
            if CONFIG["indicators"]["divergence"]:
                if current["bull_div"]:
                    score += weights["divergence"]
                elif current["bear_div"]:
                    score -= weights["divergence"]

            # Stochastic RSI
            if CONFIG["indicators"]["stoch_rsi"]:
                if current["stoch_k"] < CONFIG["stoch_rsi_levels"]["oversold"]:
                    score += weights["stoch_rsi"]
                elif current["stoch_k"] > CONFIG["stoch_rsi_levels"]["overbought"]:
                    score -= weights["stoch_rsi"]

            # MACD
            if CONFIG["indicators"]["macd"]:
                score += weights["macd"] * np.sign(current["macd"] - current["signal"])

            # PSAR
            if CONFIG["indicators"]["psar"]:
                if current["close"] > current["psar"]:
                    score += weights["psar"]
                else:
                    score -= weights["psar"]

            # Generate signal
            threshold = current["atr"] * CONFIG["atr_signal_threshold_multiplier"]
            if score > threshold:
                return {"signal": "BUY", "score": score}
            elif score < -threshold:
                return {"signal": "SELL", "score": score}
            return {"signal": "HOLD", "score": score}

        except KeyError as e:
            logger.error(f"KeyError in generate_signal: {e}. Missing indicator column.") # Log specific KeyError
            return {"signal": "HOLD", "score": 0.0} # Return HOLD signal on error
        except Exception as e:
            logger.error(f"Error generating trading signal: {e}") # Catch-all for other errors
            return {"signal": "HOLD", "score": 0.0} # Return HOLD signal on error


class QuantumTradingSystem:
    """Main trading system with AI integration and risk management."""

    def __init__(self):
        self.api = BybitAPI()
        self.analyzer = None
        self.position_manager = PositionManager()
        self.risk_manager = RiskManager()
        self.performance_monitor = PerformanceMonitor()
        self.ml_enhancer = MLSignalEnhancer()
        self.last_signal = None
        self.symbol = CONFIG["symbol"] # Store symbol in instance
        self.interval = CONFIG["interval"] # Store interval in instance

    def run_analysis(self, symbol: str, interval: str):
        """Run complete market analysis for given symbol and interval."""
        if symbol != self.symbol or interval != self.interval: # Check if symbol or interval changed
            logger.warning(f"Symbol or interval changed from config. Running analysis for symbol={symbol}, interval={interval}, but using config symbol={self.symbol}, interval={self.interval}") # Log warning if different symbol/interval is passed, using config instead

        try:
            df = self.api.get_historical_data(self.symbol, self.interval) # Use instance symbol and interval
            if df.empty:
                logger.error("No data received for analysis, skipping this cycle.") # More informative log message
                return

            self.analyzer = MarketAnalyzer(df)
            base_signal = self.analyzer.generate_signal()

            # Enhance signal with ML
            features = self.ml_enhancer.prepare_features(df)
            enhanced_signal = self.ml_enhancer.enhance_signal(base_signal, features)

            if self.risk_manager.can_open_position(self.position_manager):
                self._process_signal(enhanced_signal)
            else:
                logger.debug("Risk management prevents opening new position.") # Debug log for risk management block

        except Exception as e:
            logger.error(f"Analysis failed: {e}") # General error logging

    def _process_signal(self, signal: Dict):
        """Process and execute trading signals with risk management."""
        if not isinstance(signal, dict) or 'signal' not in signal or 'score' not in signal: # Input validation
            logger.error(f"Invalid signal format: {signal}. Must be a dict with 'signal' and 'score' keys.")
            return

        if signal["signal"] == "HOLD":
            logger.info("No trading opportunity detected (HOLD signal).") # More informative log message
            return

        logger.info(f"New {Fore.GREEN + signal['signal'] + Style.RESET_ALL} signal with strength {signal['score']:.2f}") # Colored signal output
        self.last_signal = signal

        account_balance = self.api.get_account_balance()
        current_price = self.analyzer.df.iloc[-1]["close"]
        atr = self.analyzer.df.iloc[-1]["atr"]

        # Calculate stop loss and take profit
        if signal["signal"] == "BUY":
            stop_loss = current_price - 2 * atr
            take_profit = current_price + 3 * atr  # 1.5 risk-reward ratio
        else:  # signal["signal"] == "SELL"
            stop_loss = current_price + 2 * atr
            take_profit = current_price - 3 * atr

        position_size = self.position_manager.calculate_position_size(
            current_price, stop_loss, account_balance
        )

        if position_size > 0:
            self.position_manager.add_position(
                self.symbol, current_price, stop_loss, take_profit, position_size # Use instance symbol
            )
            trade_result = self._execute_trade(position_size, signal)
            if trade_result: # Check if trade was successful
                logger.info("Trade execution successful.") # Success log
            else:
                logger.error("Trade execution failed.") # Failure log
        else:
            logger.warning("Calculated position size is zero or negative, trade not executed.") # Log reason for not trading


    def _execute_trade(self, position_size: float, signal: Dict) -> bool:  # Return boolean indicating success/failure
        """Execute trade with proper risk management."""
        if not isinstance(signal, dict) or 'signal' not in signal: # Input validation
            logger.error(f"Invalid signal format in _execute_trade: {signal}. Must be a dict with 'signal' key.")
            return False
        if not isinstance(position_size, (int, float)) or position_size <= 0: # Input validation
            logger.error(f"Invalid position_size in _execute_trade: {position_size}. Must be positive number.")
            return False

        response = self.api.place_order(
            self.symbol, signal["signal"], position_size # Use instance symbol
        )
        if response and response.get("retCode") == 0: # Check if response is not None and retCode is 0
            logger.info(f"Order executed successfully: {response['result']}")
            return True # Indicate success
        else:
            logger.error(f"Order failed: {response.get('retMsg')}. Response: {response}") # Log full response on failure
            return False # Indicate failure


    def check_open_positions(self):
        """Check and close positions based on stop loss/take profit."""
        if not self.position_manager.positions: # Check if positions are empty to avoid unnecessary API calls
            logger.debug("No open positions to check.") # Debug log if no positions
            return

        positions_to_close = [] # Collect positions to close to avoid modifying dict while iterating
        for symbol, position in self.position_manager.positions.items():
            try:
                current_df = self.api.get_historical_data(symbol, self.interval) # Fetch latest data for each position symbol and interval
                if current_df.empty:
                    logger.warning(f"No data received for {symbol} to check position, skipping.") # Warning if no data for position check
                    continue # Skip to next position
                current_price = current_df.iloc[-1]["close"]

                if (signal := self.last_signal) and signal["signal"] == "SELL" and current_price >= position["take_profit"]: # Check TP for SELL
                    positions_to_close.append((symbol, current_price, "take_profit"))
                elif (signal := self.last_signal) and signal["signal"] == "BUY" and current_price <= position["stop_loss"]: # Check SL for BUY
                    positions_to_close.append((symbol, current_price, "stop_loss"))
                elif current_price <= position["stop_loss"]: # Check SL for both BUY and SELL
                    positions_to_close.append((symbol, current_price, "stop_loss"))
                elif current_price >= position["take_profit"]: # Check TP for both BUY and SELL
                    positions_to_close.append((symbol, current_price, "take_profit"))
            except Exception as e:
                logger.error(f"Error checking position for {symbol}: {e}") # Log error during position check

        for symbol, exit_price, reason in positions_to_close:
            try:
                pnl = self.position_manager.close_position(symbol, exit_price)
                self.risk_manager.update_drawdown(pnl, self.api.get_account_balance())
                self.performance_monitor.add_trade({"pnl": pnl})
                logger.info(f"Position for {symbol} closed due to {reason} at {exit_price}, PnL={pnl:.2f}") # Log position closing reason
                if reason == "stop_loss":
                    logger.warning(f"Stop loss triggered for {symbol}.") # Stop loss triggered log
                elif reason == "take_profit":
                    logger.info(Fore.GREEN + f"Take profit triggered for {symbol}." + Style.RESET_ALL) # Take profit triggered log in green
            except Exception as e:
                logger.error(f"Error closing position for {symbol}: {e}") # Log error during position closing


def main():
    """Main execution function for the trading system."""
    system = QuantumTradingSystem()

    while True:
        try:
            system.run_analysis(CONFIG["symbol"], CONFIG["interval"])
            system.check_open_positions()
            system.risk_manager.reset_daily_drawdown() # Reset daily drawdown at midnight
            time.sleep(60 * int(CONFIG["interval"])) # Sleep for interval minutes

        except KeyboardInterrupt:
            logger.info("Shutting down Quantum Trading System...") # Shutdown message
            break
        except Exception as e:
            logger.critical(f"Critical error in main loop: {e}", exc_info=True) # Log critical error with traceback
            time.sleep(60) # Wait before retrying after critical error
            logger.info("Restarting analysis loop after error.") # Restart message


if __name__ == "__main__":
    main()
