#!/usr/bin/env python3
"""
BYBIT QUANTUM TRADING SYSTEM
Consolidated trading bot with multiple strategies, AI analysis, and PEP8 compliance.
"""

import os
import logging
import time
import hmac
import hashlib
import unittest
from datetime import datetime
from typing import Dict, List
from decimal import Decimal, getcontext
from zoneinfo import ZoneInfo

import requests
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from dotenv import load_dotenv
import colorama
from colorama import Fore, Style
import joblib  # For loading ML models

# Initialize colorama and decimal precision
colorama.init(autoreset=True)
getcontext().prec = 10

# Load environment variables
load_dotenv()

# Configuration constants
CONFIG = {
    "symbol": "BTCUSDT",
    "interval": "15",
    "analysis_window": 200,
    "risk_reward_ratio": 1.5,
    "max_drawdown": 0.05,
    "indicators": {
        "ema_alignment": True,
        "momentum": True,
        "volume_confirmation": True,
        "divergence": True,
        "stoch_rsi": True,
        "macd": True,
        "psar": True,
        "atr": True,
    },
    "weight_sets": {
        "default": {
            "ema_alignment": 0.15,
            "momentum": 0.20,
            "volume_confirmation": 0.10,
            "divergence": 0.15,
            "stoch_rsi": 0.25,
            "macd": 0.10,
            "psar": 0.05,
        },
        "scalping": {
            "ema_alignment": 0.20,
            "momentum": 0.30,
            "volume_confirmation": 0.15,
            "divergence": 0.05,
            "stoch_rsi": 0.15,
            "macd": 0.10,
            "psar": 0.05,
        }
    },
    "stoch_rsi_levels": {"overbought": 0.8, "oversold": 0.2},
    "psar_acceleration": 0.02,
    "psar_max_acceleration": 0.2,
    "atr_signal_threshold_multiplier": 0.2,
    "valid_intervals": ["1", "3", "5", "15", "30", "60", "120", "240", "D"]
}

# API configuration
API_KEY = os.getenv("BYBIT_API_KEY")
API_SECRET = os.getenv("BYBIT_API_SECRET")
BASE_URL = "https://api.bybit.com"
TIMEZONE = ZoneInfo("America/Chicago")
MAX_RETRIES = 3
RETRY_DELAY = 5


def configure_logging() -> logging.Logger:
    """Configure logging system with file and console handlers."""
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # Console handler
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # File handler
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    fh = logging.FileHandler(f"{log_dir}/quantum_bot.log")
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    return logger


logger = configure_logging()


class BybitAPI:
    """Unified Bybit API client with retry logic and error handling."""

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})

    def _generate_signature(self, params: Dict) -> str:
        """Generate HMAC SHA256 signature for API requests."""
        param_str = "&".join(
            f"{k}={v}" for k, v in sorted(params.items()) if v is not None
        )
        return hmac.new(
            API_SECRET.encode("utf-8"),
            param_str.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()

    def _send_request(self, method: str, endpoint: str, params: Dict) -> Dict:
        """Send authenticated API request with retry logic."""
        for attempt in range(MAX_RETRIES):
            try:
                params.update({
                    "api_key": API_KEY,
                    "timestamp": str(int(time.time() * 1000)),
                    "recv_window": "5000",
                })
                params["sign"] = self._generate_signature(params)

                response = self.session.request(
                    method,
                    f"{BASE_URL}{endpoint}",
                    params=params,
                    timeout=10
                )
                response.raise_for_status()
                return response.json()

            except requests.exceptions.RequestException as e:
                logger.warning(
                    f"API request failed (attempt {attempt + 1}/{MAX_RETRIES}): {e}"
                )
                time.sleep(RETRY_DELAY * (attempt + 1))

        logger.error("Max API retries exceeded")
        return {"ret_code": 1, "ret_msg": "Max retries exceeded"}

    def get_historical_data(self, symbol: str, interval: str) -> pd.DataFrame:
        """Fetch historical kline data from Bybit."""
        params = {
            "category": "linear",
            "symbol": symbol,
            "interval": interval,
            "limit": CONFIG["analysis_window"]
        }

        data = self._send_request("GET", "/v5/market/kline", params)
        if data.get("ret_code") != 0 or not data.get("result"):
            logger.error("Failed to fetch historical data")
            return pd.DataFrame()

        df = pd.DataFrame(
            data["result"]["list"],
            columns=["timestamp", "open", "high", "low", "close", "volume", "turnover"]
        )

        # Convert and validate data
        numeric_cols = ["open", "high", "low", "close", "volume"]
        df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors="coerce")
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms").dt.tz_localize(TIMEZONE)

        return df.dropna().iloc[-CONFIG["analysis_window"]:]

    def get_account_balance(self) -> float:
        """Fetch USDT balance from Bybit account."""
        params = {"accountType": "UNIFIED"}
        data = self._send_request("GET", "/v5/account/wallet-balance", params)
        if data.get("ret_code") == 0:
            for asset in data["result"]["list"][0]["coin"]:
                if asset["coin"] == "USDT":
                    return float(asset["walletBalance"])
        return 0.0

    def place_order(self, symbol: str, side: str, qty: float) -> Dict:
        """Place a market order on Bybit."""
        params = {
            "category": "linear",
            "symbol": symbol,
            "side": side,
            "orderType": "Market",
            "qty": str(qty),
            "timeInForce": "GTC"
        }
        return self._send_request("POST", "/v5/order/create", params)


class PositionManager:
    """Manages trading positions and calculates position size based on risk."""

    def __init__(self):
        self.positions = {}
        self.risk_per_trade = 0.02  # 2% risk per trade

    def calculate_position_size(self, entry_price: float, stop_loss: float, account_balance: float) -> float:
        """Calculate position size based on risk parameters."""
        risk_amount = account_balance * self.risk_per_trade
        price_risk = abs(entry_price - stop_loss)
        return risk_amount / price_risk

    def add_position(self, symbol: str, entry_price: float, stop_loss: float, take_profit: float, size: float):
        """Add a new position to the manager."""
        self.positions[symbol] = {
            'entry_price': entry_price,
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'size': size,
            'timestamp': datetime.now(TIMEZONE)
        }

    def close_position(self, symbol: str, exit_price: float) -> float:
        """Close a position and calculate PnL."""
        position = self.positions.pop(symbol, None)
        if position:
            pnl = (exit_price - position["entry_price"]) * position["size"]
            return pnl
        return 0.0


class RiskManager:
    """Monitors risk parameters for trading operations."""

    def __init__(self, max_open_positions: int = 3):
        self.max_open_positions = max_open_positions
        self.daily_drawdown = 0
        self.max_daily_drawdown = CONFIG['max_drawdown']

    def can_open_position(self, position_manager: PositionManager) -> bool:
        """Check if new position can be opened based on risk parameters."""
        if len(position_manager.positions) >= self.max_open_positions:
            return False
        if self.daily_drawdown >= self.max_daily_drawdown:
            return False
        return True

    def update_drawdown(self, pnl: float, account_balance: float):
        """Update daily drawdown tracking."""
        self.daily_drawdown = max(self.daily_drawdown, -pnl / account_balance)

    def reset_daily_drawdown(self):
        """Reset daily drawdown at midnight."""
        if datetime.now(TIMEZONE).hour == 0:
            self.daily_drawdown = 0


class PerformanceMonitor:
    """Tracks performance metrics for trades."""

    def __init__(self):
        self.trades = []
        self.metrics = {
            'win_rate': 0,
            'avg_profit': 0,
            'max_drawdown': 0,
            'sharpe_ratio': 0
        }

    def add_trade(self, trade_data: Dict):
        """Add a new trade to the monitor."""
        self.trades.append(trade_data)
        self._update_metrics()

    def _update_metrics(self):
        """Update performance metrics based on trades."""
        if not self.trades:
            return

        profits = [t['pnl'] for t in self.trades]
        self.metrics['win_rate'] = len([p for p in profits if p > 0]) / len(profits)
        self.metrics['avg_profit'] = np.mean(profits)
        self.metrics['sharpe_ratio'] = self._calculate_sharpe_ratio(profits)

    def _calculate_sharpe_ratio(self, returns: List[float]):
        """Calculate Sharpe ratio for trade returns."""
        if len(returns) == 0:
            return 0
        return np.mean(returns) / np.std(returns)


class MLSignalEnhancer:
    """Enhances trading signal using machine learning."""

    def __init__(self, model_path: str = "models/signal_model.pkl"):
        try:
            with open(model_path, "rb") as f:
                self.model = joblib.load(f)
            self.scaler = StandardScaler()
        except Exception as e:
            logger.error(f"Failed to load ML model: {e}")
            self.model = None

    def prepare_features(self, df: pd.DataFrame) -> np.ndarray:
        """Prepare features for ML model."""
        features = df[self.feature_columns].values
        if self.scaler is None:
            self.scaler = StandardScaler()
            features = self.scaler.fit_transform(features)
        else:
            features = self.scaler.transform(features)
        return features

    def enhance_signal(self, base_signal: Dict, features: np.ndarray) -> Dict:
        """Enhance trading signal with ML predictions."""
        if self.model is None:
            return base_signal

        pred_prob = self.model.predict_proba(features[-1].reshape(1, -1))[0]
        confidence = max(pred_prob)

        if confidence > 0.7:  # Minimum confidence threshold
            base_signal['score'] *= confidence

        return base_signal


class MarketAnalyzer:
    """Advanced market analysis with multiple technical indicators."""

    def __init__(self, df: pd.DataFrame):
        self.df = df.copy()
        self._validate_data()
        self._calculate_indicators()

    def _validate_data(self):
        """Ensure data quality and completeness."""
        if len(self.df) < 100:
            raise ValueError("Insufficient data (minimum 100 periods required)")
        if self.df.isnull().values.any():
            raise ValueError("Dataset contains missing values")

    def _calculate_indicators(self):
        """Calculate all enabled technical indicators."""
        # Price-based indicators
        self._calculate_ema()
        self._calculate_macd()
        self._calculate_psar()
        self._calculate_atr()

        # Momentum indicators
        self._calculate_stoch_rsi()
        self._calculate_momentum()
        self._calculate_divergence()

        # Volume indicators
        self._calculate_volume_confirmation()

    def _calculate_ema(self):
        """Calculate Exponential Moving Averages."""
        if CONFIG["indicators"]["ema_alignment"]:
            self.df["ema_short"] = self.df["close"].ewm(span=20, adjust=False).mean()
            self.df["ema_long"] = self.df["close"].ewm(span=50, adjust=False).mean()

    def _calculate_macd(self):
        """Calculate Moving Average Convergence Divergence."""
        if CONFIG["indicators"]["macd"]:
            ema12 = self.df["close"].ewm(span=12, adjust=False).mean()
            ema26 = self.df["close"].ewm(span=26, adjust=False).mean()
            self.df["macd"] = ema12 - ema26
            self.df["signal"] = self.df["macd"].ewm(span=9, adjust=False).mean()

    def _calculate_psar(self):
        """Calculate Parabolic SAR with dynamic acceleration."""
        if CONFIG["indicators"]["psar"]:
            high = self.df["high"].values
            low = self.df["low"].values
            psar = np.full(len(high), np.nan)
            bull = True
            acc = CONFIG["psar_acceleration"]
            max_acc = CONFIG["psar_max_acceleration"]

            psar[0] = low[0]
            extreme = high[0]

            for i in range(1, len(high)):
                psar[i] = psar[i - 1] + acc * (extreme - psar[i - 1])

                if bull:
                    if low[i] < psar[i]:
                        bull = False
                        psar[i] = extreme
                        extreme = low[i]
                        acc = CONFIG["psar_acceleration"]
                    else:
                        if high[i] > extreme:
                            extreme = high[i]
                            acc = min(acc + CONFIG["psar_acceleration"], max_acc)
                else:
                    if high[i] > psar[i]:
                        bull = True
                        psar[i] = extreme
                        extreme = high[i]
                        acc = CONFIG["psar_acceleration"]
                    else:
                        if low[i] < extreme:
                            extreme = low[i]
                            acc = min(acc + CONFIG["psar_acceleration"], max_acc)

            self.df["psar"] = psar

    def _calculate_atr(self):
        """Calculate Average True Range."""
        if CONFIG["indicators"]["atr"]:
            high_low = self.df["high"] - self.df["low"]
            high_close = (self.df["high"] - self.df["close"].shift()).abs()
            low_close = (self.df["low"] - self.df["close"].shift()).abs()
            tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
            self.df["atr"] = tr.rolling(14).mean()

    def _calculate_stoch_rsi(self):
        """Calculate Stochastic RSI with triple smoothing."""
        if CONFIG["indicators"]["stoch_rsi"]:
            rsi = self._calculate_rsi()
            stoch_k = (rsi - rsi.rolling(14).min()) / (rsi.rolling(14).max() - rsi.rolling(14).min())
            self.df["stoch_k"] = stoch_k.rolling(3).mean()
            self.df["stoch_d"] = self.df["stoch_k"].rolling(3).mean()

    def _calculate_rsi(self) -> pd.Series:
        """Calculate Relative Strength Index."""
        delta = self.df["close"].diff()
        gain = delta.where(delta > 0, 0.0)
        loss = -delta.where(delta < 0, 0.0)

        avg_gain = gain.rolling(14).mean()
        avg_loss = loss.rolling(14).mean()

        rs = avg_gain / avg_loss
        return 100 - (100 / (1 + rs))

    def _calculate_momentum(self):
        """Calculate price momentum."""
        if CONFIG["indicators"]["momentum"]:
            self.df["momentum"] = self.df["close"].diff(10)

    def _calculate_divergence(self):
        """Detect price/indicator divergences."""
        if CONFIG["indicators"]["divergence"]:
            rsi = self._calculate_rsi()
            self.df["bull_div"] = (self.df["close"] < self.df["close"].shift()) & (rsi > rsi.shift())
            self.df["bear_div"] = (self.df["close"] > self.df["close"].shift()) & (rsi < rsi.shift())

    def _calculate_volume_confirmation(self):
        """Analyze volume confirmation signals."""
        if CONFIG["indicators"]["volume_confirmation"]:
            self.df["vol_ma"] = self.df["volume"].rolling(20).mean()
            self.df["vol_conf"] = self.df["volume"] > self.df["vol_ma"] * 1.2

    def generate_signal(self) -> Dict:
        """Generate trading signal based on weighted indicator analysis."""
        weights = CONFIG["weight_sets"]["default"]
        score = 0.0
        current = self.df.iloc[-1]

        # EMA Alignment
        if current["ema_short"] > current["ema_long"]:
            score += weights["ema_alignment"]

        # Momentum
        score += weights["momentum"] * np.tanh(current["momentum"] / current["atr"])

        # Volume Confirmation
        if current["vol_conf"]:
            score += weights["volume_confirmation"]

        # Divergence
        if current["bull_div"]:
            score += weights["divergence"]
        elif current["bear_div"]:
            score -= weights["divergence"]

        # Stochastic RSI
        if current["stoch_k"] < CONFIG["stoch_rsi_levels"]["oversold"]:
            score += weights["stoch_rsi"]
        elif current["stoch_k"] > CONFIG["stoch_rsi_levels"]["overbought"]:
            score -= weights["stoch_rsi"]

        # MACD
        score += weights["macd"] * np.sign(current["macd"] - current["signal"])

        # PSAR
        if current["close"] > current["psar"]:
            score += weights["psar"]
        else:
            score -= weights["psar"]

        # Generate signal
        threshold = current["atr"] * CONFIG["atr_signal_threshold_multiplier"]
        if score > threshold:
            return {"signal": "BUY", "score": score}
        elif score < -threshold:
            return {"signal": "SELL", "score": score}
        return {"signal": "HOLD", "score": score}


class QuantumTradingSystem:
    """Main trading system with AI integration and risk management."""

    def __init__(self):
        self.api = BybitAPI()
        self.analyzer = None
        self.position_manager = PositionManager()
        self.risk_manager = RiskManager()
        self.performance_monitor = PerformanceMonitor()
        self.ml_enhancer = MLSignalEnhancer()
        self.last_signal = None

    def run_analysis(self, symbol: str, interval: str):
        """Run complete market analysis for given symbol and interval."""
        try:
            df = self.api.get_historical_data(symbol, interval)
            if df.empty:
                logger.error("No data received for analysis")
                return

            self.analyzer = MarketAnalyzer(df)
            base_signal = self.analyzer.generate_signal()

            # Enhance signal with ML
            features = self.ml_enhancer.prepare_features(df)
            enhanced_signal = self.ml_enhancer.enhance_signal(base_signal, features)

            if self.risk_manager.can_open_position(self.position_manager):
                self._process_signal(enhanced_signal)

        except Exception as e:
            logger.error(f"Analysis failed: {e}")

    def _process_signal(self, signal: Dict):
        """Process and execute trading signals with risk management."""
        if signal["signal"] == "HOLD":
            logger.info("No trading opportunity detected")
            return

        logger.info(f"New {signal['signal']} signal with strength {signal['score']:.2f}")
        self.last_signal = signal

        account_balance = self.api.get_account_balance()
        current_price = self.analyzer.df.iloc[-1]["close"]
        atr = self.analyzer.df.iloc[-1]["atr"]

        # Calculate stop loss and take profit
        if signal["signal"] == "BUY":
            stop_loss = current_price - 2 * atr
            take_profit = current_price + 3 * atr  # 1.5 risk-reward ratio
        else:
            stop_loss = current_price + 2 * atr
            take_profit = current_price - 3 * atr

        position_size = self.position_manager.calculate_position_size(
            current_price, stop_loss, account_balance
        )

        if position_size > 0:
            self.position_manager.add_position(
                CONFIG["symbol"], current_price, stop_loss, take_profit, position_size
            )
            self._execute_trade(position_size, signal)

    def _execute_trade(self, position_size: float, signal: Dict):
        """Execute trade with proper risk management."""
        response = self.api.place_order(
            CONFIG["symbol"], signal["signal"], position_size
        )
        if response.get("retCode") == 0:
            logger.info(f"Order executed: {response['result']}")
        else:
            logger.error(f"Order failed: {response.get('retMsg')}")

    def check_open_positions(self):
        """Check and close positions based on stop loss/take profit."""
        for symbol in list(self.position_manager.positions.keys()):
            current_price = self.api.get_historical_data(symbol, CONFIG["interval"]).iloc[-1]["close"]
            position = self.position_manager.positions[symbol]
            if (current_price <= position["stop_loss"] or
                    current_price >= position["take_profit"]):
                pnl = self.position_manager.close_position(symbol, current_price)
                self.risk_manager.update_drawdown(pnl, self.api.get_account_balance())
                self.performance_monitor.add_trade({"pnl": pnl})


def main():
    """Main execution function for the trading system."""
    system = QuantumTradingSystem()

    while True:
        try:
            system.run_analysis(CONFIG["symbol"], CONFIG["interval"])
            system.check_open_positions()
            time.sleep(60 * int(CONFIG["interval"]))

        except KeyboardInterrupt:
            logger.info("Shutting down Quantum Trading System")
            break
        except Exception as e:
            logger.error(f"Critical error: {e}")
            time.sleep(60)


if __name__ == "__main__":
    main()
